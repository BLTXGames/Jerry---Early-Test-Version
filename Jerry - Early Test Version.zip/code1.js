gdjs.StageCode = {};
gdjs.StageCode.GDJerry_9595CharacterObjects1_1final = [];

gdjs.StageCode.forEachIndex4 = 0;

gdjs.StageCode.forEachObjects4 = [];

gdjs.StageCode.forEachTemporary4 = null;

gdjs.StageCode.forEachTotalCount4 = 0;

gdjs.StageCode.GDTileObjects1= [];
gdjs.StageCode.GDTileObjects2= [];
gdjs.StageCode.GDTileObjects3= [];
gdjs.StageCode.GDTileObjects4= [];
gdjs.StageCode.GDTileObjects5= [];
gdjs.StageCode.GDTileObjects6= [];
gdjs.StageCode.GDTileObjects7= [];
gdjs.StageCode.GDTileObjects8= [];
gdjs.StageCode.GDTileObjects9= [];
gdjs.StageCode.GDJerry_9595CharacterObjects1= [];
gdjs.StageCode.GDJerry_9595CharacterObjects2= [];
gdjs.StageCode.GDJerry_9595CharacterObjects3= [];
gdjs.StageCode.GDJerry_9595CharacterObjects4= [];
gdjs.StageCode.GDJerry_9595CharacterObjects5= [];
gdjs.StageCode.GDJerry_9595CharacterObjects6= [];
gdjs.StageCode.GDJerry_9595CharacterObjects7= [];
gdjs.StageCode.GDJerry_9595CharacterObjects8= [];
gdjs.StageCode.GDJerry_9595CharacterObjects9= [];
gdjs.StageCode.GDJump_9595TileObjects1= [];
gdjs.StageCode.GDJump_9595TileObjects2= [];
gdjs.StageCode.GDJump_9595TileObjects3= [];
gdjs.StageCode.GDJump_9595TileObjects4= [];
gdjs.StageCode.GDJump_9595TileObjects5= [];
gdjs.StageCode.GDJump_9595TileObjects6= [];
gdjs.StageCode.GDJump_9595TileObjects7= [];
gdjs.StageCode.GDJump_9595TileObjects8= [];
gdjs.StageCode.GDJump_9595TileObjects9= [];
gdjs.StageCode.GDRegular_9595BrainObjects1= [];
gdjs.StageCode.GDRegular_9595BrainObjects2= [];
gdjs.StageCode.GDRegular_9595BrainObjects3= [];
gdjs.StageCode.GDRegular_9595BrainObjects4= [];
gdjs.StageCode.GDRegular_9595BrainObjects5= [];
gdjs.StageCode.GDRegular_9595BrainObjects6= [];
gdjs.StageCode.GDRegular_9595BrainObjects7= [];
gdjs.StageCode.GDRegular_9595BrainObjects8= [];
gdjs.StageCode.GDRegular_9595BrainObjects9= [];
gdjs.StageCode.GDBrainSpawnLEFTObjects1= [];
gdjs.StageCode.GDBrainSpawnLEFTObjects2= [];
gdjs.StageCode.GDBrainSpawnLEFTObjects3= [];
gdjs.StageCode.GDBrainSpawnLEFTObjects4= [];
gdjs.StageCode.GDBrainSpawnLEFTObjects5= [];
gdjs.StageCode.GDBrainSpawnLEFTObjects6= [];
gdjs.StageCode.GDBrainSpawnLEFTObjects7= [];
gdjs.StageCode.GDBrainSpawnLEFTObjects8= [];
gdjs.StageCode.GDBrainSpawnLEFTObjects9= [];
gdjs.StageCode.GDDeleteBrainLEFTObjects1= [];
gdjs.StageCode.GDDeleteBrainLEFTObjects2= [];
gdjs.StageCode.GDDeleteBrainLEFTObjects3= [];
gdjs.StageCode.GDDeleteBrainLEFTObjects4= [];
gdjs.StageCode.GDDeleteBrainLEFTObjects5= [];
gdjs.StageCode.GDDeleteBrainLEFTObjects6= [];
gdjs.StageCode.GDDeleteBrainLEFTObjects7= [];
gdjs.StageCode.GDDeleteBrainLEFTObjects8= [];
gdjs.StageCode.GDDeleteBrainLEFTObjects9= [];
gdjs.StageCode.GDScoreObjects1= [];
gdjs.StageCode.GDScoreObjects2= [];
gdjs.StageCode.GDScoreObjects3= [];
gdjs.StageCode.GDScoreObjects4= [];
gdjs.StageCode.GDScoreObjects5= [];
gdjs.StageCode.GDScoreObjects6= [];
gdjs.StageCode.GDScoreObjects7= [];
gdjs.StageCode.GDScoreObjects8= [];
gdjs.StageCode.GDScoreObjects9= [];
gdjs.StageCode.GDNo_9595Go_9595ZoneObjects1= [];
gdjs.StageCode.GDNo_9595Go_9595ZoneObjects2= [];
gdjs.StageCode.GDNo_9595Go_9595ZoneObjects3= [];
gdjs.StageCode.GDNo_9595Go_9595ZoneObjects4= [];
gdjs.StageCode.GDNo_9595Go_9595ZoneObjects5= [];
gdjs.StageCode.GDNo_9595Go_9595ZoneObjects6= [];
gdjs.StageCode.GDNo_9595Go_9595ZoneObjects7= [];
gdjs.StageCode.GDNo_9595Go_9595ZoneObjects8= [];
gdjs.StageCode.GDNo_9595Go_9595ZoneObjects9= [];
gdjs.StageCode.GDBrain_9595ScoreObjects1= [];
gdjs.StageCode.GDBrain_9595ScoreObjects2= [];
gdjs.StageCode.GDBrain_9595ScoreObjects3= [];
gdjs.StageCode.GDBrain_9595ScoreObjects4= [];
gdjs.StageCode.GDBrain_9595ScoreObjects5= [];
gdjs.StageCode.GDBrain_9595ScoreObjects6= [];
gdjs.StageCode.GDBrain_9595ScoreObjects7= [];
gdjs.StageCode.GDBrain_9595ScoreObjects8= [];
gdjs.StageCode.GDBrain_9595ScoreObjects9= [];
gdjs.StageCode.GDGolden_9595BrainObjects1= [];
gdjs.StageCode.GDGolden_9595BrainObjects2= [];
gdjs.StageCode.GDGolden_9595BrainObjects3= [];
gdjs.StageCode.GDGolden_9595BrainObjects4= [];
gdjs.StageCode.GDGolden_9595BrainObjects5= [];
gdjs.StageCode.GDGolden_9595BrainObjects6= [];
gdjs.StageCode.GDGolden_9595BrainObjects7= [];
gdjs.StageCode.GDGolden_9595BrainObjects8= [];
gdjs.StageCode.GDGolden_9595BrainObjects9= [];
gdjs.StageCode.GDEdge_9595LObjects1= [];
gdjs.StageCode.GDEdge_9595LObjects2= [];
gdjs.StageCode.GDEdge_9595LObjects3= [];
gdjs.StageCode.GDEdge_9595LObjects4= [];
gdjs.StageCode.GDEdge_9595LObjects5= [];
gdjs.StageCode.GDEdge_9595LObjects6= [];
gdjs.StageCode.GDEdge_9595LObjects7= [];
gdjs.StageCode.GDEdge_9595LObjects8= [];
gdjs.StageCode.GDEdge_9595LObjects9= [];
gdjs.StageCode.GDEdge_9595RObjects1= [];
gdjs.StageCode.GDEdge_9595RObjects2= [];
gdjs.StageCode.GDEdge_9595RObjects3= [];
gdjs.StageCode.GDEdge_9595RObjects4= [];
gdjs.StageCode.GDEdge_9595RObjects5= [];
gdjs.StageCode.GDEdge_9595RObjects6= [];
gdjs.StageCode.GDEdge_9595RObjects7= [];
gdjs.StageCode.GDEdge_9595RObjects8= [];
gdjs.StageCode.GDEdge_9595RObjects9= [];
gdjs.StageCode.GDRockSpawnObjects1= [];
gdjs.StageCode.GDRockSpawnObjects2= [];
gdjs.StageCode.GDRockSpawnObjects3= [];
gdjs.StageCode.GDRockSpawnObjects4= [];
gdjs.StageCode.GDRockSpawnObjects5= [];
gdjs.StageCode.GDRockSpawnObjects6= [];
gdjs.StageCode.GDRockSpawnObjects7= [];
gdjs.StageCode.GDRockSpawnObjects8= [];
gdjs.StageCode.GDRockSpawnObjects9= [];
gdjs.StageCode.GDRockObjects1= [];
gdjs.StageCode.GDRockObjects2= [];
gdjs.StageCode.GDRockObjects3= [];
gdjs.StageCode.GDRockObjects4= [];
gdjs.StageCode.GDRockObjects5= [];
gdjs.StageCode.GDRockObjects6= [];
gdjs.StageCode.GDRockObjects7= [];
gdjs.StageCode.GDRockObjects8= [];
gdjs.StageCode.GDRockObjects9= [];
gdjs.StageCode.GDRock_9595StopObjects1= [];
gdjs.StageCode.GDRock_9595StopObjects2= [];
gdjs.StageCode.GDRock_9595StopObjects3= [];
gdjs.StageCode.GDRock_9595StopObjects4= [];
gdjs.StageCode.GDRock_9595StopObjects5= [];
gdjs.StageCode.GDRock_9595StopObjects6= [];
gdjs.StageCode.GDRock_9595StopObjects7= [];
gdjs.StageCode.GDRock_9595StopObjects8= [];
gdjs.StageCode.GDRock_9595StopObjects9= [];
gdjs.StageCode.GDPermanent_9595RockObjects1= [];
gdjs.StageCode.GDPermanent_9595RockObjects2= [];
gdjs.StageCode.GDPermanent_9595RockObjects3= [];
gdjs.StageCode.GDPermanent_9595RockObjects4= [];
gdjs.StageCode.GDPermanent_9595RockObjects5= [];
gdjs.StageCode.GDPermanent_9595RockObjects6= [];
gdjs.StageCode.GDPermanent_9595RockObjects7= [];
gdjs.StageCode.GDPermanent_9595RockObjects8= [];
gdjs.StageCode.GDPermanent_9595RockObjects9= [];
gdjs.StageCode.GDBottom_9595BorderObjects1= [];
gdjs.StageCode.GDBottom_9595BorderObjects2= [];
gdjs.StageCode.GDBottom_9595BorderObjects3= [];
gdjs.StageCode.GDBottom_9595BorderObjects4= [];
gdjs.StageCode.GDBottom_9595BorderObjects5= [];
gdjs.StageCode.GDBottom_9595BorderObjects6= [];
gdjs.StageCode.GDBottom_9595BorderObjects7= [];
gdjs.StageCode.GDBottom_9595BorderObjects8= [];
gdjs.StageCode.GDBottom_9595BorderObjects9= [];
gdjs.StageCode.GDSpawner_9595DeleteObjects1= [];
gdjs.StageCode.GDSpawner_9595DeleteObjects2= [];
gdjs.StageCode.GDSpawner_9595DeleteObjects3= [];
gdjs.StageCode.GDSpawner_9595DeleteObjects4= [];
gdjs.StageCode.GDSpawner_9595DeleteObjects5= [];
gdjs.StageCode.GDSpawner_9595DeleteObjects6= [];
gdjs.StageCode.GDSpawner_9595DeleteObjects7= [];
gdjs.StageCode.GDSpawner_9595DeleteObjects8= [];
gdjs.StageCode.GDSpawner_9595DeleteObjects9= [];
gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects1= [];
gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects2= [];
gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects3= [];
gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects4= [];
gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects5= [];
gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects6= [];
gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects7= [];
gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects8= [];
gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects9= [];
gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects1= [];
gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects2= [];
gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects3= [];
gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects4= [];
gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects5= [];
gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects6= [];
gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects7= [];
gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects8= [];
gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects9= [];
gdjs.StageCode.GDZombie_9595GerbilObjects1= [];
gdjs.StageCode.GDZombie_9595GerbilObjects2= [];
gdjs.StageCode.GDZombie_9595GerbilObjects3= [];
gdjs.StageCode.GDZombie_9595GerbilObjects4= [];
gdjs.StageCode.GDZombie_9595GerbilObjects5= [];
gdjs.StageCode.GDZombie_9595GerbilObjects6= [];
gdjs.StageCode.GDZombie_9595GerbilObjects7= [];
gdjs.StageCode.GDZombie_9595GerbilObjects8= [];
gdjs.StageCode.GDZombie_9595GerbilObjects9= [];
gdjs.StageCode.GDLeft_9595Above_9595GroundObjects1= [];
gdjs.StageCode.GDLeft_9595Above_9595GroundObjects2= [];
gdjs.StageCode.GDLeft_9595Above_9595GroundObjects3= [];
gdjs.StageCode.GDLeft_9595Above_9595GroundObjects4= [];
gdjs.StageCode.GDLeft_9595Above_9595GroundObjects5= [];
gdjs.StageCode.GDLeft_9595Above_9595GroundObjects6= [];
gdjs.StageCode.GDLeft_9595Above_9595GroundObjects7= [];
gdjs.StageCode.GDLeft_9595Above_9595GroundObjects8= [];
gdjs.StageCode.GDLeft_9595Above_9595GroundObjects9= [];
gdjs.StageCode.GDRight_9595Above_9595GroundObjects1= [];
gdjs.StageCode.GDRight_9595Above_9595GroundObjects2= [];
gdjs.StageCode.GDRight_9595Above_9595GroundObjects3= [];
gdjs.StageCode.GDRight_9595Above_9595GroundObjects4= [];
gdjs.StageCode.GDRight_9595Above_9595GroundObjects5= [];
gdjs.StageCode.GDRight_9595Above_9595GroundObjects6= [];
gdjs.StageCode.GDRight_9595Above_9595GroundObjects7= [];
gdjs.StageCode.GDRight_9595Above_9595GroundObjects8= [];
gdjs.StageCode.GDRight_9595Above_9595GroundObjects9= [];
gdjs.StageCode.GDTimerObjects1= [];
gdjs.StageCode.GDTimerObjects2= [];
gdjs.StageCode.GDTimerObjects3= [];
gdjs.StageCode.GDTimerObjects4= [];
gdjs.StageCode.GDTimerObjects5= [];
gdjs.StageCode.GDTimerObjects6= [];
gdjs.StageCode.GDTimerObjects7= [];
gdjs.StageCode.GDTimerObjects8= [];
gdjs.StageCode.GDTimerObjects9= [];
gdjs.StageCode.GDDeleteBrainRIGHTObjects1= [];
gdjs.StageCode.GDDeleteBrainRIGHTObjects2= [];
gdjs.StageCode.GDDeleteBrainRIGHTObjects3= [];
gdjs.StageCode.GDDeleteBrainRIGHTObjects4= [];
gdjs.StageCode.GDDeleteBrainRIGHTObjects5= [];
gdjs.StageCode.GDDeleteBrainRIGHTObjects6= [];
gdjs.StageCode.GDDeleteBrainRIGHTObjects7= [];
gdjs.StageCode.GDDeleteBrainRIGHTObjects8= [];
gdjs.StageCode.GDDeleteBrainRIGHTObjects9= [];
gdjs.StageCode.GDBrainSpawnRIGHTObjects1= [];
gdjs.StageCode.GDBrainSpawnRIGHTObjects2= [];
gdjs.StageCode.GDBrainSpawnRIGHTObjects3= [];
gdjs.StageCode.GDBrainSpawnRIGHTObjects4= [];
gdjs.StageCode.GDBrainSpawnRIGHTObjects5= [];
gdjs.StageCode.GDBrainSpawnRIGHTObjects6= [];
gdjs.StageCode.GDBrainSpawnRIGHTObjects7= [];
gdjs.StageCode.GDBrainSpawnRIGHTObjects8= [];
gdjs.StageCode.GDBrainSpawnRIGHTObjects9= [];
gdjs.StageCode.GDBurrowObjects1= [];
gdjs.StageCode.GDBurrowObjects2= [];
gdjs.StageCode.GDBurrowObjects3= [];
gdjs.StageCode.GDBurrowObjects4= [];
gdjs.StageCode.GDBurrowObjects5= [];
gdjs.StageCode.GDBurrowObjects6= [];
gdjs.StageCode.GDBurrowObjects7= [];
gdjs.StageCode.GDBurrowObjects8= [];
gdjs.StageCode.GDBurrowObjects9= [];
gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects1= [];
gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects2= [];
gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects3= [];
gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects4= [];
gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects5= [];
gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects6= [];
gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects7= [];
gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects8= [];
gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects9= [];
gdjs.StageCode.GDSkyObjects1= [];
gdjs.StageCode.GDSkyObjects2= [];
gdjs.StageCode.GDSkyObjects3= [];
gdjs.StageCode.GDSkyObjects4= [];
gdjs.StageCode.GDSkyObjects5= [];
gdjs.StageCode.GDSkyObjects6= [];
gdjs.StageCode.GDSkyObjects7= [];
gdjs.StageCode.GDSkyObjects8= [];
gdjs.StageCode.GDSkyObjects9= [];
gdjs.StageCode.GDJerry_9595LogoObjects1= [];
gdjs.StageCode.GDJerry_9595LogoObjects2= [];
gdjs.StageCode.GDJerry_9595LogoObjects3= [];
gdjs.StageCode.GDJerry_9595LogoObjects4= [];
gdjs.StageCode.GDJerry_9595LogoObjects5= [];
gdjs.StageCode.GDJerry_9595LogoObjects6= [];
gdjs.StageCode.GDJerry_9595LogoObjects7= [];
gdjs.StageCode.GDJerry_9595LogoObjects8= [];
gdjs.StageCode.GDJerry_9595LogoObjects9= [];
gdjs.StageCode.GDBrains_9595EatenObjects1= [];
gdjs.StageCode.GDBrains_9595EatenObjects2= [];
gdjs.StageCode.GDBrains_9595EatenObjects3= [];
gdjs.StageCode.GDBrains_9595EatenObjects4= [];
gdjs.StageCode.GDBrains_9595EatenObjects5= [];
gdjs.StageCode.GDBrains_9595EatenObjects6= [];
gdjs.StageCode.GDBrains_9595EatenObjects7= [];
gdjs.StageCode.GDBrains_9595EatenObjects8= [];
gdjs.StageCode.GDBrains_9595EatenObjects9= [];
gdjs.StageCode.GDTransitionObjects1= [];
gdjs.StageCode.GDTransitionObjects2= [];
gdjs.StageCode.GDTransitionObjects3= [];
gdjs.StageCode.GDTransitionObjects4= [];
gdjs.StageCode.GDTransitionObjects5= [];
gdjs.StageCode.GDTransitionObjects6= [];
gdjs.StageCode.GDTransitionObjects7= [];
gdjs.StageCode.GDTransitionObjects8= [];
gdjs.StageCode.GDTransitionObjects9= [];
gdjs.StageCode.GDHigh_9595ScoreObjects1= [];
gdjs.StageCode.GDHigh_9595ScoreObjects2= [];
gdjs.StageCode.GDHigh_9595ScoreObjects3= [];
gdjs.StageCode.GDHigh_9595ScoreObjects4= [];
gdjs.StageCode.GDHigh_9595ScoreObjects5= [];
gdjs.StageCode.GDHigh_9595ScoreObjects6= [];
gdjs.StageCode.GDHigh_9595ScoreObjects7= [];
gdjs.StageCode.GDHigh_9595ScoreObjects8= [];
gdjs.StageCode.GDHigh_9595ScoreObjects9= [];
gdjs.StageCode.GDRocks_9595DestroyedObjects1= [];
gdjs.StageCode.GDRocks_9595DestroyedObjects2= [];
gdjs.StageCode.GDRocks_9595DestroyedObjects3= [];
gdjs.StageCode.GDRocks_9595DestroyedObjects4= [];
gdjs.StageCode.GDRocks_9595DestroyedObjects5= [];
gdjs.StageCode.GDRocks_9595DestroyedObjects6= [];
gdjs.StageCode.GDRocks_9595DestroyedObjects7= [];
gdjs.StageCode.GDRocks_9595DestroyedObjects8= [];
gdjs.StageCode.GDRocks_9595DestroyedObjects9= [];
gdjs.StageCode.GDGames_9595PlayedObjects1= [];
gdjs.StageCode.GDGames_9595PlayedObjects2= [];
gdjs.StageCode.GDGames_9595PlayedObjects3= [];
gdjs.StageCode.GDGames_9595PlayedObjects4= [];
gdjs.StageCode.GDGames_9595PlayedObjects5= [];
gdjs.StageCode.GDGames_9595PlayedObjects6= [];
gdjs.StageCode.GDGames_9595PlayedObjects7= [];
gdjs.StageCode.GDGames_9595PlayedObjects8= [];
gdjs.StageCode.GDGames_9595PlayedObjects9= [];


gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects3Objects = Hashtable.newFrom({"Jerry_Character": gdjs.StageCode.GDJerry_9595CharacterObjects3});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDEdge_95959595RObjects3Objects = Hashtable.newFrom({"Edge_R": gdjs.StageCode.GDEdge_9595RObjects3});
gdjs.StageCode.asyncCallback15335628 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects4);

{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects4.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects4[i].setX(gdjs.StageCode.GDJerry_9595CharacterObjects4[i].getX() + (192));
}
}{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects4.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects4[i].getBehavior("Flippable").flipX(false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 1.aac", false, 100, 1);
}}
gdjs.StageCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.StageCode.GDJerry_9595CharacterObjects3) asyncObjectsList.addObject("Jerry_Character", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.StageCode.asyncCallback15335628(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.StageCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Edge_R"), gdjs.StageCode.GDEdge_9595RObjects3);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects3Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDEdge_95959595RObjects3Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects3.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects3[i].getY() == 832 ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects3[k] = gdjs.StageCode.GDJerry_9595CharacterObjects3[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15335484);
}
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.StageCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects3Objects = Hashtable.newFrom({"Jerry_Character": gdjs.StageCode.GDJerry_9595CharacterObjects3});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDEdge_95959595LObjects3Objects = Hashtable.newFrom({"Edge_L": gdjs.StageCode.GDEdge_9595LObjects3});
gdjs.StageCode.asyncCallback15338124 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects4);

{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects4.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects4[i].setX(gdjs.StageCode.GDJerry_9595CharacterObjects4[i].getX() - (192));
}
}{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects4.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects4[i].getBehavior("Flippable").flipX(true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 1.aac", false, 100, 1);
}}
gdjs.StageCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.StageCode.GDJerry_9595CharacterObjects3) asyncObjectsList.addObject("Jerry_Character", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.StageCode.asyncCallback15338124(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.StageCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Edge_L"), gdjs.StageCode.GDEdge_9595LObjects3);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects3Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDEdge_95959595LObjects3Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects3.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects3[i].getY() == 832 ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects3[k] = gdjs.StageCode.GDJerry_9595CharacterObjects3[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15337980);
}
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.StageCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects3Objects = Hashtable.newFrom({"Jerry_Character": gdjs.StageCode.GDJerry_9595CharacterObjects3});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJump_95959595TileObjects3Objects = Hashtable.newFrom({"Jump_Tile": gdjs.StageCode.GDJump_9595TileObjects3});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects2Objects = Hashtable.newFrom({"Jerry_Character": gdjs.StageCode.GDJerry_9595CharacterObjects2});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDTileObjects2Objects = Hashtable.newFrom({"Tile": gdjs.StageCode.GDTileObjects2});
gdjs.StageCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Jump_Tile"), gdjs.StageCode.GDJump_9595TileObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects3.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects3[i].getY() == 832 ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects3[k] = gdjs.StageCode.GDJerry_9595CharacterObjects3[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects3Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJump_95959595TileObjects3Objects, false, runtimeScene, false);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects3 */
{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects3[i].getBehavior("Animation").setAnimationName("Walk");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tile"), gdjs.StageCode.GDTileObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects2.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects2[i].getY() == 832 ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects2[k] = gdjs.StageCode.GDJerry_9595CharacterObjects2[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects2Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDTileObjects2Objects, false, runtimeScene, false);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects2 */
{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects2[i].getBehavior("Animation").setAnimationName("Idle");
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


};gdjs.StageCode.eventsList5 = function(runtimeScene) {

{


gdjs.StageCode.eventsList1(runtimeScene);
}


{


gdjs.StageCode.eventsList3(runtimeScene);
}


{


gdjs.StageCode.eventsList4(runtimeScene);
}


};gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects2Objects = Hashtable.newFrom({"Jerry_Character": gdjs.StageCode.GDJerry_9595CharacterObjects2});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJump_95959595TileObjects2Objects = Hashtable.newFrom({"Jump_Tile": gdjs.StageCode.GDJump_9595TileObjects2});
gdjs.StageCode.asyncCallback15353668 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects9);

{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects9.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects9[i].setY(gdjs.StageCode.GDJerry_9595CharacterObjects9[i].getY() + (192));
}
}}
gdjs.StageCode.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.StageCode.GDJerry_9595CharacterObjects8) asyncObjectsList.addObject("Jerry_Character", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.StageCode.asyncCallback15353668(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.StageCode.eventsList7 = function(runtimeScene, asyncObjectsList) {

{

/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects8 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects8.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects8[i].getVariableBoolean(gdjs.StageCode.GDJerry_9595CharacterObjects8[i].getVariables().getFromIndex(0), false) ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects8[k] = gdjs.StageCode.GDJerry_9595CharacterObjects8[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects8.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.StageCode.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.StageCode.asyncCallback15352660 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects8);

{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects8.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects8[i].setY(gdjs.StageCode.GDJerry_9595CharacterObjects8[i].getY() + (192));
}
}
{ //Subevents
gdjs.StageCode.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.StageCode.eventsList8 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.StageCode.GDJerry_9595CharacterObjects7) asyncObjectsList.addObject("Jerry_Character", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.StageCode.asyncCallback15352660(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.StageCode.eventsList9 = function(runtimeScene, asyncObjectsList) {

{

/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects7 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects7.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects7[i].getVariableBoolean(gdjs.StageCode.GDJerry_9595CharacterObjects7[i].getVariables().getFromIndex(0), false) ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects7[k] = gdjs.StageCode.GDJerry_9595CharacterObjects7[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects7.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.StageCode.eventsList8(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.StageCode.asyncCallback15352020 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects7);

{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects7.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects7[i].setY(gdjs.StageCode.GDJerry_9595CharacterObjects7[i].getY() + (192));
}
}
{ //Subevents
gdjs.StageCode.eventsList9(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.StageCode.eventsList10 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.StageCode.GDJerry_9595CharacterObjects6) asyncObjectsList.addObject("Jerry_Character", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.StageCode.asyncCallback15352020(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.StageCode.eventsList11 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.StageCode.GDJerry_9595CharacterObjects6, gdjs.StageCode.GDJerry_9595CharacterObjects7);

{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects7.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects7[i].getBehavior("Animation").setAnimationName("Fall Satisfied");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.StageCode.GDJerry_9595CharacterObjects6, gdjs.StageCode.GDJerry_9595CharacterObjects7);

{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects7.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects7[i].getBehavior("Animation").setAnimationName("Fall");
}
}}

}


{

/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects6 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects6.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects6[i].getVariableBoolean(gdjs.StageCode.GDJerry_9595CharacterObjects6[i].getVariables().getFromIndex(0), false) ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects6[k] = gdjs.StageCode.GDJerry_9595CharacterObjects6[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects6.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.StageCode.eventsList10(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.StageCode.asyncCallback15348764 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects6);

{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects6.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects6[i].setY(gdjs.StageCode.GDJerry_9595CharacterObjects6[i].getY() + (192));
}
}
{ //Subevents
gdjs.StageCode.eventsList11(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.StageCode.eventsList12 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.StageCode.GDJerry_9595CharacterObjects5) asyncObjectsList.addObject("Jerry_Character", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.StageCode.asyncCallback15348764(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.StageCode.eventsList13 = function(runtimeScene, asyncObjectsList) {

{

/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects5 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects5.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects5[i].getVariableBoolean(gdjs.StageCode.GDJerry_9595CharacterObjects5[i].getVariables().getFromIndex(0), false) ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects5[k] = gdjs.StageCode.GDJerry_9595CharacterObjects5[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects5.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.StageCode.eventsList12(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.StageCode.asyncCallback15347756 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects5);

{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects5.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects5[i].setY(gdjs.StageCode.GDJerry_9595CharacterObjects5[i].getY() - (192));
}
}
{ //Subevents
gdjs.StageCode.eventsList13(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.StageCode.eventsList14 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.StageCode.GDJerry_9595CharacterObjects4) asyncObjectsList.addObject("Jerry_Character", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.StageCode.asyncCallback15347756(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.StageCode.eventsList15 = function(runtimeScene, asyncObjectsList) {

{

/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects4.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects4[i].getVariableBoolean(gdjs.StageCode.GDJerry_9595CharacterObjects4[i].getVariables().getFromIndex(0), false) ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects4[k] = gdjs.StageCode.GDJerry_9595CharacterObjects4[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects4.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.StageCode.eventsList14(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.StageCode.asyncCallback15346748 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects4);

{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects4.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects4[i].setY(gdjs.StageCode.GDJerry_9595CharacterObjects4[i].getY() - (192));
}
}
{ //Subevents
gdjs.StageCode.eventsList15(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.StageCode.eventsList16 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.StageCode.GDJerry_9595CharacterObjects3) asyncObjectsList.addObject("Jerry_Character", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.StageCode.asyncCallback15346748(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.StageCode.eventsList17 = function(runtimeScene, asyncObjectsList) {

{

/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects3.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects3[i].getVariableBoolean(gdjs.StageCode.GDJerry_9595CharacterObjects3[i].getVariables().getFromIndex(0), false) ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects3[k] = gdjs.StageCode.GDJerry_9595CharacterObjects3[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects3.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.StageCode.eventsList16(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.StageCode.asyncCallback15346108 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects3);

{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects3[i].setY(gdjs.StageCode.GDJerry_9595CharacterObjects3[i].getY() - (192));
}
}
{ //Subevents
gdjs.StageCode.eventsList17(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.StageCode.eventsList18 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.StageCode.GDJerry_9595CharacterObjects2) asyncObjectsList.addObject("Jerry_Character", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.StageCode.asyncCallback15346108(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.StageCode.eventsList19 = function(runtimeScene) {

{

/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects2.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects2[i].getVariableBoolean(gdjs.StageCode.GDJerry_9595CharacterObjects2[i].getVariables().getFromIndex(0), false) ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects2[k] = gdjs.StageCode.GDJerry_9595CharacterObjects2[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects2.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.StageCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.StageCode.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jump_Tile"), gdjs.StageCode.GDJump_9595TileObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects2.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects2[i].getY() == 832 ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects2[k] = gdjs.StageCode.GDJerry_9595CharacterObjects2[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects2Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJump_95959595TileObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
{let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
isConditionTrue_2 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
isConditionTrue_2 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "a"));
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
isConditionTrue_2 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right"));
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
isConditionTrue_2 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "d"));
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15343940);
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects2 */
{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects2[i].setY(gdjs.StageCode.GDJerry_9595CharacterObjects2[i].getY() - (192));
}
}{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects2[i].getBehavior("Animation").setAnimationName("Jump");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 1.aac", false, 100, 1);
}
{ //Subevents
gdjs.StageCode.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.StageCode.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects2.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects2[i].getX() == -(96) ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects2[k] = gdjs.StageCode.GDJerry_9595CharacterObjects2[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects2 */
{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects2[i].setX(96);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects1.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects1[i].getX() == 1824 ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects1[k] = gdjs.StageCode.GDJerry_9595CharacterObjects1[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects1 */
{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects1.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects1[i].setX(1632);
}
}}

}


};gdjs.StageCode.eventsList22 = function(runtimeScene) {

{


gdjs.StageCode.eventsList5(runtimeScene);
}


{


gdjs.StageCode.eventsList20(runtimeScene);
}


{


gdjs.StageCode.eventsList21(runtimeScene);
}


};gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects1Objects = Hashtable.newFrom({"Jerry_Character": gdjs.StageCode.GDJerry_9595CharacterObjects1});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDPermanent_95959595RockObjects1Objects = Hashtable.newFrom({"Permanent_Rock": gdjs.StageCode.GDPermanent_9595RockObjects1});
gdjs.StageCode.eventsList23 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects4 */
{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects4.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects4[i].setVariableBoolean(gdjs.StageCode.GDJerry_9595CharacterObjects4[i].getVariables().getFromIndex(0), false);
}
}}

}


};gdjs.StageCode.asyncCallback15359244 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects4);

{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects4.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects4[i].setY(gdjs.StageCode.GDJerry_9595CharacterObjects4[i].getY() + (192));
}
}
{ //Subevents
gdjs.StageCode.eventsList23(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.StageCode.eventsList24 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.StageCode.GDJerry_9595CharacterObjects3) asyncObjectsList.addObject("Jerry_Character", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.StageCode.asyncCallback15359244(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.StageCode.eventsList25 = function(runtimeScene, asyncObjectsList) {

{

/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects3.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects3[i].getVariableBoolean(gdjs.StageCode.GDJerry_9595CharacterObjects3[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects3[k] = gdjs.StageCode.GDJerry_9595CharacterObjects3[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.StageCode.eventsList24(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.StageCode.asyncCallback15358196 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects3);

{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects3[i].setY(gdjs.StageCode.GDJerry_9595CharacterObjects3[i].getY() + (192));
}
}
{ //Subevents
gdjs.StageCode.eventsList25(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.StageCode.eventsList26 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.StageCode.GDJerry_9595CharacterObjects2) asyncObjectsList.addObject("Jerry_Character", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.StageCode.asyncCallback15358196(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.StageCode.eventsList27 = function(runtimeScene, asyncObjectsList) {

{

/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects2.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects2[i].getVariableBoolean(gdjs.StageCode.GDJerry_9595CharacterObjects2[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects2[k] = gdjs.StageCode.GDJerry_9595CharacterObjects2[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.StageCode.eventsList26(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.StageCode.asyncCallback15356204 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects2);

{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects2[i].setY(gdjs.StageCode.GDJerry_9595CharacterObjects2[i].getY() + (192));
}
}
{ //Subevents
gdjs.StageCode.eventsList27(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.StageCode.eventsList28 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.StageCode.GDJerry_9595CharacterObjects1) asyncObjectsList.addObject("Jerry_Character", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.StageCode.asyncCallback15356204(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.StageCode.eventsList29 = function(runtimeScene) {

{

/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects1.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects1[i].getVariableBoolean(gdjs.StageCode.GDJerry_9595CharacterObjects1[i].getVariables().getFromIndex(0), true) ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects1[k] = gdjs.StageCode.GDJerry_9595CharacterObjects1[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.StageCode.eventsList28(runtimeScene);} //End of subevents
}

}


};gdjs.StageCode.eventsList30 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Permanent_Rock"), gdjs.StageCode.GDPermanent_9595RockObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects1Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDPermanent_95959595RockObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15355716);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects1 */
{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects1.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects1[i].setVariableBoolean(gdjs.StageCode.GDJerry_9595CharacterObjects1[i].getVariables().getFromIndex(0), true);
}
}
{ //Subevents
gdjs.StageCode.eventsList29(runtimeScene);} //End of subevents
}

}


};gdjs.StageCode.eventsList31 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15360356);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects1);
{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects1.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects1[i].getBehavior("Animation").setAnimationName("Death");
}
}{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects1.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects1[i].getBehavior("Flippable").flipX(false);
}
}}

}


};gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects1Objects = Hashtable.newFrom({"Regular_Brain": gdjs.StageCode.GDRegular_9595BrainObjects1});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDPermanent_95959595RockObjects1Objects = Hashtable.newFrom({"Permanent_Rock": gdjs.StageCode.GDPermanent_9595RockObjects1});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects1Objects = Hashtable.newFrom({"Jerry_Character": gdjs.StageCode.GDJerry_9595CharacterObjects1});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects1Objects = Hashtable.newFrom({"Regular_Brain": gdjs.StageCode.GDRegular_9595BrainObjects1});
gdjs.StageCode.asyncCallback15364596 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Regular_Brain"), gdjs.StageCode.GDRegular_9595BrainObjects2);

{for(var i = 0, len = gdjs.StageCode.GDRegular_9595BrainObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDRegular_9595BrainObjects2[i].deleteFromScene(runtimeScene);
}
}}
gdjs.StageCode.eventsList32 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.StageCode.GDRegular_9595BrainObjects1) asyncObjectsList.addObject("Regular_Brain", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.StageCode.asyncCallback15364596(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.StageCode.eventsList33 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects1 */
{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects1.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects1[i].getBehavior("Animation").setAnimationName("Eat");
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).add(1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 2.aac", false, 100, 1);
}
{ //Subevents
gdjs.StageCode.eventsList32(runtimeScene);} //End of subevents
}

}


};gdjs.StageCode.eventsList34 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Permanent_Rock"), gdjs.StageCode.GDPermanent_9595RockObjects1);
gdjs.copyArray(runtimeScene.getObjects("Regular_Brain"), gdjs.StageCode.GDRegular_9595BrainObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects1Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDPermanent_95959595RockObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects1Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.StageCode.GDJerry_9595CharacterObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.StageCode.GDJerry_9595CharacterObjects1, gdjs.StageCode.GDJerry_9595CharacterObjects2);

for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects2.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects2[i].getY() == 256 ) {
        isConditionTrue_1 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects2[k] = gdjs.StageCode.GDJerry_9595CharacterObjects2[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.StageCode.GDJerry_9595CharacterObjects2.length; j < jLen ; ++j) {
        if ( gdjs.StageCode.GDJerry_9595CharacterObjects1_1final.indexOf(gdjs.StageCode.GDJerry_9595CharacterObjects2[j]) === -1 )
            gdjs.StageCode.GDJerry_9595CharacterObjects1_1final.push(gdjs.StageCode.GDJerry_9595CharacterObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.StageCode.GDJerry_9595CharacterObjects1, gdjs.StageCode.GDJerry_9595CharacterObjects2);

for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects2.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects2[i].getY() == 64 ) {
        isConditionTrue_1 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects2[k] = gdjs.StageCode.GDJerry_9595CharacterObjects2[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.StageCode.GDJerry_9595CharacterObjects2.length; j < jLen ; ++j) {
        if ( gdjs.StageCode.GDJerry_9595CharacterObjects1_1final.indexOf(gdjs.StageCode.GDJerry_9595CharacterObjects2[j]) === -1 )
            gdjs.StageCode.GDJerry_9595CharacterObjects1_1final.push(gdjs.StageCode.GDJerry_9595CharacterObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.StageCode.GDJerry_9595CharacterObjects1_1final, gdjs.StageCode.GDJerry_9595CharacterObjects1);
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
}
{ //Subevents
gdjs.StageCode.eventsList33(runtimeScene);} //End of subevents
}

}


};gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects1Objects = Hashtable.newFrom({"Jerry_Character": gdjs.StageCode.GDJerry_9595CharacterObjects1});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRockObjects1Objects = Hashtable.newFrom({"Rock": gdjs.StageCode.GDRockObjects1});
gdjs.StageCode.asyncCallback15366372 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Rock"), gdjs.StageCode.GDRockObjects2);

{for(var i = 0, len = gdjs.StageCode.GDRockObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDRockObjects2[i].deleteFromScene(runtimeScene);
}
}}
gdjs.StageCode.eventsList35 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.StageCode.GDRockObjects1) asyncObjectsList.addObject("Rock", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.StageCode.asyncCallback15366372(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.StageCode.eventsList36 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(2).add(1);
}
{ //Subevents
gdjs.StageCode.eventsList35(runtimeScene);} //End of subevents
}

}


};gdjs.StageCode.eventsList37 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rock"), gdjs.StageCode.GDRockObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects1Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRockObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15365252);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDRockObjects1 */
{for(var i = 0, len = gdjs.StageCode.GDRockObjects1.length ;i < len;++i) {
    gdjs.StageCode.GDRockObjects1[i].getBehavior("Animation").setAnimationName("Broken");
}
}
{ //Subevents
gdjs.StageCode.eventsList36(runtimeScene);} //End of subevents
}

}


};gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects1Objects = Hashtable.newFrom({"Jerry_Character": gdjs.StageCode.GDJerry_9595CharacterObjects1});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJump_95959595TileObjects1Objects = Hashtable.newFrom({"Jump_Tile": gdjs.StageCode.GDJump_9595TileObjects1});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects1Objects = Hashtable.newFrom({"Jerry_Character": gdjs.StageCode.GDJerry_9595CharacterObjects1});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDTileObjects1Objects = Hashtable.newFrom({"Tile": gdjs.StageCode.GDTileObjects1});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDTileObjects1Objects = Hashtable.newFrom({"Tile": gdjs.StageCode.GDTileObjects1});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects2Objects = Hashtable.newFrom({"Jerry_Character": gdjs.StageCode.GDJerry_9595CharacterObjects2});
gdjs.StageCode.asyncCallback15368956 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Tile"), gdjs.StageCode.GDTileObjects2);

gdjs.copyArray(asyncObjectsList.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects2);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects2Objects, (( gdjs.StageCode.GDTileObjects2.length === 0 ) ? 0 :gdjs.StageCode.GDTileObjects2[0].getPointX("")), (( gdjs.StageCode.GDTileObjects2.length === 0 ) ? 0 :gdjs.StageCode.GDTileObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects2[i].getBehavior("Resizable").setSize(192, 192);
}
}}
gdjs.StageCode.eventsList38 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.StageCode.GDJerry_9595CharacterObjects1) asyncObjectsList.addObject("Jerry_Character", obj);
for (const obj of gdjs.StageCode.GDTileObjects1) asyncObjectsList.addObject("Tile", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.StageCode.asyncCallback15368956(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.StageCode.eventsList39 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.StageCode.eventsList38(runtimeScene);} //End of subevents
}

}


};gdjs.StageCode.eventsList40 = function(runtimeScene) {

{

/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects1 */
/* Reuse gdjs.StageCode.GDTileObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickNearestObject(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDTileObjects1Objects, (( gdjs.StageCode.GDJerry_9595CharacterObjects1.length === 0 ) ? 0 :gdjs.StageCode.GDJerry_9595CharacterObjects1[0].getPointX("")), (( gdjs.StageCode.GDJerry_9595CharacterObjects1.length === 0 ) ? 0 :gdjs.StageCode.GDJerry_9595CharacterObjects1[0].getPointY("")), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15368004);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDJerry_9595CharacterObjects1 */
{for(var i = 0, len = gdjs.StageCode.GDJerry_9595CharacterObjects1.length ;i < len;++i) {
    gdjs.StageCode.GDJerry_9595CharacterObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.StageCode.eventsList39(runtimeScene);} //End of subevents
}

}


};gdjs.StageCode.eventsList41 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Jump_Tile"), gdjs.StageCode.GDJump_9595TileObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tile"), gdjs.StageCode.GDTileObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects1Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJump_95959595TileObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects1Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDTileObjects1Objects, true, runtimeScene, false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.StageCode.eventsList40(runtimeScene);} //End of subevents
}

}


};gdjs.StageCode.eventsList42 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("GameStorage", "BrainsEatenNumber", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(1));
}}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)));
}}

}


{



}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeNumberInJSONFile("GameStorage", "BrainsEatenNumber", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)));
}}

}


};gdjs.StageCode.eventsList43 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("GameStorage", "RocksDestroyedNumber", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(2));
}}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)));
}}

}


{



}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeNumberInJSONFile("GameStorage", "RocksDestroyedNumber", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)));
}}

}


};gdjs.StageCode.eventsList44 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("GameStorage", "GamesPlayedNumber", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(3));
}}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)));
}}

}


{



}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeNumberInJSONFile("GameStorage", "GamesPlayedNumber", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)));
}}

}


};gdjs.StageCode.eventsList45 = function(runtimeScene) {

{


gdjs.StageCode.eventsList42(runtimeScene);
}


{


gdjs.StageCode.eventsList43(runtimeScene);
}


{


gdjs.StageCode.eventsList44(runtimeScene);
}


};gdjs.StageCode.eventsList46 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Edge_L"), gdjs.StageCode.GDEdge_9595LObjects2);
gdjs.copyArray(runtimeScene.getObjects("Edge_R"), gdjs.StageCode.GDEdge_9595RObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jump_Tile"), gdjs.StageCode.GDJump_9595TileObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rock_Stop"), gdjs.StageCode.GDRock_9595StopObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tile"), gdjs.StageCode.GDTileObjects2);
{for(var i = 0, len = gdjs.StageCode.GDTileObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDTileObjects2[i].hide();
}
for(var i = 0, len = gdjs.StageCode.GDJump_9595TileObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDJump_9595TileObjects2[i].hide();
}
for(var i = 0, len = gdjs.StageCode.GDRock_9595StopObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDRock_9595StopObjects2[i].hide();
}
for(var i = 0, len = gdjs.StageCode.GDEdge_9595LObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDEdge_9595LObjects2[i].hide();
}
for(var i = 0, len = gdjs.StageCode.GDEdge_9595RObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDEdge_9595RObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.StageCode.GDTileObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDTileObjects2[i].getBehavior("Opacity").setOpacity(100);
}
for(var i = 0, len = gdjs.StageCode.GDJump_9595TileObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDJump_9595TileObjects2[i].getBehavior("Opacity").setOpacity(100);
}
for(var i = 0, len = gdjs.StageCode.GDRock_9595StopObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDRock_9595StopObjects2[i].getBehavior("Opacity").setOpacity(100);
}
for(var i = 0, len = gdjs.StageCode.GDEdge_9595LObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDEdge_9595LObjects2[i].getBehavior("Opacity").setOpacity(100);
}
for(var i = 0, len = gdjs.StageCode.GDEdge_9595RObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDEdge_9595RObjects2[i].getBehavior("Opacity").setOpacity(100);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Gameplay");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}}

}


};gdjs.StageCode.eventsList47 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burrow"), gdjs.StageCode.GDBurrowObjects3);
{for(var i = 0, len = gdjs.StageCode.GDBurrowObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDBurrowObjects3[i].getBehavior("Animation").setAnimationName("Night");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burrow"), gdjs.StageCode.GDBurrowObjects3);
{for(var i = 0, len = gdjs.StageCode.GDBurrowObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDBurrowObjects3[i].getBehavior("Animation").setAnimationName("Day");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__October.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burrow"), gdjs.StageCode.GDBurrowObjects3);
{for(var i = 0, len = gdjs.StageCode.GDBurrowObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDBurrowObjects3[i].getBehavior("Animation").setAnimationName("Halloween");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__December.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burrow"), gdjs.StageCode.GDBurrowObjects2);
{for(var i = 0, len = gdjs.StageCode.GDBurrowObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDBurrowObjects2[i].getBehavior("Animation").setAnimationName("Christmas");
}
}}

}


};gdjs.StageCode.eventsList48 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Dawn.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.StageCode.GDSkyObjects2);
{for(var i = 0, len = gdjs.StageCode.GDSkyObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDSkyObjects2[i].getBehavior("Animation").setAnimationName("Dawn");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Morning.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.StageCode.GDSkyObjects2);
{for(var i = 0, len = gdjs.StageCode.GDSkyObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDSkyObjects2[i].getBehavior("Animation").setAnimationName("Day");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Dusk.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.StageCode.GDSkyObjects2);
{for(var i = 0, len = gdjs.StageCode.GDSkyObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDSkyObjects2[i].getBehavior("Animation").setAnimationName("Dusk");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.StageCode.GDSkyObjects2);
{for(var i = 0, len = gdjs.StageCode.GDSkyObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDSkyObjects2[i].getBehavior("Animation").setAnimationName("Night");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__October.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.StageCode.GDSkyObjects1);
{for(var i = 0, len = gdjs.StageCode.GDSkyObjects1.length ;i < len;++i) {
    gdjs.StageCode.GDSkyObjects1[i].getBehavior("Animation").setAnimationName("Halloween");
}
}}

}


};gdjs.StageCode.eventsList49 = function(runtimeScene) {

{


gdjs.StageCode.eventsList47(runtimeScene);
}


{


gdjs.StageCode.eventsList48(runtimeScene);
}


};gdjs.StageCode.mapOfEmptyGDRegular_9595BrainObjects = Hashtable.newFrom({"Regular_Brain": []});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrainSpawnLEFTObjects3ObjectsGDgdjs_9546StageCode_9546GDBrainSpawnRIGHTObjects3Objects = Hashtable.newFrom({"BrainSpawnLEFT": gdjs.StageCode.GDBrainSpawnLEFTObjects3, "BrainSpawnRIGHT": gdjs.StageCode.GDBrainSpawnRIGHTObjects3});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects3Objects = Hashtable.newFrom({"Regular_Brain": gdjs.StageCode.GDRegular_9595BrainObjects3});
gdjs.StageCode.mapOfEmptyGDRegular_9595BrainObjects = Hashtable.newFrom({"Regular_Brain": []});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrainSpawnLEFTObjects3ObjectsGDgdjs_9546StageCode_9546GDBrainSpawnRIGHTObjects3Objects = Hashtable.newFrom({"BrainSpawnLEFT": gdjs.StageCode.GDBrainSpawnLEFTObjects3, "BrainSpawnRIGHT": gdjs.StageCode.GDBrainSpawnRIGHTObjects3});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects3Objects = Hashtable.newFrom({"Regular_Brain": gdjs.StageCode.GDRegular_9595BrainObjects3});
gdjs.StageCode.mapOfEmptyGDRegular_9595BrainObjects = Hashtable.newFrom({"Regular_Brain": []});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrainSpawnLEFTObjects2ObjectsGDgdjs_9546StageCode_9546GDBrainSpawnRIGHTObjects2Objects = Hashtable.newFrom({"BrainSpawnLEFT": gdjs.StageCode.GDBrainSpawnLEFTObjects2, "BrainSpawnRIGHT": gdjs.StageCode.GDBrainSpawnRIGHTObjects2});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects2Objects = Hashtable.newFrom({"Regular_Brain": gdjs.StageCode.GDRegular_9595BrainObjects2});
gdjs.StageCode.eventsList50 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainSpawn");
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BrainSpawnLEFT"), gdjs.StageCode.GDBrainSpawnLEFTObjects3);
gdjs.copyArray(runtimeScene.getObjects("BrainSpawnRIGHT"), gdjs.StageCode.GDBrainSpawnRIGHTObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 10;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfEmptyGDRegular_9595BrainObjects) <= 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrainSpawnLEFTObjects3ObjectsGDgdjs_9546StageCode_9546GDBrainSpawnRIGHTObjects3Objects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "BrainSpawn") > 5;
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDBrainSpawnLEFTObjects3 */
/* Reuse gdjs.StageCode.GDBrainSpawnRIGHTObjects3 */
gdjs.StageCode.GDRegular_9595BrainObjects3.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainSpawn");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects3Objects, (( gdjs.StageCode.GDBrainSpawnRIGHTObjects3.length === 0 ) ? (( gdjs.StageCode.GDBrainSpawnLEFTObjects3.length === 0 ) ? 0 :gdjs.StageCode.GDBrainSpawnLEFTObjects3[0].getCenterXInScene()) :gdjs.StageCode.GDBrainSpawnRIGHTObjects3[0].getCenterXInScene()), (( gdjs.StageCode.GDBrainSpawnRIGHTObjects3.length === 0 ) ? (( gdjs.StageCode.GDBrainSpawnLEFTObjects3.length === 0 ) ? 0 :gdjs.StageCode.GDBrainSpawnLEFTObjects3[0].getCenterYInScene()) :gdjs.StageCode.GDBrainSpawnRIGHTObjects3[0].getCenterYInScene()), "Brains");
}{for(var i = 0, len = gdjs.StageCode.GDRegular_9595BrainObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDRegular_9595BrainObjects3[i].getBehavior("Resizable").setSize(192, 192);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BrainSpawnLEFT"), gdjs.StageCode.GDBrainSpawnLEFTObjects3);
gdjs.copyArray(runtimeScene.getObjects("BrainSpawnRIGHT"), gdjs.StageCode.GDBrainSpawnRIGHTObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 10;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfEmptyGDRegular_9595BrainObjects) <= 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrainSpawnLEFTObjects3ObjectsGDgdjs_9546StageCode_9546GDBrainSpawnRIGHTObjects3Objects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "BrainSpawn") > 5;
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDBrainSpawnLEFTObjects3 */
/* Reuse gdjs.StageCode.GDBrainSpawnRIGHTObjects3 */
gdjs.StageCode.GDRegular_9595BrainObjects3.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainSpawn");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects3Objects, (( gdjs.StageCode.GDBrainSpawnRIGHTObjects3.length === 0 ) ? (( gdjs.StageCode.GDBrainSpawnLEFTObjects3.length === 0 ) ? 0 :gdjs.StageCode.GDBrainSpawnLEFTObjects3[0].getCenterXInScene()) :gdjs.StageCode.GDBrainSpawnRIGHTObjects3[0].getCenterXInScene()), (( gdjs.StageCode.GDBrainSpawnRIGHTObjects3.length === 0 ) ? (( gdjs.StageCode.GDBrainSpawnLEFTObjects3.length === 0 ) ? 0 :gdjs.StageCode.GDBrainSpawnLEFTObjects3[0].getCenterYInScene()) :gdjs.StageCode.GDBrainSpawnRIGHTObjects3[0].getCenterYInScene()), "Brains");
}{for(var i = 0, len = gdjs.StageCode.GDRegular_9595BrainObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDRegular_9595BrainObjects3[i].getBehavior("Resizable").setSize(192, 192);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BrainSpawnLEFT"), gdjs.StageCode.GDBrainSpawnLEFTObjects2);
gdjs.copyArray(runtimeScene.getObjects("BrainSpawnRIGHT"), gdjs.StageCode.GDBrainSpawnRIGHTObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 50;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfEmptyGDRegular_9595BrainObjects) <= 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrainSpawnLEFTObjects2ObjectsGDgdjs_9546StageCode_9546GDBrainSpawnRIGHTObjects2Objects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "BrainSpawn") > 5;
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDBrainSpawnLEFTObjects2 */
/* Reuse gdjs.StageCode.GDBrainSpawnRIGHTObjects2 */
gdjs.StageCode.GDRegular_9595BrainObjects2.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainSpawn");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects2Objects, (( gdjs.StageCode.GDBrainSpawnRIGHTObjects2.length === 0 ) ? (( gdjs.StageCode.GDBrainSpawnLEFTObjects2.length === 0 ) ? 0 :gdjs.StageCode.GDBrainSpawnLEFTObjects2[0].getCenterXInScene()) :gdjs.StageCode.GDBrainSpawnRIGHTObjects2[0].getCenterXInScene()), (( gdjs.StageCode.GDBrainSpawnRIGHTObjects2.length === 0 ) ? (( gdjs.StageCode.GDBrainSpawnLEFTObjects2.length === 0 ) ? 0 :gdjs.StageCode.GDBrainSpawnLEFTObjects2[0].getCenterYInScene()) :gdjs.StageCode.GDBrainSpawnRIGHTObjects2[0].getCenterYInScene()), "Brains");
}{for(var i = 0, len = gdjs.StageCode.GDRegular_9595BrainObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDRegular_9595BrainObjects2[i].getBehavior("Resizable").setSize(192, 192);
}
}}

}


};gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects3Objects = Hashtable.newFrom({"Regular_Brain": gdjs.StageCode.GDRegular_9595BrainObjects3});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrainSpawnLEFTObjects3Objects = Hashtable.newFrom({"BrainSpawnLEFT": gdjs.StageCode.GDBrainSpawnLEFTObjects3});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects2Objects = Hashtable.newFrom({"Regular_Brain": gdjs.StageCode.GDRegular_9595BrainObjects2});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrainSpawnRIGHTObjects2Objects = Hashtable.newFrom({"BrainSpawnRIGHT": gdjs.StageCode.GDBrainSpawnRIGHTObjects2});
gdjs.StageCode.eventsList51 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BrainSpawnRIGHT"), gdjs.StageCode.GDBrainSpawnRIGHTObjects2);
/* Reuse gdjs.StageCode.GDRegular_9595BrainObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDRegular_9595BrainObjects2.length;i<l;++i) {
    if ( !(gdjs.StageCode.GDRegular_9595BrainObjects2[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDRegular_9595BrainObjects2[k] = gdjs.StageCode.GDRegular_9595BrainObjects2[i];
        ++k;
    }
}
gdjs.StageCode.GDRegular_9595BrainObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects2Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrainSpawnRIGHTObjects2Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDRegular_9595BrainObjects2 */
{for(var i = 0, len = gdjs.StageCode.GDRegular_9595BrainObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDRegular_9595BrainObjects2[i].setX(gdjs.StageCode.GDRegular_9595BrainObjects2[i].getX() + (192));
}
}}

}


};gdjs.StageCode.eventsList52 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BrainSpawnLEFT"), gdjs.StageCode.GDBrainSpawnLEFTObjects3);
gdjs.copyArray(runtimeScene.getObjects("Regular_Brain"), gdjs.StageCode.GDRegular_9595BrainObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects3Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrainSpawnLEFTObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDRegular_9595BrainObjects3 */
{for(var i = 0, len = gdjs.StageCode.GDRegular_9595BrainObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDRegular_9595BrainObjects3[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Regular_Brain"), gdjs.StageCode.GDRegular_9595BrainObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) >= 3);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDRegular_9595BrainObjects2.length;i<l;++i) {
    if ( !(gdjs.StageCode.GDRegular_9595BrainObjects2[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDRegular_9595BrainObjects2[k] = gdjs.StageCode.GDRegular_9595BrainObjects2[i];
        ++k;
    }
}
gdjs.StageCode.GDRegular_9595BrainObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDRegular_9595BrainObjects2.length;i<l;++i) {
    if ( gdjs.StageCode.GDRegular_9595BrainObjects2[i].getBehavior("RepeatTimer").Repeat2("BrainScroll", 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDRegular_9595BrainObjects2[k] = gdjs.StageCode.GDRegular_9595BrainObjects2[i];
        ++k;
    }
}
gdjs.StageCode.GDRegular_9595BrainObjects2.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDRegular_9595BrainObjects2 */
{for(var i = 0, len = gdjs.StageCode.GDRegular_9595BrainObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDRegular_9595BrainObjects2[i].setX(gdjs.StageCode.GDRegular_9595BrainObjects2[i].getX() + (192));
}
}
{ //Subevents
gdjs.StageCode.eventsList51(runtimeScene);} //End of subevents
}

}


};gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects3Objects = Hashtable.newFrom({"Regular_Brain": gdjs.StageCode.GDRegular_9595BrainObjects3});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrainSpawnRIGHTObjects3Objects = Hashtable.newFrom({"BrainSpawnRIGHT": gdjs.StageCode.GDBrainSpawnRIGHTObjects3});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects2Objects = Hashtable.newFrom({"Regular_Brain": gdjs.StageCode.GDRegular_9595BrainObjects2});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrainSpawnLEFTObjects2Objects = Hashtable.newFrom({"BrainSpawnLEFT": gdjs.StageCode.GDBrainSpawnLEFTObjects2});
gdjs.StageCode.eventsList53 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BrainSpawnLEFT"), gdjs.StageCode.GDBrainSpawnLEFTObjects2);
/* Reuse gdjs.StageCode.GDRegular_9595BrainObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDRegular_9595BrainObjects2.length;i<l;++i) {
    if ( gdjs.StageCode.GDRegular_9595BrainObjects2[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDRegular_9595BrainObjects2[k] = gdjs.StageCode.GDRegular_9595BrainObjects2[i];
        ++k;
    }
}
gdjs.StageCode.GDRegular_9595BrainObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects2Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrainSpawnLEFTObjects2Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDRegular_9595BrainObjects2 */
{for(var i = 0, len = gdjs.StageCode.GDRegular_9595BrainObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDRegular_9595BrainObjects2[i].setX(gdjs.StageCode.GDRegular_9595BrainObjects2[i].getX() - (192));
}
}}

}


};gdjs.StageCode.eventsList54 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BrainSpawnRIGHT"), gdjs.StageCode.GDBrainSpawnRIGHTObjects3);
gdjs.copyArray(runtimeScene.getObjects("Regular_Brain"), gdjs.StageCode.GDRegular_9595BrainObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects3Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrainSpawnRIGHTObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDRegular_9595BrainObjects3 */
{for(var i = 0, len = gdjs.StageCode.GDRegular_9595BrainObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDRegular_9595BrainObjects3[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Regular_Brain"), gdjs.StageCode.GDRegular_9595BrainObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) >= 3);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDRegular_9595BrainObjects2.length;i<l;++i) {
    if ( gdjs.StageCode.GDRegular_9595BrainObjects2[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDRegular_9595BrainObjects2[k] = gdjs.StageCode.GDRegular_9595BrainObjects2[i];
        ++k;
    }
}
gdjs.StageCode.GDRegular_9595BrainObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDRegular_9595BrainObjects2.length;i<l;++i) {
    if ( gdjs.StageCode.GDRegular_9595BrainObjects2[i].getBehavior("RepeatTimer").Repeat2("BrainScroll", 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDRegular_9595BrainObjects2[k] = gdjs.StageCode.GDRegular_9595BrainObjects2[i];
        ++k;
    }
}
gdjs.StageCode.GDRegular_9595BrainObjects2.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDRegular_9595BrainObjects2 */
{for(var i = 0, len = gdjs.StageCode.GDRegular_9595BrainObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDRegular_9595BrainObjects2[i].setX(gdjs.StageCode.GDRegular_9595BrainObjects2[i].getX() - (192));
}
}
{ //Subevents
gdjs.StageCode.eventsList53(runtimeScene);} //End of subevents
}

}


};gdjs.StageCode.eventsList55 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainScrollingSpeed");
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.setLayerTimeScale(runtimeScene, "Brains", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(8)));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "BrainScrollingSpeed") >= 90;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(8).add(0.6);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainScrollingSpeed");
}}

}


};gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects2Objects = Hashtable.newFrom({"Regular_Brain": gdjs.StageCode.GDRegular_9595BrainObjects2});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects2Objects = Hashtable.newFrom({"Regular_Brain": gdjs.StageCode.GDRegular_9595BrainObjects2});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects2Objects = Hashtable.newFrom({"Regular_Brain": gdjs.StageCode.GDRegular_9595BrainObjects2});
gdjs.StageCode.eventsList56 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Regular_Brain"), gdjs.StageCode.GDRegular_9595BrainObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects2Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects2Objects, 192, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDRegular_9595BrainObjects2.length;i<l;++i) {
    if ( !(gdjs.StageCode.GDRegular_9595BrainObjects2[i].getBehavior("InOnScreen").IsOnScreen(0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDRegular_9595BrainObjects2[k] = gdjs.StageCode.GDRegular_9595BrainObjects2[i];
        ++k;
    }
}
gdjs.StageCode.GDRegular_9595BrainObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects2Objects);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDRegular_9595BrainObjects2 */
{for(var i = 0, len = gdjs.StageCode.GDRegular_9595BrainObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDRegular_9595BrainObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects1Objects = Hashtable.newFrom({"Regular_Brain": gdjs.StageCode.GDRegular_9595BrainObjects1});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDDeleteBrainLEFTObjects1ObjectsGDgdjs_9546StageCode_9546GDDeleteBrainRIGHTObjects1Objects = Hashtable.newFrom({"DeleteBrainLEFT": gdjs.StageCode.GDDeleteBrainLEFTObjects1, "DeleteBrainRIGHT": gdjs.StageCode.GDDeleteBrainRIGHTObjects1});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrain_95959595ScoreObjects3Objects = Hashtable.newFrom({"Brain_Score": gdjs.StageCode.GDBrain_9595ScoreObjects3});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrain_95959595ScoreObjects3Objects = Hashtable.newFrom({"Brain_Score": gdjs.StageCode.GDBrain_9595ScoreObjects3});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrain_95959595ScoreObjects2Objects = Hashtable.newFrom({"Brain_Score": gdjs.StageCode.GDBrain_9595ScoreObjects2});
gdjs.StageCode.eventsList57 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 1;
if (isConditionTrue_0) {
gdjs.StageCode.GDBrain_9595ScoreObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrain_95959595ScoreObjects3Objects, 32, 160, "Gui");
}{for(var i = 0, len = gdjs.StageCode.GDBrain_9595ScoreObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDBrain_9595ScoreObjects3[i].getBehavior("Resizable").setSize(64, 64);
}
}{for(var i = 0, len = gdjs.StageCode.GDBrain_9595ScoreObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDBrain_9595ScoreObjects3[i].getBehavior("Flash").Flash(3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 2;
if (isConditionTrue_0) {
gdjs.StageCode.GDBrain_9595ScoreObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrain_95959595ScoreObjects3Objects, 32, 256, "Gui");
}{for(var i = 0, len = gdjs.StageCode.GDBrain_9595ScoreObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDBrain_9595ScoreObjects3[i].getBehavior("Resizable").setSize(64, 64);
}
}{for(var i = 0, len = gdjs.StageCode.GDBrain_9595ScoreObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDBrain_9595ScoreObjects3[i].getBehavior("Flash").Flash(3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 3;
if (isConditionTrue_0) {
gdjs.StageCode.GDBrain_9595ScoreObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDBrain_95959595ScoreObjects2Objects, 32, 352, "Gui");
}{for(var i = 0, len = gdjs.StageCode.GDBrain_9595ScoreObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDBrain_9595ScoreObjects2[i].getBehavior("Resizable").setSize(64, 64);
}
}}

}


};gdjs.StageCode.asyncCallback14681804 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Regular_Brain"), gdjs.StageCode.GDRegular_9595BrainObjects2);

{for(var i = 0, len = gdjs.StageCode.GDRegular_9595BrainObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDRegular_9595BrainObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.StageCode.eventsList57(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.StageCode.eventsList58 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.StageCode.GDRegular_9595BrainObjects1) asyncObjectsList.addObject("Regular_Brain", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.StageCode.asyncCallback14681804(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.StageCode.eventsList59 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DeleteBrainLEFT"), gdjs.StageCode.GDDeleteBrainLEFTObjects1);
gdjs.copyArray(runtimeScene.getObjects("DeleteBrainRIGHT"), gdjs.StageCode.GDDeleteBrainRIGHTObjects1);
gdjs.copyArray(runtimeScene.getObjects("Regular_Brain"), gdjs.StageCode.GDRegular_9595BrainObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRegular_95959595BrainObjects1Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDDeleteBrainLEFTObjects1ObjectsGDgdjs_9546StageCode_9546GDDeleteBrainRIGHTObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 4.aac", false, 100, 0.5);
}
{ //Subevents
gdjs.StageCode.eventsList58(runtimeScene);} //End of subevents
}

}


};gdjs.StageCode.eventsList60 = function(runtimeScene) {

{


gdjs.StageCode.eventsList50(runtimeScene);
}


{


gdjs.StageCode.eventsList52(runtimeScene);
}


{


gdjs.StageCode.eventsList54(runtimeScene);
}


{


gdjs.StageCode.eventsList55(runtimeScene);
}


{


gdjs.StageCode.eventsList56(runtimeScene);
}


{


gdjs.StageCode.eventsList59(runtimeScene);
}


};gdjs.StageCode.mapOfEmptyGDRockObjects = Hashtable.newFrom({"Rock": []});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRockSpawnObjects3Objects = Hashtable.newFrom({"RockSpawn": gdjs.StageCode.GDRockSpawnObjects3});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRockObjects3Objects = Hashtable.newFrom({"Rock": gdjs.StageCode.GDRockObjects3});
gdjs.StageCode.mapOfEmptyGDRockObjects = Hashtable.newFrom({"Rock": []});
gdjs.StageCode.eventsList61 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "RockSpawn");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RockSpawn"), gdjs.StageCode.GDRockSpawnObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Gameplay") > 30;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfEmptyGDRockObjects) <= 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRockSpawnObjects3Objects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "RockSpawn") > 30;
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDRockSpawnObjects3 */
gdjs.StageCode.GDRockObjects3.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "RockSpawn");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRockObjects3Objects, (( gdjs.StageCode.GDRockSpawnObjects3.length === 0 ) ? 0 :gdjs.StageCode.GDRockSpawnObjects3[0].getCenterXInScene()) + 192, (( gdjs.StageCode.GDRockSpawnObjects3.length === 0 ) ? 0 :gdjs.StageCode.GDRockSpawnObjects3[0].getCenterYInScene()) + 192, "Rocks");
}{for(var i = 0, len = gdjs.StageCode.GDRockObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDRockObjects3[i].getBehavior("Resizable").setSize(192, 192);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfEmptyGDRockObjects) > 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Rock"), gdjs.StageCode.GDRockObjects2);
{for(var i = 0, len = gdjs.StageCode.GDRockObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDRockObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects3Objects = Hashtable.newFrom({"Jerry_Character": gdjs.StageCode.GDJerry_9595CharacterObjects3});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRockObjects3Objects = Hashtable.newFrom({"Rock": gdjs.StageCode.GDRockObjects3});
gdjs.StageCode.eventsList62 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "RockFallingSpeed");
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.setLayerTimeScale(runtimeScene, "Rocks", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(9)));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "RockFallingSpeed") >= 90;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(9).add(0.7);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "RockFallingSpeed");
}}

}


};gdjs.StageCode.eventsList63 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Rock"), gdjs.StageCode.GDRockObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects3Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRockObjects3Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) >= 3);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDRockObjects3.length;i<l;++i) {
    if ( gdjs.StageCode.GDRockObjects3[i].getBehavior("RepeatTimer").Repeat2("RockFall", 6, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDRockObjects3[k] = gdjs.StageCode.GDRockObjects3[i];
        ++k;
    }
}
gdjs.StageCode.GDRockObjects3.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDRockObjects3 */
{for(var i = 0, len = gdjs.StageCode.GDRockObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDRockObjects3[i].setY(gdjs.StageCode.GDRockObjects3[i].getY() + (192));
}
}}

}


{


gdjs.StageCode.eventsList62(runtimeScene);
}


};gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRockObjects4Objects = Hashtable.newFrom({"Rock": gdjs.StageCode.GDRockObjects4});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRock_95959595StopObjects4Objects = Hashtable.newFrom({"Rock_Stop": gdjs.StageCode.GDRock_9595StopObjects4});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDPermanent_95959595RockObjects4Objects = Hashtable.newFrom({"Permanent_Rock": gdjs.StageCode.GDPermanent_9595RockObjects4});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDSpawner_95959595DeleteObjects5Objects = Hashtable.newFrom({"Spawner_Delete": gdjs.StageCode.GDSpawner_9595DeleteObjects5});
gdjs.StageCode.eventsList64 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.StageCode.GDPermanent_9595RockObjects4, gdjs.StageCode.GDPermanent_9595RockObjects5);

gdjs.StageCode.GDSpawner_9595DeleteObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDSpawner_95959595DeleteObjects5Objects, (( gdjs.StageCode.GDPermanent_9595RockObjects5.length === 0 ) ? 0 :gdjs.StageCode.GDPermanent_9595RockObjects5[0].getPointX("")), (( gdjs.StageCode.GDPermanent_9595RockObjects5.length === 0 ) ? 0 :gdjs.StageCode.GDPermanent_9595RockObjects5[0].getPointY("")) - 768, "");
}}

}


};gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDSpawner_95959595DeleteObjects2Objects = Hashtable.newFrom({"Spawner_Delete": gdjs.StageCode.GDSpawner_9595DeleteObjects2});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRockSpawnObjects2Objects = Hashtable.newFrom({"RockSpawn": gdjs.StageCode.GDRockSpawnObjects2});
gdjs.StageCode.asyncCallback14694292 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Spawner_Delete"), gdjs.StageCode.GDSpawner_9595DeleteObjects3);

{for(var i = 0, len = gdjs.StageCode.GDSpawner_9595DeleteObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDSpawner_9595DeleteObjects3[i].deleteFromScene(runtimeScene);
}
}}
gdjs.StageCode.eventsList65 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.StageCode.GDSpawner_9595DeleteObjects2) asyncObjectsList.addObject("Spawner_Delete", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.StageCode.asyncCallback14694292(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.StageCode.eventsList66 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Rock"), gdjs.StageCode.GDRockObjects3);

for (gdjs.StageCode.forEachIndex4 = 0;gdjs.StageCode.forEachIndex4 < gdjs.StageCode.GDRockObjects3.length;++gdjs.StageCode.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("Rock_Stop"), gdjs.StageCode.GDRock_9595StopObjects4);
gdjs.StageCode.GDPermanent_9595RockObjects4.length = 0;

gdjs.StageCode.GDRockObjects4.length = 0;


gdjs.StageCode.forEachTemporary4 = gdjs.StageCode.GDRockObjects3[gdjs.StageCode.forEachIndex4];
gdjs.StageCode.GDRockObjects4.push(gdjs.StageCode.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRockObjects4Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRock_95959595StopObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14692972);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDPermanent_95959595RockObjects4Objects, (( gdjs.StageCode.GDRock_9595StopObjects4.length === 0 ) ? 0 :gdjs.StageCode.GDRock_9595StopObjects4[0].getPointX("")), (( gdjs.StageCode.GDRock_9595StopObjects4.length === 0 ) ? 0 :gdjs.StageCode.GDRock_9595StopObjects4[0].getPointY("")) - 32, "");
}{for(var i = 0, len = gdjs.StageCode.GDRockObjects4.length ;i < len;++i) {
    gdjs.StageCode.GDRockObjects4[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents: 
gdjs.StageCode.eventsList64(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("RockSpawn"), gdjs.StageCode.GDRockSpawnObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spawner_Delete"), gdjs.StageCode.GDSpawner_9595DeleteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDSpawner_95959595DeleteObjects2Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRockSpawnObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDRockSpawnObjects2 */
{for(var i = 0, len = gdjs.StageCode.GDRockSpawnObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDRockSpawnObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.StageCode.eventsList65(runtimeScene);} //End of subevents
}

}


};gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRockObjects1Objects = Hashtable.newFrom({"Rock": gdjs.StageCode.GDRockObjects1});
gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects1Objects = Hashtable.newFrom({"Jerry_Character": gdjs.StageCode.GDJerry_9595CharacterObjects1});
gdjs.StageCode.eventsList67 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rock"), gdjs.StageCode.GDRockObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDRockObjects1Objects, gdjs.StageCode.mapOfGDgdjs_9546StageCode_9546GDJerry_95959595CharacterObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14695748);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(5);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 2.aac", false, 100, 1);
}}

}


};gdjs.StageCode.eventsList68 = function(runtimeScene) {

{


gdjs.StageCode.eventsList61(runtimeScene);
}


{


gdjs.StageCode.eventsList63(runtimeScene);
}


{


gdjs.StageCode.eventsList66(runtimeScene);
}


{


gdjs.StageCode.eventsList67(runtimeScene);
}


};gdjs.StageCode.eventsList69 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 3;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title", false);
}}

}


};gdjs.StageCode.asyncCallback14698556 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getScene().getVariables().getFromIndex(3).add(1);
}}
gdjs.StageCode.eventsList70 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(52), (runtimeScene) => (gdjs.StageCode.asyncCallback14698556(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.StageCode.eventsList71 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Jerry_Character"), gdjs.StageCode.GDJerry_9595CharacterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDJerry_9595CharacterObjects1.length;i<l;++i) {
    if ( gdjs.StageCode.GDJerry_9595CharacterObjects1[i].getBehavior("InOnScreen").IsOnScreen(0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDJerry_9595CharacterObjects1[k] = gdjs.StageCode.GDJerry_9595CharacterObjects1[i];
        ++k;
    }
}
gdjs.StageCode.GDJerry_9595CharacterObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14698332);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.StageCode.eventsList70(runtimeScene);} //End of subevents
}

}


};gdjs.StageCode.eventsList72 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num1");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Delete");
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14700316);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(0);
}}

}


};gdjs.StageCode.eventsList73 = function(runtimeScene) {

{


gdjs.StageCode.eventsList72(runtimeScene);
}


};gdjs.StageCode.eventsList74 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("GameStorage", "HighScore", runtimeScene, runtimeScene.getScene().getVariables().getFromIndex(0));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("High_Score_Gameplay"), gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects2);
{for(var i = 0, len = gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects2[i].getBehavior("Text").setText("High Score: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)));
}
}{gdjs.evtTools.storage.writeNumberInJSONFile("GameStorage", "HighScore", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)));
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Score"), gdjs.StageCode.GDScoreObjects1);
{for(var i = 0, len = gdjs.StageCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.StageCode.GDScoreObjects1[i].getBehavior("Text").setText("Score: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}}

}


};gdjs.StageCode.eventsList75 = function(runtimeScene) {

{

/* Reuse gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects3.length;i<l;++i) {
    if ( gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects3[i].getBehavior("Animation").getAnimationName() == "Jumper" ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects3[k] = gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects3[i];
        ++k;
    }
}
gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects3 */
{for(var i = 0, len = gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects3[i].setX(0);
}
}}

}


};gdjs.StageCode.eventsList76 = function(runtimeScene) {

{

/* Reuse gdjs.StageCode.GDRight_9595Above_9595GroundObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.StageCode.GDRight_9595Above_9595GroundObjects3.length;i<l;++i) {
    if ( gdjs.StageCode.GDRight_9595Above_9595GroundObjects3[i].getBehavior("Animation").getAnimationName() == "Tank" ) {
        isConditionTrue_0 = true;
        gdjs.StageCode.GDRight_9595Above_9595GroundObjects3[k] = gdjs.StageCode.GDRight_9595Above_9595GroundObjects3[i];
        ++k;
    }
}
gdjs.StageCode.GDRight_9595Above_9595GroundObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.StageCode.GDRight_9595Above_9595GroundObjects3 */
{for(var i = 0, len = gdjs.StageCode.GDRight_9595Above_9595GroundObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDRight_9595Above_9595GroundObjects3[i].setZOrder(-(1));
}
}}

}


};gdjs.StageCode.eventsList77 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14705820);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Left_Background_Image_Burrow"), gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects3);
{for(var i = 0, len = gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects3[i].getBehavior("Animation").setAnimationIndex(gdjs.random(3));
}
}
{ //Subevents
gdjs.StageCode.eventsList75(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14707396);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Right_Background_Image_Burrow"), gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects3);
{for(var i = 0, len = gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects3[i].getBehavior("Animation").setAnimationIndex(gdjs.random(3));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14708140);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Right_Above_Ground"), gdjs.StageCode.GDRight_9595Above_9595GroundObjects3);
{for(var i = 0, len = gdjs.StageCode.GDRight_9595Above_9595GroundObjects3.length ;i < len;++i) {
    gdjs.StageCode.GDRight_9595Above_9595GroundObjects3[i].getBehavior("Animation").setAnimationIndex(gdjs.random(5));
}
}
{ //Subevents
gdjs.StageCode.eventsList76(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14709716);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Left_Above_Ground"), gdjs.StageCode.GDLeft_9595Above_9595GroundObjects2);
{for(var i = 0, len = gdjs.StageCode.GDLeft_9595Above_9595GroundObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDLeft_9595Above_9595GroundObjects2[i].getBehavior("Animation").setAnimationIndex(gdjs.random(5));
}
}}

}


};gdjs.StageCode.eventsList78 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14710596);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gerbil"), gdjs.StageCode.GDZombie_9595GerbilObjects2);
{for(var i = 0, len = gdjs.StageCode.GDZombie_9595GerbilObjects2.length ;i < len;++i) {
    gdjs.StageCode.GDZombie_9595GerbilObjects2[i].getBehavior("Animation").setAnimationIndex(gdjs.random(2));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14711500);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gerbil"), gdjs.StageCode.GDZombie_9595GerbilObjects1);
{for(var i = 0, len = gdjs.StageCode.GDZombie_9595GerbilObjects1.length ;i < len;++i) {
    gdjs.StageCode.GDZombie_9595GerbilObjects1[i].getBehavior("Animation").setAnimationName("Zombie Gerbil None");
}
}}

}


};gdjs.StageCode.eventsList79 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.StageCode.eventsList77(runtimeScene);} //End of subevents
}

}


{


gdjs.StageCode.eventsList78(runtimeScene);
}


};gdjs.StageCode.eventsList80 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) >= 3;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) >= 10;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
}}

}


{



}


{



}


{



}


{



}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) >= 20;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), true);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) >= 50;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), true);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 500;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(13), true);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 1000;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) >= 200;
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(14), true);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 1500;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), true);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 3000;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) >= 500;
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(16), true);
}}

}


};gdjs.StageCode.eventsList81 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 3;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage", false);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title", false);
}}

}


};gdjs.StageCode.eventsList82 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num2");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "NumpadReturn");
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14726532);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(13), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(14), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(16), true);
}}

}


};gdjs.StageCode.eventsList83 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num2");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Delete");
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14729444);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(13), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(14), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(16), false);
}}

}


};gdjs.StageCode.eventsList84 = function(runtimeScene) {

{


gdjs.StageCode.eventsList81(runtimeScene);
}


{


gdjs.StageCode.eventsList82(runtimeScene);
}


{


gdjs.StageCode.eventsList83(runtimeScene);
}


};gdjs.StageCode.eventsList85 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isPreview(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.StageCode.eventsList84(runtimeScene);} //End of subevents
}

}


};gdjs.StageCode.eventsList86 = function(runtimeScene) {

{



}


{


gdjs.StageCode.eventsList22(runtimeScene);
}


{


gdjs.StageCode.eventsList30(runtimeScene);
}


{


gdjs.StageCode.eventsList31(runtimeScene);
}


{


gdjs.StageCode.eventsList34(runtimeScene);
}


{


gdjs.StageCode.eventsList37(runtimeScene);
}


{


gdjs.StageCode.eventsList41(runtimeScene);
}


{


gdjs.StageCode.eventsList45(runtimeScene);
}


{


gdjs.StageCode.eventsList46(runtimeScene);
}


{


gdjs.StageCode.eventsList49(runtimeScene);
}


{


gdjs.StageCode.eventsList60(runtimeScene);
}


{


gdjs.StageCode.eventsList68(runtimeScene);
}


{


gdjs.StageCode.eventsList69(runtimeScene);
}


{


gdjs.StageCode.eventsList71(runtimeScene);
}


{


gdjs.StageCode.eventsList73(runtimeScene);
}


{


gdjs.StageCode.eventsList74(runtimeScene);
}


{


gdjs.StageCode.eventsList79(runtimeScene);
}


{


gdjs.StageCode.eventsList80(runtimeScene);
}


{


gdjs.StageCode.eventsList85(runtimeScene);
}


};

gdjs.StageCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.StageCode.GDTileObjects1.length = 0;
gdjs.StageCode.GDTileObjects2.length = 0;
gdjs.StageCode.GDTileObjects3.length = 0;
gdjs.StageCode.GDTileObjects4.length = 0;
gdjs.StageCode.GDTileObjects5.length = 0;
gdjs.StageCode.GDTileObjects6.length = 0;
gdjs.StageCode.GDTileObjects7.length = 0;
gdjs.StageCode.GDTileObjects8.length = 0;
gdjs.StageCode.GDTileObjects9.length = 0;
gdjs.StageCode.GDJerry_9595CharacterObjects1.length = 0;
gdjs.StageCode.GDJerry_9595CharacterObjects2.length = 0;
gdjs.StageCode.GDJerry_9595CharacterObjects3.length = 0;
gdjs.StageCode.GDJerry_9595CharacterObjects4.length = 0;
gdjs.StageCode.GDJerry_9595CharacterObjects5.length = 0;
gdjs.StageCode.GDJerry_9595CharacterObjects6.length = 0;
gdjs.StageCode.GDJerry_9595CharacterObjects7.length = 0;
gdjs.StageCode.GDJerry_9595CharacterObjects8.length = 0;
gdjs.StageCode.GDJerry_9595CharacterObjects9.length = 0;
gdjs.StageCode.GDJump_9595TileObjects1.length = 0;
gdjs.StageCode.GDJump_9595TileObjects2.length = 0;
gdjs.StageCode.GDJump_9595TileObjects3.length = 0;
gdjs.StageCode.GDJump_9595TileObjects4.length = 0;
gdjs.StageCode.GDJump_9595TileObjects5.length = 0;
gdjs.StageCode.GDJump_9595TileObjects6.length = 0;
gdjs.StageCode.GDJump_9595TileObjects7.length = 0;
gdjs.StageCode.GDJump_9595TileObjects8.length = 0;
gdjs.StageCode.GDJump_9595TileObjects9.length = 0;
gdjs.StageCode.GDRegular_9595BrainObjects1.length = 0;
gdjs.StageCode.GDRegular_9595BrainObjects2.length = 0;
gdjs.StageCode.GDRegular_9595BrainObjects3.length = 0;
gdjs.StageCode.GDRegular_9595BrainObjects4.length = 0;
gdjs.StageCode.GDRegular_9595BrainObjects5.length = 0;
gdjs.StageCode.GDRegular_9595BrainObjects6.length = 0;
gdjs.StageCode.GDRegular_9595BrainObjects7.length = 0;
gdjs.StageCode.GDRegular_9595BrainObjects8.length = 0;
gdjs.StageCode.GDRegular_9595BrainObjects9.length = 0;
gdjs.StageCode.GDBrainSpawnLEFTObjects1.length = 0;
gdjs.StageCode.GDBrainSpawnLEFTObjects2.length = 0;
gdjs.StageCode.GDBrainSpawnLEFTObjects3.length = 0;
gdjs.StageCode.GDBrainSpawnLEFTObjects4.length = 0;
gdjs.StageCode.GDBrainSpawnLEFTObjects5.length = 0;
gdjs.StageCode.GDBrainSpawnLEFTObjects6.length = 0;
gdjs.StageCode.GDBrainSpawnLEFTObjects7.length = 0;
gdjs.StageCode.GDBrainSpawnLEFTObjects8.length = 0;
gdjs.StageCode.GDBrainSpawnLEFTObjects9.length = 0;
gdjs.StageCode.GDDeleteBrainLEFTObjects1.length = 0;
gdjs.StageCode.GDDeleteBrainLEFTObjects2.length = 0;
gdjs.StageCode.GDDeleteBrainLEFTObjects3.length = 0;
gdjs.StageCode.GDDeleteBrainLEFTObjects4.length = 0;
gdjs.StageCode.GDDeleteBrainLEFTObjects5.length = 0;
gdjs.StageCode.GDDeleteBrainLEFTObjects6.length = 0;
gdjs.StageCode.GDDeleteBrainLEFTObjects7.length = 0;
gdjs.StageCode.GDDeleteBrainLEFTObjects8.length = 0;
gdjs.StageCode.GDDeleteBrainLEFTObjects9.length = 0;
gdjs.StageCode.GDScoreObjects1.length = 0;
gdjs.StageCode.GDScoreObjects2.length = 0;
gdjs.StageCode.GDScoreObjects3.length = 0;
gdjs.StageCode.GDScoreObjects4.length = 0;
gdjs.StageCode.GDScoreObjects5.length = 0;
gdjs.StageCode.GDScoreObjects6.length = 0;
gdjs.StageCode.GDScoreObjects7.length = 0;
gdjs.StageCode.GDScoreObjects8.length = 0;
gdjs.StageCode.GDScoreObjects9.length = 0;
gdjs.StageCode.GDNo_9595Go_9595ZoneObjects1.length = 0;
gdjs.StageCode.GDNo_9595Go_9595ZoneObjects2.length = 0;
gdjs.StageCode.GDNo_9595Go_9595ZoneObjects3.length = 0;
gdjs.StageCode.GDNo_9595Go_9595ZoneObjects4.length = 0;
gdjs.StageCode.GDNo_9595Go_9595ZoneObjects5.length = 0;
gdjs.StageCode.GDNo_9595Go_9595ZoneObjects6.length = 0;
gdjs.StageCode.GDNo_9595Go_9595ZoneObjects7.length = 0;
gdjs.StageCode.GDNo_9595Go_9595ZoneObjects8.length = 0;
gdjs.StageCode.GDNo_9595Go_9595ZoneObjects9.length = 0;
gdjs.StageCode.GDBrain_9595ScoreObjects1.length = 0;
gdjs.StageCode.GDBrain_9595ScoreObjects2.length = 0;
gdjs.StageCode.GDBrain_9595ScoreObjects3.length = 0;
gdjs.StageCode.GDBrain_9595ScoreObjects4.length = 0;
gdjs.StageCode.GDBrain_9595ScoreObjects5.length = 0;
gdjs.StageCode.GDBrain_9595ScoreObjects6.length = 0;
gdjs.StageCode.GDBrain_9595ScoreObjects7.length = 0;
gdjs.StageCode.GDBrain_9595ScoreObjects8.length = 0;
gdjs.StageCode.GDBrain_9595ScoreObjects9.length = 0;
gdjs.StageCode.GDGolden_9595BrainObjects1.length = 0;
gdjs.StageCode.GDGolden_9595BrainObjects2.length = 0;
gdjs.StageCode.GDGolden_9595BrainObjects3.length = 0;
gdjs.StageCode.GDGolden_9595BrainObjects4.length = 0;
gdjs.StageCode.GDGolden_9595BrainObjects5.length = 0;
gdjs.StageCode.GDGolden_9595BrainObjects6.length = 0;
gdjs.StageCode.GDGolden_9595BrainObjects7.length = 0;
gdjs.StageCode.GDGolden_9595BrainObjects8.length = 0;
gdjs.StageCode.GDGolden_9595BrainObjects9.length = 0;
gdjs.StageCode.GDEdge_9595LObjects1.length = 0;
gdjs.StageCode.GDEdge_9595LObjects2.length = 0;
gdjs.StageCode.GDEdge_9595LObjects3.length = 0;
gdjs.StageCode.GDEdge_9595LObjects4.length = 0;
gdjs.StageCode.GDEdge_9595LObjects5.length = 0;
gdjs.StageCode.GDEdge_9595LObjects6.length = 0;
gdjs.StageCode.GDEdge_9595LObjects7.length = 0;
gdjs.StageCode.GDEdge_9595LObjects8.length = 0;
gdjs.StageCode.GDEdge_9595LObjects9.length = 0;
gdjs.StageCode.GDEdge_9595RObjects1.length = 0;
gdjs.StageCode.GDEdge_9595RObjects2.length = 0;
gdjs.StageCode.GDEdge_9595RObjects3.length = 0;
gdjs.StageCode.GDEdge_9595RObjects4.length = 0;
gdjs.StageCode.GDEdge_9595RObjects5.length = 0;
gdjs.StageCode.GDEdge_9595RObjects6.length = 0;
gdjs.StageCode.GDEdge_9595RObjects7.length = 0;
gdjs.StageCode.GDEdge_9595RObjects8.length = 0;
gdjs.StageCode.GDEdge_9595RObjects9.length = 0;
gdjs.StageCode.GDRockSpawnObjects1.length = 0;
gdjs.StageCode.GDRockSpawnObjects2.length = 0;
gdjs.StageCode.GDRockSpawnObjects3.length = 0;
gdjs.StageCode.GDRockSpawnObjects4.length = 0;
gdjs.StageCode.GDRockSpawnObjects5.length = 0;
gdjs.StageCode.GDRockSpawnObjects6.length = 0;
gdjs.StageCode.GDRockSpawnObjects7.length = 0;
gdjs.StageCode.GDRockSpawnObjects8.length = 0;
gdjs.StageCode.GDRockSpawnObjects9.length = 0;
gdjs.StageCode.GDRockObjects1.length = 0;
gdjs.StageCode.GDRockObjects2.length = 0;
gdjs.StageCode.GDRockObjects3.length = 0;
gdjs.StageCode.GDRockObjects4.length = 0;
gdjs.StageCode.GDRockObjects5.length = 0;
gdjs.StageCode.GDRockObjects6.length = 0;
gdjs.StageCode.GDRockObjects7.length = 0;
gdjs.StageCode.GDRockObjects8.length = 0;
gdjs.StageCode.GDRockObjects9.length = 0;
gdjs.StageCode.GDRock_9595StopObjects1.length = 0;
gdjs.StageCode.GDRock_9595StopObjects2.length = 0;
gdjs.StageCode.GDRock_9595StopObjects3.length = 0;
gdjs.StageCode.GDRock_9595StopObjects4.length = 0;
gdjs.StageCode.GDRock_9595StopObjects5.length = 0;
gdjs.StageCode.GDRock_9595StopObjects6.length = 0;
gdjs.StageCode.GDRock_9595StopObjects7.length = 0;
gdjs.StageCode.GDRock_9595StopObjects8.length = 0;
gdjs.StageCode.GDRock_9595StopObjects9.length = 0;
gdjs.StageCode.GDPermanent_9595RockObjects1.length = 0;
gdjs.StageCode.GDPermanent_9595RockObjects2.length = 0;
gdjs.StageCode.GDPermanent_9595RockObjects3.length = 0;
gdjs.StageCode.GDPermanent_9595RockObjects4.length = 0;
gdjs.StageCode.GDPermanent_9595RockObjects5.length = 0;
gdjs.StageCode.GDPermanent_9595RockObjects6.length = 0;
gdjs.StageCode.GDPermanent_9595RockObjects7.length = 0;
gdjs.StageCode.GDPermanent_9595RockObjects8.length = 0;
gdjs.StageCode.GDPermanent_9595RockObjects9.length = 0;
gdjs.StageCode.GDBottom_9595BorderObjects1.length = 0;
gdjs.StageCode.GDBottom_9595BorderObjects2.length = 0;
gdjs.StageCode.GDBottom_9595BorderObjects3.length = 0;
gdjs.StageCode.GDBottom_9595BorderObjects4.length = 0;
gdjs.StageCode.GDBottom_9595BorderObjects5.length = 0;
gdjs.StageCode.GDBottom_9595BorderObjects6.length = 0;
gdjs.StageCode.GDBottom_9595BorderObjects7.length = 0;
gdjs.StageCode.GDBottom_9595BorderObjects8.length = 0;
gdjs.StageCode.GDBottom_9595BorderObjects9.length = 0;
gdjs.StageCode.GDSpawner_9595DeleteObjects1.length = 0;
gdjs.StageCode.GDSpawner_9595DeleteObjects2.length = 0;
gdjs.StageCode.GDSpawner_9595DeleteObjects3.length = 0;
gdjs.StageCode.GDSpawner_9595DeleteObjects4.length = 0;
gdjs.StageCode.GDSpawner_9595DeleteObjects5.length = 0;
gdjs.StageCode.GDSpawner_9595DeleteObjects6.length = 0;
gdjs.StageCode.GDSpawner_9595DeleteObjects7.length = 0;
gdjs.StageCode.GDSpawner_9595DeleteObjects8.length = 0;
gdjs.StageCode.GDSpawner_9595DeleteObjects9.length = 0;
gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects1.length = 0;
gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects2.length = 0;
gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects3.length = 0;
gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects4.length = 0;
gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects5.length = 0;
gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects6.length = 0;
gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects7.length = 0;
gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects8.length = 0;
gdjs.StageCode.GDLeft_9595Background_9595Image_9595BurrowObjects9.length = 0;
gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects1.length = 0;
gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects2.length = 0;
gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects3.length = 0;
gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects4.length = 0;
gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects5.length = 0;
gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects6.length = 0;
gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects7.length = 0;
gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects8.length = 0;
gdjs.StageCode.GDRight_9595Background_9595Image_9595BurrowObjects9.length = 0;
gdjs.StageCode.GDZombie_9595GerbilObjects1.length = 0;
gdjs.StageCode.GDZombie_9595GerbilObjects2.length = 0;
gdjs.StageCode.GDZombie_9595GerbilObjects3.length = 0;
gdjs.StageCode.GDZombie_9595GerbilObjects4.length = 0;
gdjs.StageCode.GDZombie_9595GerbilObjects5.length = 0;
gdjs.StageCode.GDZombie_9595GerbilObjects6.length = 0;
gdjs.StageCode.GDZombie_9595GerbilObjects7.length = 0;
gdjs.StageCode.GDZombie_9595GerbilObjects8.length = 0;
gdjs.StageCode.GDZombie_9595GerbilObjects9.length = 0;
gdjs.StageCode.GDLeft_9595Above_9595GroundObjects1.length = 0;
gdjs.StageCode.GDLeft_9595Above_9595GroundObjects2.length = 0;
gdjs.StageCode.GDLeft_9595Above_9595GroundObjects3.length = 0;
gdjs.StageCode.GDLeft_9595Above_9595GroundObjects4.length = 0;
gdjs.StageCode.GDLeft_9595Above_9595GroundObjects5.length = 0;
gdjs.StageCode.GDLeft_9595Above_9595GroundObjects6.length = 0;
gdjs.StageCode.GDLeft_9595Above_9595GroundObjects7.length = 0;
gdjs.StageCode.GDLeft_9595Above_9595GroundObjects8.length = 0;
gdjs.StageCode.GDLeft_9595Above_9595GroundObjects9.length = 0;
gdjs.StageCode.GDRight_9595Above_9595GroundObjects1.length = 0;
gdjs.StageCode.GDRight_9595Above_9595GroundObjects2.length = 0;
gdjs.StageCode.GDRight_9595Above_9595GroundObjects3.length = 0;
gdjs.StageCode.GDRight_9595Above_9595GroundObjects4.length = 0;
gdjs.StageCode.GDRight_9595Above_9595GroundObjects5.length = 0;
gdjs.StageCode.GDRight_9595Above_9595GroundObjects6.length = 0;
gdjs.StageCode.GDRight_9595Above_9595GroundObjects7.length = 0;
gdjs.StageCode.GDRight_9595Above_9595GroundObjects8.length = 0;
gdjs.StageCode.GDRight_9595Above_9595GroundObjects9.length = 0;
gdjs.StageCode.GDTimerObjects1.length = 0;
gdjs.StageCode.GDTimerObjects2.length = 0;
gdjs.StageCode.GDTimerObjects3.length = 0;
gdjs.StageCode.GDTimerObjects4.length = 0;
gdjs.StageCode.GDTimerObjects5.length = 0;
gdjs.StageCode.GDTimerObjects6.length = 0;
gdjs.StageCode.GDTimerObjects7.length = 0;
gdjs.StageCode.GDTimerObjects8.length = 0;
gdjs.StageCode.GDTimerObjects9.length = 0;
gdjs.StageCode.GDDeleteBrainRIGHTObjects1.length = 0;
gdjs.StageCode.GDDeleteBrainRIGHTObjects2.length = 0;
gdjs.StageCode.GDDeleteBrainRIGHTObjects3.length = 0;
gdjs.StageCode.GDDeleteBrainRIGHTObjects4.length = 0;
gdjs.StageCode.GDDeleteBrainRIGHTObjects5.length = 0;
gdjs.StageCode.GDDeleteBrainRIGHTObjects6.length = 0;
gdjs.StageCode.GDDeleteBrainRIGHTObjects7.length = 0;
gdjs.StageCode.GDDeleteBrainRIGHTObjects8.length = 0;
gdjs.StageCode.GDDeleteBrainRIGHTObjects9.length = 0;
gdjs.StageCode.GDBrainSpawnRIGHTObjects1.length = 0;
gdjs.StageCode.GDBrainSpawnRIGHTObjects2.length = 0;
gdjs.StageCode.GDBrainSpawnRIGHTObjects3.length = 0;
gdjs.StageCode.GDBrainSpawnRIGHTObjects4.length = 0;
gdjs.StageCode.GDBrainSpawnRIGHTObjects5.length = 0;
gdjs.StageCode.GDBrainSpawnRIGHTObjects6.length = 0;
gdjs.StageCode.GDBrainSpawnRIGHTObjects7.length = 0;
gdjs.StageCode.GDBrainSpawnRIGHTObjects8.length = 0;
gdjs.StageCode.GDBrainSpawnRIGHTObjects9.length = 0;
gdjs.StageCode.GDBurrowObjects1.length = 0;
gdjs.StageCode.GDBurrowObjects2.length = 0;
gdjs.StageCode.GDBurrowObjects3.length = 0;
gdjs.StageCode.GDBurrowObjects4.length = 0;
gdjs.StageCode.GDBurrowObjects5.length = 0;
gdjs.StageCode.GDBurrowObjects6.length = 0;
gdjs.StageCode.GDBurrowObjects7.length = 0;
gdjs.StageCode.GDBurrowObjects8.length = 0;
gdjs.StageCode.GDBurrowObjects9.length = 0;
gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects1.length = 0;
gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects2.length = 0;
gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects3.length = 0;
gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects4.length = 0;
gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects5.length = 0;
gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects6.length = 0;
gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects7.length = 0;
gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects8.length = 0;
gdjs.StageCode.GDHigh_9595Score_9595GameplayObjects9.length = 0;
gdjs.StageCode.GDSkyObjects1.length = 0;
gdjs.StageCode.GDSkyObjects2.length = 0;
gdjs.StageCode.GDSkyObjects3.length = 0;
gdjs.StageCode.GDSkyObjects4.length = 0;
gdjs.StageCode.GDSkyObjects5.length = 0;
gdjs.StageCode.GDSkyObjects6.length = 0;
gdjs.StageCode.GDSkyObjects7.length = 0;
gdjs.StageCode.GDSkyObjects8.length = 0;
gdjs.StageCode.GDSkyObjects9.length = 0;
gdjs.StageCode.GDJerry_9595LogoObjects1.length = 0;
gdjs.StageCode.GDJerry_9595LogoObjects2.length = 0;
gdjs.StageCode.GDJerry_9595LogoObjects3.length = 0;
gdjs.StageCode.GDJerry_9595LogoObjects4.length = 0;
gdjs.StageCode.GDJerry_9595LogoObjects5.length = 0;
gdjs.StageCode.GDJerry_9595LogoObjects6.length = 0;
gdjs.StageCode.GDJerry_9595LogoObjects7.length = 0;
gdjs.StageCode.GDJerry_9595LogoObjects8.length = 0;
gdjs.StageCode.GDJerry_9595LogoObjects9.length = 0;
gdjs.StageCode.GDBrains_9595EatenObjects1.length = 0;
gdjs.StageCode.GDBrains_9595EatenObjects2.length = 0;
gdjs.StageCode.GDBrains_9595EatenObjects3.length = 0;
gdjs.StageCode.GDBrains_9595EatenObjects4.length = 0;
gdjs.StageCode.GDBrains_9595EatenObjects5.length = 0;
gdjs.StageCode.GDBrains_9595EatenObjects6.length = 0;
gdjs.StageCode.GDBrains_9595EatenObjects7.length = 0;
gdjs.StageCode.GDBrains_9595EatenObjects8.length = 0;
gdjs.StageCode.GDBrains_9595EatenObjects9.length = 0;
gdjs.StageCode.GDTransitionObjects1.length = 0;
gdjs.StageCode.GDTransitionObjects2.length = 0;
gdjs.StageCode.GDTransitionObjects3.length = 0;
gdjs.StageCode.GDTransitionObjects4.length = 0;
gdjs.StageCode.GDTransitionObjects5.length = 0;
gdjs.StageCode.GDTransitionObjects6.length = 0;
gdjs.StageCode.GDTransitionObjects7.length = 0;
gdjs.StageCode.GDTransitionObjects8.length = 0;
gdjs.StageCode.GDTransitionObjects9.length = 0;
gdjs.StageCode.GDHigh_9595ScoreObjects1.length = 0;
gdjs.StageCode.GDHigh_9595ScoreObjects2.length = 0;
gdjs.StageCode.GDHigh_9595ScoreObjects3.length = 0;
gdjs.StageCode.GDHigh_9595ScoreObjects4.length = 0;
gdjs.StageCode.GDHigh_9595ScoreObjects5.length = 0;
gdjs.StageCode.GDHigh_9595ScoreObjects6.length = 0;
gdjs.StageCode.GDHigh_9595ScoreObjects7.length = 0;
gdjs.StageCode.GDHigh_9595ScoreObjects8.length = 0;
gdjs.StageCode.GDHigh_9595ScoreObjects9.length = 0;
gdjs.StageCode.GDRocks_9595DestroyedObjects1.length = 0;
gdjs.StageCode.GDRocks_9595DestroyedObjects2.length = 0;
gdjs.StageCode.GDRocks_9595DestroyedObjects3.length = 0;
gdjs.StageCode.GDRocks_9595DestroyedObjects4.length = 0;
gdjs.StageCode.GDRocks_9595DestroyedObjects5.length = 0;
gdjs.StageCode.GDRocks_9595DestroyedObjects6.length = 0;
gdjs.StageCode.GDRocks_9595DestroyedObjects7.length = 0;
gdjs.StageCode.GDRocks_9595DestroyedObjects8.length = 0;
gdjs.StageCode.GDRocks_9595DestroyedObjects9.length = 0;
gdjs.StageCode.GDGames_9595PlayedObjects1.length = 0;
gdjs.StageCode.GDGames_9595PlayedObjects2.length = 0;
gdjs.StageCode.GDGames_9595PlayedObjects3.length = 0;
gdjs.StageCode.GDGames_9595PlayedObjects4.length = 0;
gdjs.StageCode.GDGames_9595PlayedObjects5.length = 0;
gdjs.StageCode.GDGames_9595PlayedObjects6.length = 0;
gdjs.StageCode.GDGames_9595PlayedObjects7.length = 0;
gdjs.StageCode.GDGames_9595PlayedObjects8.length = 0;
gdjs.StageCode.GDGames_9595PlayedObjects9.length = 0;

gdjs.StageCode.eventsList86(runtimeScene);

return;

}

gdjs['StageCode'] = gdjs.StageCode;
