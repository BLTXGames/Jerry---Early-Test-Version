gdjs.DataCode = {};
gdjs.DataCode.GDData_9595BGObjects1= [];
gdjs.DataCode.GDData_9595BGObjects2= [];
gdjs.DataCode.GDData_9595BGObjects3= [];
gdjs.DataCode.GDBurrowObjects1= [];
gdjs.DataCode.GDBurrowObjects2= [];
gdjs.DataCode.GDBurrowObjects3= [];
gdjs.DataCode.GDHigh_9595Score_9595GameplayObjects1= [];
gdjs.DataCode.GDHigh_9595Score_9595GameplayObjects2= [];
gdjs.DataCode.GDHigh_9595Score_9595GameplayObjects3= [];
gdjs.DataCode.GDSkyObjects1= [];
gdjs.DataCode.GDSkyObjects2= [];
gdjs.DataCode.GDSkyObjects3= [];
gdjs.DataCode.GDJerry_9595LogoObjects1= [];
gdjs.DataCode.GDJerry_9595LogoObjects2= [];
gdjs.DataCode.GDJerry_9595LogoObjects3= [];
gdjs.DataCode.GDBrains_9595EatenObjects1= [];
gdjs.DataCode.GDBrains_9595EatenObjects2= [];
gdjs.DataCode.GDBrains_9595EatenObjects3= [];
gdjs.DataCode.GDTransitionObjects1= [];
gdjs.DataCode.GDTransitionObjects2= [];
gdjs.DataCode.GDTransitionObjects3= [];
gdjs.DataCode.GDHigh_9595ScoreObjects1= [];
gdjs.DataCode.GDHigh_9595ScoreObjects2= [];
gdjs.DataCode.GDHigh_9595ScoreObjects3= [];
gdjs.DataCode.GDRocks_9595DestroyedObjects1= [];
gdjs.DataCode.GDRocks_9595DestroyedObjects2= [];
gdjs.DataCode.GDRocks_9595DestroyedObjects3= [];
gdjs.DataCode.GDGames_9595PlayedObjects1= [];
gdjs.DataCode.GDGames_9595PlayedObjects2= [];
gdjs.DataCode.GDGames_9595PlayedObjects3= [];


gdjs.DataCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("GameStorage", "HighScore", runtimeScene, runtimeScene.getScene().getVariables().get("HighScore"));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("HighScore"));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("HighScore").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("High_Score"), gdjs.DataCode.GDHigh_9595ScoreObjects1);
{for(var i = 0, len = gdjs.DataCode.GDHigh_9595ScoreObjects1.length ;i < len;++i) {
    gdjs.DataCode.GDHigh_9595ScoreObjects1[i].getBehavior("Text").setText("High Score: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("HighScore")));
}
}}

}


};gdjs.DataCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("GameStorage", "BrainsEatenNumber", runtimeScene, runtimeScene.getScene().getVariables().get("Brains_Eaten_Number"));
}}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Brains_Eaten_Number")));
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Brains_Eaten"), gdjs.DataCode.GDBrains_9595EatenObjects1);
{for(var i = 0, len = gdjs.DataCode.GDBrains_9595EatenObjects1.length ;i < len;++i) {
    gdjs.DataCode.GDBrains_9595EatenObjects1[i].getBehavior("Text").setText("Brains Eaten: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(5)));
}
}}

}


};gdjs.DataCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("GameStorage", "RocksDestroyedNumber", runtimeScene, runtimeScene.getScene().getVariables().get("Rocks_Destroyed_Number"));
}}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Rocks_Destroyed_Number")));
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Rocks_Destroyed"), gdjs.DataCode.GDRocks_9595DestroyedObjects1);
{for(var i = 0, len = gdjs.DataCode.GDRocks_9595DestroyedObjects1.length ;i < len;++i) {
    gdjs.DataCode.GDRocks_9595DestroyedObjects1[i].getBehavior("Text").setText("Rocks Destroyed: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(7)));
}
}}

}


};gdjs.DataCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("GameStorage", "GamesPlayedNumber", runtimeScene, runtimeScene.getScene().getVariables().get("Games_Played_Number"));
}}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Games_Played_Number")));
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Games_Played"), gdjs.DataCode.GDGames_9595PlayedObjects1);
{for(var i = 0, len = gdjs.DataCode.GDGames_9595PlayedObjects1.length ;i < len;++i) {
    gdjs.DataCode.GDGames_9595PlayedObjects1[i].getBehavior("Text").setText("Games Played: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(8)));
}
}}

}


};gdjs.DataCode.mapOfGDgdjs_9546DataCode_9546GDTransitionObjects1Objects = Hashtable.newFrom({"Transition": gdjs.DataCode.GDTransitionObjects1});
gdjs.DataCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.DataCode.GDTransitionObjects1 */
{for(var i = 0, len = gdjs.DataCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.DataCode.GDTransitionObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Transition", 0, "linear", 0.3, false);
}
}}

}


};gdjs.DataCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.DataCode.GDTransitionObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.DataCode.mapOfGDgdjs_9546DataCode_9546GDTransitionObjects1Objects, 0, 0, "");
}{for(var i = 0, len = gdjs.DataCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.DataCode.GDTransitionObjects1[i].setLayer("Transition");
}
}{for(var i = 0, len = gdjs.DataCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.DataCode.GDTransitionObjects1[i].getBehavior("Resizable").setSize(1920, 1080);
}
}{for(var i = 0, len = gdjs.DataCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.DataCode.GDTransitionObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}
{ //Subevents
gdjs.DataCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.DataCode.mapOfGDgdjs_9546DataCode_9546GDTransitionObjects1Objects = Hashtable.newFrom({"Transition": gdjs.DataCode.GDTransitionObjects1});
gdjs.DataCode.asyncCallback14891508 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title", false);
}}
gdjs.DataCode.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.DataCode.asyncCallback14891508(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.DataCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.DataCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.DataCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.DataCode.GDTransitionObjects1 */
{for(var i = 0, len = gdjs.DataCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.DataCode.GDTransitionObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Transition", 255, "linear", 0.3, false);
}
}
{ //Subevents
gdjs.DataCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.DataCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
gdjs.DataCode.GDTransitionObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.DataCode.mapOfGDgdjs_9546DataCode_9546GDTransitionObjects1Objects, 0, 0, "");
}{for(var i = 0, len = gdjs.DataCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.DataCode.GDTransitionObjects1[i].setLayer("Transition");
}
}{for(var i = 0, len = gdjs.DataCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.DataCode.GDTransitionObjects1[i].getBehavior("Resizable").setSize(1920, 1080);
}
}{for(var i = 0, len = gdjs.DataCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.DataCode.GDTransitionObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(6), true);
}
{ //Subevents
gdjs.DataCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.DataCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Brains_Eaten"), gdjs.DataCode.GDBrains_9595EatenObjects1);
gdjs.copyArray(runtimeScene.getObjects("Games_Played"), gdjs.DataCode.GDGames_9595PlayedObjects1);
gdjs.copyArray(runtimeScene.getObjects("High_Score"), gdjs.DataCode.GDHigh_9595ScoreObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rocks_Destroyed"), gdjs.DataCode.GDRocks_9595DestroyedObjects1);
{for(var i = 0, len = gdjs.DataCode.GDBrains_9595EatenObjects1.length ;i < len;++i) {
    gdjs.DataCode.GDBrains_9595EatenObjects1[i].setCenterXInScene(960);
}
for(var i = 0, len = gdjs.DataCode.GDHigh_9595ScoreObjects1.length ;i < len;++i) {
    gdjs.DataCode.GDHigh_9595ScoreObjects1[i].setCenterXInScene(960);
}
for(var i = 0, len = gdjs.DataCode.GDRocks_9595DestroyedObjects1.length ;i < len;++i) {
    gdjs.DataCode.GDRocks_9595DestroyedObjects1[i].setCenterXInScene(960);
}
for(var i = 0, len = gdjs.DataCode.GDGames_9595PlayedObjects1.length ;i < len;++i) {
    gdjs.DataCode.GDGames_9595PlayedObjects1[i].setCenterXInScene(960);
}
}}

}


{


gdjs.DataCode.eventsList0(runtimeScene);
}


{


gdjs.DataCode.eventsList1(runtimeScene);
}


{


gdjs.DataCode.eventsList2(runtimeScene);
}


{


gdjs.DataCode.eventsList3(runtimeScene);
}


{


gdjs.DataCode.eventsList5(runtimeScene);
}


{


gdjs.DataCode.eventsList9(runtimeScene);
}


};

gdjs.DataCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.DataCode.GDData_9595BGObjects1.length = 0;
gdjs.DataCode.GDData_9595BGObjects2.length = 0;
gdjs.DataCode.GDData_9595BGObjects3.length = 0;
gdjs.DataCode.GDBurrowObjects1.length = 0;
gdjs.DataCode.GDBurrowObjects2.length = 0;
gdjs.DataCode.GDBurrowObjects3.length = 0;
gdjs.DataCode.GDHigh_9595Score_9595GameplayObjects1.length = 0;
gdjs.DataCode.GDHigh_9595Score_9595GameplayObjects2.length = 0;
gdjs.DataCode.GDHigh_9595Score_9595GameplayObjects3.length = 0;
gdjs.DataCode.GDSkyObjects1.length = 0;
gdjs.DataCode.GDSkyObjects2.length = 0;
gdjs.DataCode.GDSkyObjects3.length = 0;
gdjs.DataCode.GDJerry_9595LogoObjects1.length = 0;
gdjs.DataCode.GDJerry_9595LogoObjects2.length = 0;
gdjs.DataCode.GDJerry_9595LogoObjects3.length = 0;
gdjs.DataCode.GDBrains_9595EatenObjects1.length = 0;
gdjs.DataCode.GDBrains_9595EatenObjects2.length = 0;
gdjs.DataCode.GDBrains_9595EatenObjects3.length = 0;
gdjs.DataCode.GDTransitionObjects1.length = 0;
gdjs.DataCode.GDTransitionObjects2.length = 0;
gdjs.DataCode.GDTransitionObjects3.length = 0;
gdjs.DataCode.GDHigh_9595ScoreObjects1.length = 0;
gdjs.DataCode.GDHigh_9595ScoreObjects2.length = 0;
gdjs.DataCode.GDHigh_9595ScoreObjects3.length = 0;
gdjs.DataCode.GDRocks_9595DestroyedObjects1.length = 0;
gdjs.DataCode.GDRocks_9595DestroyedObjects2.length = 0;
gdjs.DataCode.GDRocks_9595DestroyedObjects3.length = 0;
gdjs.DataCode.GDGames_9595PlayedObjects1.length = 0;
gdjs.DataCode.GDGames_9595PlayedObjects2.length = 0;
gdjs.DataCode.GDGames_9595PlayedObjects3.length = 0;

gdjs.DataCode.eventsList10(runtimeScene);

return;

}

gdjs['DataCode'] = gdjs.DataCode;
