gdjs.Gallery_32_45_32DebugCode = {};
gdjs.Gallery_32_45_32DebugCode.GDData_9595BGObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDData_9595BGObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDData_9595BGObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDData_9595BGObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDData_9595BGObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDData_9595BGObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDData_9595BGObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDData_9595BGObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDData_9595BGObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595BGObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595BGObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595BGObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595BGObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595BGObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595BGObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595BGObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595BGObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595BGObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDOriginObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDOriginObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDOriginObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDOriginObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDOriginObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDOriginObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDOriginObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDOriginObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDOriginObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDSkyObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDSkyObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDSkyObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDSkyObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDSkyObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDSkyObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDSkyObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDSkyObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDSkyObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595LogoObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595LogoObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595LogoObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595LogoObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595LogoObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595LogoObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595LogoObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595LogoObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595LogoObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects9= [];
gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects1= [];
gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects2= [];
gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects3= [];
gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects4= [];
gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects5= [];
gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects6= [];
gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects7= [];
gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects8= [];
gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects9= [];


gdjs.Gallery_32_45_32DebugCode.asyncCallback15335628 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 1.aac", false, 100, 1);
}}
gdjs.Gallery_32_45_32DebugCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15335628(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15335484);
}
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15338124 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 1.aac", false, 100, 1);
}}
gdjs.Gallery_32_45_32DebugCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15338124(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15337980);
}
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}{/* Unknown object - skipped. */}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList5 = function(runtimeScene) {

{


gdjs.Gallery_32_45_32DebugCode.eventsList1(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList3(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList4(runtimeScene);
}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15353668 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}}
gdjs.Gallery_32_45_32DebugCode.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15353668(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15352660 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Gallery_32_45_32DebugCode.eventsList8 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15352660(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList9 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList8(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15352020 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList9(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Gallery_32_45_32DebugCode.eventsList10 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15352020(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList11 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList10(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15348764 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList11(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Gallery_32_45_32DebugCode.eventsList12 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15348764(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList13 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList12(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15347756 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList13(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Gallery_32_45_32DebugCode.eventsList14 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15347756(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList15 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList14(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15346748 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList15(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Gallery_32_45_32DebugCode.eventsList16 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15346748(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList17 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList16(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15346108 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList17(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Gallery_32_45_32DebugCode.eventsList18 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15346108(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList20 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
/* Unknown object - skipped. */if (isConditionTrue_1) {
isConditionTrue_1 = false;
{let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
isConditionTrue_2 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
isConditionTrue_2 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "a"));
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
isConditionTrue_2 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right"));
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
isConditionTrue_2 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "d"));
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15343940);
}
}
}
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 1.aac", false, 100, 1);
}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList21 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList22 = function(runtimeScene) {

{


gdjs.Gallery_32_45_32DebugCode.eventsList5(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList20(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList21(runtimeScene);
}


};gdjs.Gallery_32_45_32DebugCode.eventsList23 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{/* Unknown object - skipped. */}}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15359244 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList23(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Gallery_32_45_32DebugCode.eventsList24 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15359244(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList25 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList24(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15358196 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList25(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Gallery_32_45_32DebugCode.eventsList26 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15358196(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList27 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList26(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15356204 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList27(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Gallery_32_45_32DebugCode.eventsList28 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15356204(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList29 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList28(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList30 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15355716);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList29(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList31 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15360356);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15364596 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}}
gdjs.Gallery_32_45_32DebugCode.eventsList32 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15364596(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList33 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{runtimeScene.getScene().getVariables().get("Brains_Eaten_Number").add(1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 2.aac", false, 100, 1);
}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList32(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList34 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
/* Unknown object - skipped. */if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
/* Unknown object - skipped. */if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList33(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15366372 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}}
gdjs.Gallery_32_45_32DebugCode.eventsList35 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15366372(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList36 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().get("Rocks_Destroyed_Number").add(1);
}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList35(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList37 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15365252);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList36(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15368956 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}
gdjs.Gallery_32_45_32DebugCode.eventsList38 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15368956(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList39 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList38(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList40 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15368004);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList39(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList41 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList40(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList42 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("GameStorage", "BrainsEatenNumber", runtimeScene, runtimeScene.getScene().getVariables().get("Brains_Eaten_Number"));
}}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Brains_Eaten_Number")));
}}

}


{



}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeNumberInJSONFile("GameStorage", "BrainsEatenNumber", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Brains_Eaten_Number")));
}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList43 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("GameStorage", "RocksDestroyedNumber", runtimeScene, runtimeScene.getScene().getVariables().get("Rocks_Destroyed_Number"));
}}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Rocks_Destroyed_Number")));
}}

}


{



}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeNumberInJSONFile("GameStorage", "RocksDestroyedNumber", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Rocks_Destroyed_Number")));
}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList44 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("GameStorage", "GamesPlayedNumber", runtimeScene, runtimeScene.getScene().getVariables().get("Games_Played_Number"));
}}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Games_Played_Number")));
}}

}


{



}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeNumberInJSONFile("GameStorage", "GamesPlayedNumber", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Games_Played_Number")));
}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList45 = function(runtimeScene) {

{


gdjs.Gallery_32_45_32DebugCode.eventsList42(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList43(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList44(runtimeScene);
}


};gdjs.Gallery_32_45_32DebugCode.eventsList46 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Gameplay");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList47 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burrow"), gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects3);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects3[i].getBehavior("Animation").setAnimationName("Night");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burrow"), gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects3);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects3[i].getBehavior("Animation").setAnimationName("Day");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__October.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burrow"), gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects3);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects3[i].getBehavior("Animation").setAnimationName("Halloween");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__December.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burrow"), gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects2[i].getBehavior("Animation").setAnimationName("Christmas");
}
}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList48 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Dawn.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.Gallery_32_45_32DebugCode.GDSkyObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSkyObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSkyObjects2[i].getBehavior("Animation").setAnimationName("Dawn");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Morning.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.Gallery_32_45_32DebugCode.GDSkyObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSkyObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSkyObjects2[i].getBehavior("Animation").setAnimationName("Day");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Dusk.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.Gallery_32_45_32DebugCode.GDSkyObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSkyObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSkyObjects2[i].getBehavior("Animation").setAnimationName("Dusk");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.Gallery_32_45_32DebugCode.GDSkyObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSkyObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSkyObjects2[i].getBehavior("Animation").setAnimationName("Night");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__October.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.Gallery_32_45_32DebugCode.GDSkyObjects1);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSkyObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSkyObjects1[i].getBehavior("Animation").setAnimationName("Halloween");
}
}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList49 = function(runtimeScene) {

{


gdjs.Gallery_32_45_32DebugCode.eventsList47(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList48(runtimeScene);
}


};gdjs.Gallery_32_45_32DebugCode.eventsList50 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainSpawn");
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 10;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "BrainSpawn") > 5;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainSpawn");
}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 10;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "BrainSpawn") > 5;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainSpawn");
}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 50;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "BrainSpawn") > 5;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainSpawn");
}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList51 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList52 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) >= 3);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList51(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList53 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList54 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) >= 3);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList53(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList55 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainScrollingSpeed");
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.setLayerTimeScale(runtimeScene, "Brains", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("BrainScrollingSpeed")));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "BrainScrollingSpeed") >= 90;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("BrainScrollingSpeed").add(0.6);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainScrollingSpeed");
}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList56 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList57 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 1;
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 2;
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 3;
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback14681804 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList57(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.Gallery_32_45_32DebugCode.eventsList58 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback14681804(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList59 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 4.aac", false, 100, 0.5);
}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList58(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList60 = function(runtimeScene) {

{


gdjs.Gallery_32_45_32DebugCode.eventsList50(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList52(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList54(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList55(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList56(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList59(runtimeScene);
}


};gdjs.Gallery_32_45_32DebugCode.eventsList61 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "RockSpawn");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Gameplay") > 30;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "RockSpawn") > 30;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "RockSpawn");
}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList62 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "RockFallingSpeed");
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.setLayerTimeScale(runtimeScene, "Rocks", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("RockFallingSpeed")));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "RockFallingSpeed") >= 90;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("RockFallingSpeed").add(0.7);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "RockFallingSpeed");
}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList63 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) >= 3);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


gdjs.Gallery_32_45_32DebugCode.eventsList62(runtimeScene);
}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback14694292 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}}
gdjs.Gallery_32_45_32DebugCode.eventsList64 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback14694292(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList65 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList64(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList66 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14695748);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(5);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 2.aac", false, 100, 1);
}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList67 = function(runtimeScene) {

{


gdjs.Gallery_32_45_32DebugCode.eventsList61(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList63(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList65(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList66(runtimeScene);
}


};gdjs.Gallery_32_45_32DebugCode.eventsList68 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 3;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title", false);
}}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback14698556 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getScene().getVariables().get("Games_Played_Number").add(1);
}}
gdjs.Gallery_32_45_32DebugCode.eventsList69 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(52), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback14698556(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList70 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14698332);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList69(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList71 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num1");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Delete");
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14700316);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("HighScore").setNumber(0);
}{runtimeScene.getScene().getVariables().get("Brains_Eaten_Number").setNumber(0);
}{runtimeScene.getScene().getVariables().get("Games_Played_Number").setNumber(0);
}{runtimeScene.getScene().getVariables().get("Rocks_Destroyed_Number").setNumber(0);
}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList72 = function(runtimeScene) {

{


gdjs.Gallery_32_45_32DebugCode.eventsList71(runtimeScene);
}


};gdjs.Gallery_32_45_32DebugCode.eventsList73 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("GameStorage", "HighScore", runtimeScene, runtimeScene.getScene().getVariables().get("HighScore"));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("HighScore"));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("HighScore").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("High_Score_Gameplay"), gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects2[i].getBehavior("Text").setText("High Score: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("HighScore")));
}
}{gdjs.evtTools.storage.writeNumberInJSONFile("GameStorage", "HighScore", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("HighScore")));
}}

}


{


let isConditionTrue_0 = false;
{
{/* Unknown object - skipped. */}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList74 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList75 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList76 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14705820);
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList74(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14707396);
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14708140);
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList75(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14709716);
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList77 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14710596);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14711500);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList78 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList76(runtimeScene);} //End of subevents
}

}


{


gdjs.Gallery_32_45_32DebugCode.eventsList77(runtimeScene);
}


};gdjs.Gallery_32_45_32DebugCode.eventsList79 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) >= 3;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) >= 10;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
}}

}


{



}


{



}


{



}


{



}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) >= 20;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), true);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) >= 50;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), true);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 500;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(13), true);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 1000;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) >= 200;
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(14), true);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 1500;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), true);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 3000;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) >= 500;
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(16), true);
}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList80 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 3;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage", false);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title", false);
}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList81 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num2");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "NumpadReturn");
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14726532);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(13), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(14), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(16), true);
}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList82 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num2");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Delete");
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14729444);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(13), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(14), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(16), false);
}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList83 = function(runtimeScene) {

{


gdjs.Gallery_32_45_32DebugCode.eventsList80(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList81(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList82(runtimeScene);
}


};gdjs.Gallery_32_45_32DebugCode.eventsList84 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isPreview(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList83(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15103364 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Not_Selected"), gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects2);
gdjs.copyArray(runtimeScene.getObjects("Select_Cursor"), gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects2[i].setCenterPositionInScene((( gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects2[0].getCenterXInScene()),(( gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects2[0].getCenterYInScene()));
}
}}
gdjs.Gallery_32_45_32DebugCode.eventsList85 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15103364(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList86 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Not_Selected"), gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects2);
gdjs.copyArray(runtimeScene.getObjects("Select_Cursor"), gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects2);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), false);
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects2[i].setCenterPositionInScene((( gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects2[0].getCenterXInScene()),(( gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Select_Cursor"), gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Selected"), gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects2[i].setCenterPositionInScene((( gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects2[0].getCenterXInScene()),(( gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects2[0].getCenterYInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList85(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList87 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Brains_Eaten"), gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects2);
gdjs.copyArray(runtimeScene.getObjects("Games_Played"), gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects2);
gdjs.copyArray(runtimeScene.getObjects("High_Score"), gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rocks_Destroyed"), gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects2[i].setCenterXInScene(960);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects2[i].setCenterXInScene(960);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects2[i].setCenterXInScene(960);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects2[i].setCenterXInScene(960);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects2[i].setCenterYInScene(540);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects2[i].setCenterYInScene(540);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects2[i].setCenterYInScene(540);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects2[i].setCenterYInScene(540);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects2[i].setCenterYInScene(540);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects2[i].setCenterYInScene(540);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects2[i].setCenterYInScene(540);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects2[i].setCenterYInScene(540);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Character_Name"), gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects2);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects2[i].setY((( gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects2[0].getY()) :gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects2[0].getY()) :gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects2[0].getY()) :gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects2[0].getY()) :gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects2[0].getY()) :gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects2[0].getY()) :gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects2[0].getY()) :gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects2[0].getY()) - 100);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects2[i].setCenterXInScene((( gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects2[0].getCenterXInScene()) :gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects2[0].getCenterXInScene()) :gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects2[0].getCenterXInScene()) :gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects2[0].getCenterXInScene()) :gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects2[0].getCenterXInScene()) :gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects2[0].getCenterXInScene()) :gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects2[0].getCenterXInScene()) :gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects2[0].getCenterXInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Border_Bottom"), gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects2);
gdjs.copyArray(runtimeScene.getObjects("Border_L"), gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects2);
gdjs.copyArray(runtimeScene.getObjects("Border_R"), gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects2);
gdjs.copyArray(runtimeScene.getObjects("Border_Top"), gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Image"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects2);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Image"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects2);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Image"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects2);
gdjs.copyArray(runtimeScene.getObjects("Gallery_Image_Box"), gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Image"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Image"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects2);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Image"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Image"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Image"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects2[i].setCenterPositionInScene((( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2[0].getPointX("")),(( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects2[i].setCenterPositionInScene((( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2[0].getPointX("")),(( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects2[i].setCenterPositionInScene((( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2[0].getPointX("")),(( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects2[i].setCenterPositionInScene((( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2[0].getPointX("")),(( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects2[i].setCenterPositionInScene((( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2[0].getPointX("")),(( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects2[i].setCenterPositionInScene((( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2[0].getPointX("")),(( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects2[i].setCenterPositionInScene((( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2[0].getPointX("")),(( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects2[i].setCenterPositionInScene((( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2[0].getPointX("")),(( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2[i].hide();
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].setCenterXInScene(960);
}
}}

}


{


gdjs.Gallery_32_45_32DebugCode.eventsList86(runtimeScene);
}


};gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDBorder_95959595RObjects2Objects = Hashtable.newFrom({"Border_R": gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Jerry_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2, "Rudy_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects2, "Conquest_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects2, "Libby_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects2, "General_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects2, "Zombie_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects2, "Alien_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects2, "Carcass_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDBorder_95959595LObjects2Objects = Hashtable.newFrom({"Border_L": gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Jerry_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2, "Rudy_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects2, "Conquest_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects2, "Libby_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects2, "General_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects2, "Zombie_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects2, "Alien_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects2, "Carcass_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDBorder_95959595BottomObjects2Objects = Hashtable.newFrom({"Border_Bottom": gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Jerry_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2, "Rudy_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects2, "Conquest_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects2, "Libby_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects2, "General_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects2, "Zombie_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects2, "Alien_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects2, "Carcass_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDBorder_95959595TopObjects1Objects = Hashtable.newFrom({"Border_Top": gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects1});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Jerry_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects1, "Rudy_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects1, "Conquest_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects1, "Libby_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects1, "General_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects1, "Zombie_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects1, "Alien_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects1, "Carcass_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects1});
gdjs.Gallery_32_45_32DebugCode.eventsList88 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15104348);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2);
gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, (( gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2[0].getPointX("")), (( gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Resizable").setSize(300, 352);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Border_R"), gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects2);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDBorder_95959595RObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15105372);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2 */
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].setX(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].getX() + (437));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Border_L"), gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects2);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDBorder_95959595LObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15106684);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2 */
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].setX(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].getX() - (437));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Border_Bottom"), gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects2);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDBorder_95959595BottomObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15108556);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2 */
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].setY(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].getY() + (448));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Border_Top"), gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects1);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDBorder_95959595TopObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15109300);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1 */
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1[i].setY(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1[i].getY() - (448));
}
}}

}


};gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Jerry_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDSelect_95959595CursorObjects2Objects = Hashtable.newFrom({"Select_Cursor": gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDNot_95959595SelectedObjects2Objects = Hashtable.newFrom({"Not_Selected": gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDJerry_95959595Gallery_95959595TextObjects4Objects = Hashtable.newFrom({"Jerry_Gallery_Text": gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects4});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDJerry_95959595Gallery_95959595ImageObjects4Objects = Hashtable.newFrom({"Jerry_Gallery_Image": gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects4});
gdjs.Gallery_32_45_32DebugCode.asyncCallback15115620 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Gallery_Image_Box"), gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4);
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects4.length = 0;

gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDJerry_95959595Gallery_95959595TextObjects4Objects, 692, 320, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDJerry_95959595Gallery_95959595ImageObjects4Objects, (( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4[0].getPointX("")), (( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4[0].getPointY("")), "");
}}
gdjs.Gallery_32_45_32DebugCode.eventsList89 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15115620(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15116916 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3);

{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].setX(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].getX() - (3000));
}
}}
gdjs.Gallery_32_45_32DebugCode.eventsList90 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2) asyncObjectsList.addObject("Hover_Gallery_Thumbnail", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.12), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15116916(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList91 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Character_Name"), gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2, gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2, gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3[i].getBehavior("Text").setText("Jerry");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList89(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15116844);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList90(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList92 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15113068);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), true);
}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList91(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList93 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Animation").setAnimationName("Gallery Thumbnail Jerry");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Not_Selected"), gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects2);
gdjs.copyArray(runtimeScene.getObjects("Select_Cursor"), gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDSelect_95959595CursorObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDNot_95959595SelectedObjects2Objects, false, runtimeScene, false);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList92(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Rudy_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDRudy_95959595Gallery_95959595TextObjects4Objects = Hashtable.newFrom({"Rudy_Gallery_Text": gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects4});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDRudy_95959595Gallery_95959595ImageObjects4Objects = Hashtable.newFrom({"Rudy_Gallery_Image": gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects4});
gdjs.Gallery_32_45_32DebugCode.asyncCallback15121108 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Gallery_Image_Box"), gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4);
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects4.length = 0;

gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDRudy_95959595Gallery_95959595TextObjects4Objects, 692, 320, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDRudy_95959595Gallery_95959595ImageObjects4Objects, (( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4[0].getPointX("")), (( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4[0].getPointY("")), "");
}}
gdjs.Gallery_32_45_32DebugCode.eventsList94 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15121108(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15122404 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3);

{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].setX(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].getX() - (3000));
}
}}
gdjs.Gallery_32_45_32DebugCode.eventsList95 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2) asyncObjectsList.addObject("Hover_Gallery_Thumbnail", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.12), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15122404(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList96 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Character_Name"), gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2, gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects2, gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3[i].getBehavior("Text").setText("Rudy The Brain Rabbit");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList94(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15122332);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList95(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList97 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Animation").setAnimationName("Gallery Thumbnail Rudy");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList96(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Zombie_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDZombie_95959595Gallery_95959595TextObjects4Objects = Hashtable.newFrom({"Zombie_Gallery_Text": gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects4});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDZombie_95959595Gallery_95959595ImageObjects4Objects = Hashtable.newFrom({"Zombie_Gallery_Image": gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects4});
gdjs.Gallery_32_45_32DebugCode.asyncCallback15126708 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Gallery_Image_Box"), gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4);
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects4.length = 0;

gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDZombie_95959595Gallery_95959595TextObjects4Objects, 692, 320, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDZombie_95959595Gallery_95959595ImageObjects4Objects, (( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4[0].getPointX("")), (( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4[0].getPointY("")), "");
}}
gdjs.Gallery_32_45_32DebugCode.eventsList98 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15126708(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15127996 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3);

{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].setX(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].getX() - (3000));
}
}}
gdjs.Gallery_32_45_32DebugCode.eventsList99 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2) asyncObjectsList.addObject("Hover_Gallery_Thumbnail", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.12), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15127996(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList100 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Character_Name"), gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2, gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3);
gdjs.copyArray(gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects2, gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3);

{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3[i].getBehavior("Text").setText("Zombie Gerbil");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList98(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15126844);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList99(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList101 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Animation").setAnimationName("Gallery Thumbnail Zombie");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList100(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Alien_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDAlien_95959595Gallery_95959595TextObjects4Objects = Hashtable.newFrom({"Alien_Gallery_Text": gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects4});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDAlien_95959595Gallery_95959595ImageObjects4Objects = Hashtable.newFrom({"Alien_Gallery_Image": gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects4});
gdjs.Gallery_32_45_32DebugCode.asyncCallback15132284 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Gallery_Image_Box"), gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4);
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects4.length = 0;

gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDAlien_95959595Gallery_95959595TextObjects4Objects, 692, 320, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDAlien_95959595Gallery_95959595ImageObjects4Objects, (( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4[0].getPointX("")), (( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4[0].getPointY("")), "");
}}
gdjs.Gallery_32_45_32DebugCode.eventsList102 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15132284(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15133604 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3);

{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].setX(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].getX() - (3000));
}
}}
gdjs.Gallery_32_45_32DebugCode.eventsList103 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2) asyncObjectsList.addObject("Hover_Gallery_Thumbnail", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.12), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15133604(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList104 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects2, gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Character_Name"), gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2, gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3[i].getBehavior("Text").setText("Alien");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList102(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15133532);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList103(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList105 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Animation").setAnimationName("Gallery Thumbnail Alien");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList104(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Conquest_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDConquest_95959595Gallery_95959595TextObjects4Objects = Hashtable.newFrom({"Conquest_Gallery_Text": gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects4});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDConquest_95959595Gallery_95959595ImageObjects4Objects = Hashtable.newFrom({"Conquest_Gallery_Image": gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects4});
gdjs.Gallery_32_45_32DebugCode.asyncCallback15137916 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Gallery_Image_Box"), gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4);
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects4.length = 0;

gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDConquest_95959595Gallery_95959595TextObjects4Objects, 692, 320, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDConquest_95959595Gallery_95959595ImageObjects4Objects, (( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4[0].getPointX("")), (( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4[0].getPointY("")), "");
}}
gdjs.Gallery_32_45_32DebugCode.eventsList106 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15137916(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15139204 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3);

{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].setX(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].getX() - (3000));
}
}}
gdjs.Gallery_32_45_32DebugCode.eventsList107 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2) asyncObjectsList.addObject("Hover_Gallery_Thumbnail", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.12), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15139204(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList108 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Character_Name"), gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3);
gdjs.copyArray(gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects2, gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2, gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3[i].getBehavior("Text").setText("Dr. Conquest");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList106(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15138052);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList107(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList109 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(13), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Animation").setAnimationName("Gallery Thumbnail Conquest");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(13), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList108(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Carcass_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDCarcass_95959595Gallery_95959595TextObjects4Objects = Hashtable.newFrom({"Carcass_Gallery_Text": gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects4});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDCarcass_95959595Gallery_95959595ImageObjects4Objects = Hashtable.newFrom({"Carcass_Gallery_Image": gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects4});
gdjs.Gallery_32_45_32DebugCode.asyncCallback15143652 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Gallery_Image_Box"), gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4);
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects4.length = 0;

gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDCarcass_95959595Gallery_95959595TextObjects4Objects, 692, 320, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDCarcass_95959595Gallery_95959595ImageObjects4Objects, (( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4[0].getPointX("")), (( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4[0].getPointY("")), "");
}}
gdjs.Gallery_32_45_32DebugCode.eventsList110 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15143652(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15144868 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3);

{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].setX(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].getX() - (3000));
}
}}
gdjs.Gallery_32_45_32DebugCode.eventsList111 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2) asyncObjectsList.addObject("Hover_Gallery_Thumbnail", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.12), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15144868(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList112 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects2, gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Character_Name"), gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2, gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3[i].getBehavior("Text").setText("Gerbil Carcass");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList110(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15144708);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList111(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList113 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(14), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Animation").setAnimationName("Gallery Thumbnail Carcass");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(14), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList112(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"General_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDGeneral_95959595Gallery_95959595TextObjects4Objects = Hashtable.newFrom({"General_Gallery_Text": gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects4});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDGeneral_95959595Gallery_95959595ImageObjects4Objects = Hashtable.newFrom({"General_Gallery_Image": gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects4});
gdjs.Gallery_32_45_32DebugCode.asyncCallback15149244 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Gallery_Image_Box"), gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4);
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects4.length = 0;

gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDGeneral_95959595Gallery_95959595TextObjects4Objects, 692, 320, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDGeneral_95959595Gallery_95959595ImageObjects4Objects, (( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4[0].getPointX("")), (( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4[0].getPointY("")), "");
}}
gdjs.Gallery_32_45_32DebugCode.eventsList114 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15149244(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15150540 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3);

{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].setX(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].getX() - (3000));
}
}}
gdjs.Gallery_32_45_32DebugCode.eventsList115 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2) asyncObjectsList.addObject("Hover_Gallery_Thumbnail", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.12), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15150540(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList116 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Character_Name"), gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects2, gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2, gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3[i].getBehavior("Text").setText("General");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList114(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15150468);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList115(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList117 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Animation").setAnimationName("Gallery Thumbnail General");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList116(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Libby_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects1});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDLibby_95959595Gallery_95959595TextObjects3Objects = Hashtable.newFrom({"Libby_Gallery_Text": gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects3});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDLibby_95959595Gallery_95959595ImageObjects3Objects = Hashtable.newFrom({"Libby_Gallery_Image": gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects3});
gdjs.Gallery_32_45_32DebugCode.asyncCallback15154748 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Gallery_Image_Box"), gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects3);
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects3.length = 0;

gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDLibby_95959595Gallery_95959595TextObjects3Objects, 692, 320, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDLibby_95959595Gallery_95959595ImageObjects3Objects, (( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects3.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects3[0].getPointX("")), (( gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects3.length === 0 ) ? 0 :gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects3[0].getPointY("")), "");
}}
gdjs.Gallery_32_45_32DebugCode.eventsList118 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15154748(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.asyncCallback15156068 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);

{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].setX(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].getX() - (3000));
}
}}
gdjs.Gallery_32_45_32DebugCode.eventsList119 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1) asyncObjectsList.addObject("Hover_Gallery_Thumbnail", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.12), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15156068(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList120 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Character_Name"), gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects2);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1, gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);

gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects1, gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects2);

gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects2[i].getBehavior("Text").setText("Libby");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList118(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15155996);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList119(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList121 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(16), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Animation").setAnimationName("Gallery Thumbnail Libby");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(16), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList120(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList122 = function(runtimeScene) {

{


gdjs.Gallery_32_45_32DebugCode.eventsList93(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList97(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList101(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList105(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList109(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList113(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList117(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList121(runtimeScene);
}


};gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDSelect_95959595CursorObjects1Objects = Hashtable.newFrom({"Select_Cursor": gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects1});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDSelectedObjects1Objects = Hashtable.newFrom({"Selected": gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects1});
gdjs.Gallery_32_45_32DebugCode.asyncCallback15159460 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);

{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].setX(gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].getX() + (3000));
}
}}
gdjs.Gallery_32_45_32DebugCode.eventsList123 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1) asyncObjectsList.addObject("Hover_Gallery_Thumbnail", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.12), (runtimeScene) => (gdjs.Gallery_32_45_32DebugCode.asyncCallback15159460(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList124 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList123(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList125 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15157548);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Image"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects1);
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Image"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects1);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Image"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects1);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Image"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects1);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects1);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Image"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects1);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Image"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects1);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Image"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects1);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Image"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects1);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Text"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects1);
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(0), false);
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 149, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 149, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 149, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 149, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 597, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 597, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 597, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 597, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList124(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList126 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Select_Cursor"), gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Selected"), gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDSelect_95959595CursorObjects1Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDSelectedObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList125(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Jerry_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Rudy_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.eventsList127 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
if (isConditionTrue_0) {
/* Reuse gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2 */
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Play 10 Games");
}
}}

}


};gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Zombie_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.eventsList128 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
if (isConditionTrue_0) {
/* Reuse gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2 */
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Play 20 Games");
}
}}

}


};gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Alien_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.eventsList129 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) >= 1;
if (isConditionTrue_0) {
/* Reuse gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2 */
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Destroy 50 Rocks");
}
}}

}


};gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Conquest_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.eventsList130 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 250;
if (isConditionTrue_0) {
/* Reuse gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2 */
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Eat 500 Brains");
}
}}

}


};gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Carcass_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.eventsList131 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 500;
if (isConditionTrue_0) {
/* Reuse gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2 */
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Eat 1000 Brains and destroy 200 rocks");
}
}}

}


};gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"General_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.eventsList132 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 500;
if (isConditionTrue_0) {
/* Reuse gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2 */
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Eat 1500 Brains");
}
}}

}


};gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Libby_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects1});
gdjs.Gallery_32_45_32DebugCode.eventsList133 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Play 3 Games");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("???");
}
}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList127(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("???");
}
}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList128(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("???");
}
}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList129(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(13), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("???");
}
}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList130(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(14), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("???");
}
}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList131(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("???");
}
}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList132(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(16), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects1);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects1[i].getBehavior("Text").setText("???");
}
}}

}


};gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Jerry_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Rudy_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Zombie_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Alien_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Conquest_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Carcass_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"General_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects2});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1});
gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Libby_Gallery_Thumbnail": gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects1});
gdjs.Gallery_32_45_32DebugCode.eventsList134 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Jerry - Play 3 games");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Rudy - Play 10 Games");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), true);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Zombie Gerbil - Play 20 Games");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), true);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Alien - Destroy 50 Rocks");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(13), true);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Dr. Conquest - Eat 500 Brains");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(14), true);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Gerbil Carcass - Eat 1000 Briains, and destroy 200 rocks.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), true);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("General - Eat 1500 Brains.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects, gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(16), true);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects1);
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects1[i].getBehavior("Text").setText("Libby - Eat 3000 Brains, and Destroy 500 Rocks.");
}
}}

}


};gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDTransitionObjects1Objects = Hashtable.newFrom({"Transition": gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects1});
gdjs.Gallery_32_45_32DebugCode.eventsList135 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects1 */
{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Transition", 0, "linear", 0.3, false);
}
}}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList136 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Gallery_32_45_32DebugCode.mapOfGDgdjs_9546Gallery_959532_959545_959532DebugCode_9546GDTransitionObjects1Objects, 0, 0, "");
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects1[i].setLayer("Transition");
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects1[i].getBehavior("Resizable").setSize(1920, 1080);
}
}{for(var i = 0, len = gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}
{ //Subevents
gdjs.Gallery_32_45_32DebugCode.eventsList135(runtimeScene);} //End of subevents
}

}


};gdjs.Gallery_32_45_32DebugCode.eventsList137 = function(runtimeScene) {

{



}


{



}


{


gdjs.Gallery_32_45_32DebugCode.eventsList22(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList30(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList31(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList34(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList37(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList41(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList45(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList46(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList49(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList60(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList67(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList68(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList70(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList72(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList73(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList78(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList79(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList84(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList87(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList88(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList122(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList126(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList133(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList134(runtimeScene);
}


{


gdjs.Gallery_32_45_32DebugCode.eventsList136(runtimeScene);
}


{



}


};

gdjs.Gallery_32_45_32DebugCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Gallery_32_45_32DebugCode.GDData_9595BGObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDData_9595BGObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDData_9595BGObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDData_9595BGObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDData_9595BGObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDData_9595BGObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDData_9595BGObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDData_9595BGObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDData_9595BGObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ThumbnailObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHover_9595Gallery_9595ThumbnailObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ThumbnailObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595LObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595RObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ThumbnailObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ThumbnailObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595BottomObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBorder_9595TopObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ThumbnailObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ThumbnailObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ThumbnailObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ThumbnailObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595TextObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595Gallery_9595ImageObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595Image_9595BoxObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelected_9595ItemObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595ImageObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRudy_9595Gallery_9595TextObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595ImageObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDAlien_9595Gallery_9595TextObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595ImageObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDZombie_9595Gallery_9595TextObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595ImageObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595ImageObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595ImageObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595ImageObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDConquest_9595Gallery_9595TextObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCarcass_9595Gallery_9595TextObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGeneral_9595Gallery_9595TextObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDLibby_9595Gallery_9595TextObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595BGObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595BGObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595BGObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595BGObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595BGObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595BGObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595BGObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595BGObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGallery_9595BGObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDCharacter_9595NameObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDOriginObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDOriginObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDOriginObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDOriginObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDOriginObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDOriginObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDOriginObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDOriginObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDOriginObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelectedObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDNot_9595SelectedObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSelect_9595CursorObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBurrowObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595Score_9595GameplayObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSkyObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSkyObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSkyObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSkyObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSkyObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSkyObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSkyObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSkyObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDSkyObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595LogoObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595LogoObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595LogoObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595LogoObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595LogoObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595LogoObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595LogoObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595LogoObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDJerry_9595LogoObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDBrains_9595EatenObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDTransitionObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDHigh_9595ScoreObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDRocks_9595DestroyedObjects9.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects1.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects2.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects3.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects4.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects5.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects6.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects7.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects8.length = 0;
gdjs.Gallery_32_45_32DebugCode.GDGames_9595PlayedObjects9.length = 0;

gdjs.Gallery_32_45_32DebugCode.eventsList137(runtimeScene);

return;

}

gdjs['Gallery_32_45_32DebugCode'] = gdjs.Gallery_32_45_32DebugCode;
