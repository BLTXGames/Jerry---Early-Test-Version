gdjs.TitleCode = {};
gdjs.TitleCode.GDVerObjects1= [];
gdjs.TitleCode.GDVerObjects2= [];
gdjs.TitleCode.GDVerObjects3= [];
gdjs.TitleCode.GDVerObjects4= [];
gdjs.TitleCode.GDSTARTObjects1= [];
gdjs.TitleCode.GDSTARTObjects2= [];
gdjs.TitleCode.GDSTARTObjects3= [];
gdjs.TitleCode.GDSTARTObjects4= [];
gdjs.TitleCode.GDDATAObjects1= [];
gdjs.TitleCode.GDDATAObjects2= [];
gdjs.TitleCode.GDDATAObjects3= [];
gdjs.TitleCode.GDDATAObjects4= [];
gdjs.TitleCode.GDGALLERYObjects1= [];
gdjs.TitleCode.GDGALLERYObjects2= [];
gdjs.TitleCode.GDGALLERYObjects3= [];
gdjs.TitleCode.GDGALLERYObjects4= [];
gdjs.TitleCode.GDCursorObjects1= [];
gdjs.TitleCode.GDCursorObjects2= [];
gdjs.TitleCode.GDCursorObjects3= [];
gdjs.TitleCode.GDCursorObjects4= [];
gdjs.TitleCode.GDCursor_9595Border_9595TopObjects1= [];
gdjs.TitleCode.GDCursor_9595Border_9595TopObjects2= [];
gdjs.TitleCode.GDCursor_9595Border_9595TopObjects3= [];
gdjs.TitleCode.GDCursor_9595Border_9595TopObjects4= [];
gdjs.TitleCode.GDCursor_9595Border_9595BottomObjects1= [];
gdjs.TitleCode.GDCursor_9595Border_9595BottomObjects2= [];
gdjs.TitleCode.GDCursor_9595Border_9595BottomObjects3= [];
gdjs.TitleCode.GDCursor_9595Border_9595BottomObjects4= [];
gdjs.TitleCode.GDCopyrightObjects1= [];
gdjs.TitleCode.GDCopyrightObjects2= [];
gdjs.TitleCode.GDCopyrightObjects3= [];
gdjs.TitleCode.GDCopyrightObjects4= [];
gdjs.TitleCode.GDBurrowObjects1= [];
gdjs.TitleCode.GDBurrowObjects2= [];
gdjs.TitleCode.GDBurrowObjects3= [];
gdjs.TitleCode.GDBurrowObjects4= [];
gdjs.TitleCode.GDHigh_9595Score_9595GameplayObjects1= [];
gdjs.TitleCode.GDHigh_9595Score_9595GameplayObjects2= [];
gdjs.TitleCode.GDHigh_9595Score_9595GameplayObjects3= [];
gdjs.TitleCode.GDHigh_9595Score_9595GameplayObjects4= [];
gdjs.TitleCode.GDSkyObjects1= [];
gdjs.TitleCode.GDSkyObjects2= [];
gdjs.TitleCode.GDSkyObjects3= [];
gdjs.TitleCode.GDSkyObjects4= [];
gdjs.TitleCode.GDJerry_9595LogoObjects1= [];
gdjs.TitleCode.GDJerry_9595LogoObjects2= [];
gdjs.TitleCode.GDJerry_9595LogoObjects3= [];
gdjs.TitleCode.GDJerry_9595LogoObjects4= [];
gdjs.TitleCode.GDBrains_9595EatenObjects1= [];
gdjs.TitleCode.GDBrains_9595EatenObjects2= [];
gdjs.TitleCode.GDBrains_9595EatenObjects3= [];
gdjs.TitleCode.GDBrains_9595EatenObjects4= [];
gdjs.TitleCode.GDTransitionObjects1= [];
gdjs.TitleCode.GDTransitionObjects2= [];
gdjs.TitleCode.GDTransitionObjects3= [];
gdjs.TitleCode.GDTransitionObjects4= [];
gdjs.TitleCode.GDHigh_9595ScoreObjects1= [];
gdjs.TitleCode.GDHigh_9595ScoreObjects2= [];
gdjs.TitleCode.GDHigh_9595ScoreObjects3= [];
gdjs.TitleCode.GDHigh_9595ScoreObjects4= [];
gdjs.TitleCode.GDRocks_9595DestroyedObjects1= [];
gdjs.TitleCode.GDRocks_9595DestroyedObjects2= [];
gdjs.TitleCode.GDRocks_9595DestroyedObjects3= [];
gdjs.TitleCode.GDRocks_9595DestroyedObjects4= [];
gdjs.TitleCode.GDGames_9595PlayedObjects1= [];
gdjs.TitleCode.GDGames_9595PlayedObjects2= [];
gdjs.TitleCode.GDGames_9595PlayedObjects3= [];
gdjs.TitleCode.GDGames_9595PlayedObjects4= [];


gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects2Objects = Hashtable.newFrom({"Cursor": gdjs.TitleCode.GDCursorObjects2});
gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects2Objects = Hashtable.newFrom({"Cursor": gdjs.TitleCode.GDCursorObjects2});
gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursor_95959595Border_95959595TopObjects2Objects = Hashtable.newFrom({"Cursor_Border_Top": gdjs.TitleCode.GDCursor_9595Border_9595TopObjects2});
gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.TitleCode.GDCursorObjects1});
gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursor_95959595Border_95959595BottomObjects1Objects = Hashtable.newFrom({"Cursor_Border_Bottom": gdjs.TitleCode.GDCursor_9595Border_9595BottomObjects1});
gdjs.TitleCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.TitleCode.GDCursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cursor_Border_Top"), gdjs.TitleCode.GDCursor_9595Border_9595TopObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects2Objects, gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursor_95959595Border_95959595TopObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14830068);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TitleCode.GDCursorObjects2 */
{for(var i = 0, len = gdjs.TitleCode.GDCursorObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDCursorObjects2[i].setY(gdjs.TitleCode.GDCursorObjects2[i].getY() - (100));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.TitleCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Cursor_Border_Bottom"), gdjs.TitleCode.GDCursor_9595Border_9595BottomObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects1Objects, gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursor_95959595Border_95959595BottomObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14831020);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TitleCode.GDCursorObjects1 */
{for(var i = 0, len = gdjs.TitleCode.GDCursorObjects1.length ;i < len;++i) {
    gdjs.TitleCode.GDCursorObjects1[i].setY(gdjs.TitleCode.GDCursorObjects1[i].getY() + (100));
}
}}

}


};gdjs.TitleCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.input.hideCursor(runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("DATA"), gdjs.TitleCode.GDDATAObjects2);
gdjs.copyArray(runtimeScene.getObjects("GALLERY"), gdjs.TitleCode.GDGALLERYObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Logo"), gdjs.TitleCode.GDJerry_9595LogoObjects2);
gdjs.copyArray(runtimeScene.getObjects("START"), gdjs.TitleCode.GDSTARTObjects2);
{for(var i = 0, len = gdjs.TitleCode.GDSTARTObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDSTARTObjects2[i].setCenterXInScene(960);
}
for(var i = 0, len = gdjs.TitleCode.GDDATAObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDDATAObjects2[i].setCenterXInScene(960);
}
for(var i = 0, len = gdjs.TitleCode.GDJerry_9595LogoObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDJerry_9595LogoObjects2[i].setCenterXInScene(960);
}
for(var i = 0, len = gdjs.TitleCode.GDGALLERYObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDGALLERYObjects2[i].setCenterXInScene(960);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14826740);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("START"), gdjs.TitleCode.GDSTARTObjects2);
gdjs.TitleCode.GDCursorObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects2Objects, (( gdjs.TitleCode.GDSTARTObjects2.length === 0 ) ? 0 :gdjs.TitleCode.GDSTARTObjects2[0].getX()), (( gdjs.TitleCode.GDSTARTObjects2.length === 0 ) ? 0 :gdjs.TitleCode.GDSTARTObjects2[0].getY()), "");
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.TitleCode.GDCursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cursor_Border_Bottom"), gdjs.TitleCode.GDCursor_9595Border_9595BottomObjects2);
gdjs.copyArray(runtimeScene.getObjects("Cursor_Border_Top"), gdjs.TitleCode.GDCursor_9595Border_9595TopObjects2);
{for(var i = 0, len = gdjs.TitleCode.GDCursorObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDCursorObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.TitleCode.GDCursor_9595Border_9595TopObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDCursor_9595Border_9595TopObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.TitleCode.GDCursor_9595Border_9595BottomObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDCursor_9595Border_9595BottomObjects2[i].hide();
}
}}

}


{


gdjs.TitleCode.eventsList0(runtimeScene);
}


};gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects2Objects = Hashtable.newFrom({"Cursor": gdjs.TitleCode.GDCursorObjects2});
gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDSTARTObjects2Objects = Hashtable.newFrom({"START": gdjs.TitleCode.GDSTARTObjects2});
gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects2Objects = Hashtable.newFrom({"Cursor": gdjs.TitleCode.GDCursorObjects2});
gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDSTARTObjects2Objects = Hashtable.newFrom({"START": gdjs.TitleCode.GDSTARTObjects2});
gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.TitleCode.GDCursorObjects1});
gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDSTARTObjects1Objects = Hashtable.newFrom({"START": gdjs.TitleCode.GDSTARTObjects1});
gdjs.TitleCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.TitleCode.GDCursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("START"), gdjs.TitleCode.GDSTARTObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects2Objects, gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDSTARTObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.TitleCode.GDCursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("START"), gdjs.TitleCode.GDSTARTObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects2Objects, gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDSTARTObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TitleCode.GDSTARTObjects2 */
{for(var i = 0, len = gdjs.TitleCode.GDSTARTObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDSTARTObjects2[i].setColor("233;52;223");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.TitleCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("START"), gdjs.TitleCode.GDSTARTObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects1Objects, gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDSTARTObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TitleCode.GDSTARTObjects1 */
{for(var i = 0, len = gdjs.TitleCode.GDSTARTObjects1.length ;i < len;++i) {
    gdjs.TitleCode.GDSTARTObjects1[i].setColor("255;255;255");
}
}}

}


};gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects2Objects = Hashtable.newFrom({"Cursor": gdjs.TitleCode.GDCursorObjects2});
gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDDATAObjects2Objects = Hashtable.newFrom({"DATA": gdjs.TitleCode.GDDATAObjects2});
gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDTransitionObjects2Objects = Hashtable.newFrom({"Transition": gdjs.TitleCode.GDTransitionObjects2});
gdjs.TitleCode.asyncCallback14836524 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Data", false);
}}
gdjs.TitleCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.TitleCode.asyncCallback14836524(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TitleCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.TitleCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.TitleCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.TitleCode.GDTransitionObjects2 */
{for(var i = 0, len = gdjs.TitleCode.GDTransitionObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDTransitionObjects2[i].getBehavior("Tween").addObjectOpacityTween2("Transition", 255, "linear", 0.5, false);
}
}
{ //Subevents
gdjs.TitleCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects2Objects = Hashtable.newFrom({"Cursor": gdjs.TitleCode.GDCursorObjects2});
gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDDATAObjects2Objects = Hashtable.newFrom({"DATA": gdjs.TitleCode.GDDATAObjects2});
gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.TitleCode.GDCursorObjects1});
gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDDATAObjects1Objects = Hashtable.newFrom({"DATA": gdjs.TitleCode.GDDATAObjects1});
gdjs.TitleCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.TitleCode.GDCursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("DATA"), gdjs.TitleCode.GDDATAObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects2Objects, gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDDATAObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}
if (isConditionTrue_0) {
gdjs.TitleCode.GDTransitionObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDTransitionObjects2Objects, 0, 0, "");
}{for(var i = 0, len = gdjs.TitleCode.GDTransitionObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDTransitionObjects2[i].setLayer("Transition");
}
}{for(var i = 0, len = gdjs.TitleCode.GDTransitionObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDTransitionObjects2[i].getBehavior("Resizable").setSize(1920, 1080);
}
}{for(var i = 0, len = gdjs.TitleCode.GDTransitionObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDTransitionObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}
{ //Subevents
gdjs.TitleCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.TitleCode.GDCursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("DATA"), gdjs.TitleCode.GDDATAObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects2Objects, gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDDATAObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TitleCode.GDDATAObjects2 */
{for(var i = 0, len = gdjs.TitleCode.GDDATAObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDDATAObjects2[i].setColor("233;52;223");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.TitleCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("DATA"), gdjs.TitleCode.GDDATAObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects1Objects, gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDDATAObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TitleCode.GDDATAObjects1 */
{for(var i = 0, len = gdjs.TitleCode.GDDATAObjects1.length ;i < len;++i) {
    gdjs.TitleCode.GDDATAObjects1[i].setColor("255;255;255");
}
}}

}


};gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects2Objects = Hashtable.newFrom({"Cursor": gdjs.TitleCode.GDCursorObjects2});
gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDGALLERYObjects2Objects = Hashtable.newFrom({"GALLERY": gdjs.TitleCode.GDGALLERYObjects2});
gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDTransitionObjects2Objects = Hashtable.newFrom({"Transition": gdjs.TitleCode.GDTransitionObjects2});
gdjs.TitleCode.asyncCallback14840732 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Gallery", false);
}}
gdjs.TitleCode.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.TitleCode.asyncCallback14840732(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TitleCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.TitleCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.TitleCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.TitleCode.GDTransitionObjects2 */
{for(var i = 0, len = gdjs.TitleCode.GDTransitionObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDTransitionObjects2[i].getBehavior("Tween").addObjectOpacityTween2("Transition", 255, "linear", 0.5, false);
}
}
{ //Subevents
gdjs.TitleCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects2Objects = Hashtable.newFrom({"Cursor": gdjs.TitleCode.GDCursorObjects2});
gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDGALLERYObjects2Objects = Hashtable.newFrom({"GALLERY": gdjs.TitleCode.GDGALLERYObjects2});
gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects1Objects = Hashtable.newFrom({"Cursor": gdjs.TitleCode.GDCursorObjects1});
gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDGALLERYObjects1Objects = Hashtable.newFrom({"GALLERY": gdjs.TitleCode.GDGALLERYObjects1});
gdjs.TitleCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.TitleCode.GDCursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("GALLERY"), gdjs.TitleCode.GDGALLERYObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects2Objects, gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDGALLERYObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}
if (isConditionTrue_0) {
gdjs.TitleCode.GDTransitionObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDTransitionObjects2Objects, 0, 0, "");
}{for(var i = 0, len = gdjs.TitleCode.GDTransitionObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDTransitionObjects2[i].setLayer("Transition");
}
}{for(var i = 0, len = gdjs.TitleCode.GDTransitionObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDTransitionObjects2[i].getBehavior("Resizable").setSize(1920, 1080);
}
}{for(var i = 0, len = gdjs.TitleCode.GDTransitionObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDTransitionObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}
{ //Subevents
gdjs.TitleCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.TitleCode.GDCursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("GALLERY"), gdjs.TitleCode.GDGALLERYObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects2Objects, gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDGALLERYObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TitleCode.GDGALLERYObjects2 */
{for(var i = 0, len = gdjs.TitleCode.GDGALLERYObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDGALLERYObjects2[i].setColor("255;255;255");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Cursor"), gdjs.TitleCode.GDCursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("GALLERY"), gdjs.TitleCode.GDGALLERYObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDCursorObjects1Objects, gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDGALLERYObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TitleCode.GDGALLERYObjects1 */
{for(var i = 0, len = gdjs.TitleCode.GDGALLERYObjects1.length ;i < len;++i) {
    gdjs.TitleCode.GDGALLERYObjects1[i].setColor("233;52;223");
}
}}

}


};gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDTransitionObjects1Objects = Hashtable.newFrom({"Transition": gdjs.TitleCode.GDTransitionObjects1});
gdjs.TitleCode.asyncCallback14844956 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(6), false);
}}
gdjs.TitleCode.eventsList11 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.TitleCode.asyncCallback14844956(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TitleCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.TitleCode.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.TitleCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.TitleCode.GDTransitionObjects1 */
{for(var i = 0, len = gdjs.TitleCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.TitleCode.GDTransitionObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Transition", 0, "linear", 0.3, false);
}
}
{ //Subevents
gdjs.TitleCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.TitleCode.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(6), true);
}
if (isConditionTrue_0) {
gdjs.TitleCode.GDTransitionObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TitleCode.mapOfGDgdjs_9546TitleCode_9546GDTransitionObjects1Objects, 0, 0, "");
}{for(var i = 0, len = gdjs.TitleCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.TitleCode.GDTransitionObjects1[i].setLayer("Transition");
}
}{for(var i = 0, len = gdjs.TitleCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.TitleCode.GDTransitionObjects1[i].getBehavior("Resizable").setSize(1920, 1080);
}
}{for(var i = 0, len = gdjs.TitleCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.TitleCode.GDTransitionObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}
{ //Subevents
gdjs.TitleCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.TitleCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burrow"), gdjs.TitleCode.GDBurrowObjects3);
{for(var i = 0, len = gdjs.TitleCode.GDBurrowObjects3.length ;i < len;++i) {
    gdjs.TitleCode.GDBurrowObjects3[i].getBehavior("Animation").setAnimationName("Night");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burrow"), gdjs.TitleCode.GDBurrowObjects3);
{for(var i = 0, len = gdjs.TitleCode.GDBurrowObjects3.length ;i < len;++i) {
    gdjs.TitleCode.GDBurrowObjects3[i].getBehavior("Animation").setAnimationName("Day");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__October.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burrow"), gdjs.TitleCode.GDBurrowObjects3);
{for(var i = 0, len = gdjs.TitleCode.GDBurrowObjects3.length ;i < len;++i) {
    gdjs.TitleCode.GDBurrowObjects3[i].getBehavior("Animation").setAnimationName("Halloween");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__December.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burrow"), gdjs.TitleCode.GDBurrowObjects2);
{for(var i = 0, len = gdjs.TitleCode.GDBurrowObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDBurrowObjects2[i].getBehavior("Animation").setAnimationName("Christmas");
}
}}

}


};gdjs.TitleCode.eventsList16 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Dawn.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.TitleCode.GDSkyObjects2);
{for(var i = 0, len = gdjs.TitleCode.GDSkyObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDSkyObjects2[i].getBehavior("Animation").setAnimationName("Dawn");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Morning.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.TitleCode.GDSkyObjects2);
{for(var i = 0, len = gdjs.TitleCode.GDSkyObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDSkyObjects2[i].getBehavior("Animation").setAnimationName("Day");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Dusk.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.TitleCode.GDSkyObjects2);
{for(var i = 0, len = gdjs.TitleCode.GDSkyObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDSkyObjects2[i].getBehavior("Animation").setAnimationName("Dusk");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.TitleCode.GDSkyObjects2);
{for(var i = 0, len = gdjs.TitleCode.GDSkyObjects2.length ;i < len;++i) {
    gdjs.TitleCode.GDSkyObjects2[i].getBehavior("Animation").setAnimationName("Night");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__October.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.TitleCode.GDSkyObjects1);
{for(var i = 0, len = gdjs.TitleCode.GDSkyObjects1.length ;i < len;++i) {
    gdjs.TitleCode.GDSkyObjects1[i].getBehavior("Animation").setAnimationName("Halloween");
}
}}

}


};gdjs.TitleCode.eventsList17 = function(runtimeScene) {

{


gdjs.TitleCode.eventsList15(runtimeScene);
}


{


gdjs.TitleCode.eventsList16(runtimeScene);
}


};gdjs.TitleCode.eventsList18 = function(runtimeScene) {

{


gdjs.TitleCode.eventsList1(runtimeScene);
}


{


gdjs.TitleCode.eventsList2(runtimeScene);
}


{


gdjs.TitleCode.eventsList6(runtimeScene);
}


{


gdjs.TitleCode.eventsList10(runtimeScene);
}


{


gdjs.TitleCode.eventsList14(runtimeScene);
}


{


gdjs.TitleCode.eventsList17(runtimeScene);
}


};

gdjs.TitleCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.TitleCode.GDVerObjects1.length = 0;
gdjs.TitleCode.GDVerObjects2.length = 0;
gdjs.TitleCode.GDVerObjects3.length = 0;
gdjs.TitleCode.GDVerObjects4.length = 0;
gdjs.TitleCode.GDSTARTObjects1.length = 0;
gdjs.TitleCode.GDSTARTObjects2.length = 0;
gdjs.TitleCode.GDSTARTObjects3.length = 0;
gdjs.TitleCode.GDSTARTObjects4.length = 0;
gdjs.TitleCode.GDDATAObjects1.length = 0;
gdjs.TitleCode.GDDATAObjects2.length = 0;
gdjs.TitleCode.GDDATAObjects3.length = 0;
gdjs.TitleCode.GDDATAObjects4.length = 0;
gdjs.TitleCode.GDGALLERYObjects1.length = 0;
gdjs.TitleCode.GDGALLERYObjects2.length = 0;
gdjs.TitleCode.GDGALLERYObjects3.length = 0;
gdjs.TitleCode.GDGALLERYObjects4.length = 0;
gdjs.TitleCode.GDCursorObjects1.length = 0;
gdjs.TitleCode.GDCursorObjects2.length = 0;
gdjs.TitleCode.GDCursorObjects3.length = 0;
gdjs.TitleCode.GDCursorObjects4.length = 0;
gdjs.TitleCode.GDCursor_9595Border_9595TopObjects1.length = 0;
gdjs.TitleCode.GDCursor_9595Border_9595TopObjects2.length = 0;
gdjs.TitleCode.GDCursor_9595Border_9595TopObjects3.length = 0;
gdjs.TitleCode.GDCursor_9595Border_9595TopObjects4.length = 0;
gdjs.TitleCode.GDCursor_9595Border_9595BottomObjects1.length = 0;
gdjs.TitleCode.GDCursor_9595Border_9595BottomObjects2.length = 0;
gdjs.TitleCode.GDCursor_9595Border_9595BottomObjects3.length = 0;
gdjs.TitleCode.GDCursor_9595Border_9595BottomObjects4.length = 0;
gdjs.TitleCode.GDCopyrightObjects1.length = 0;
gdjs.TitleCode.GDCopyrightObjects2.length = 0;
gdjs.TitleCode.GDCopyrightObjects3.length = 0;
gdjs.TitleCode.GDCopyrightObjects4.length = 0;
gdjs.TitleCode.GDBurrowObjects1.length = 0;
gdjs.TitleCode.GDBurrowObjects2.length = 0;
gdjs.TitleCode.GDBurrowObjects3.length = 0;
gdjs.TitleCode.GDBurrowObjects4.length = 0;
gdjs.TitleCode.GDHigh_9595Score_9595GameplayObjects1.length = 0;
gdjs.TitleCode.GDHigh_9595Score_9595GameplayObjects2.length = 0;
gdjs.TitleCode.GDHigh_9595Score_9595GameplayObjects3.length = 0;
gdjs.TitleCode.GDHigh_9595Score_9595GameplayObjects4.length = 0;
gdjs.TitleCode.GDSkyObjects1.length = 0;
gdjs.TitleCode.GDSkyObjects2.length = 0;
gdjs.TitleCode.GDSkyObjects3.length = 0;
gdjs.TitleCode.GDSkyObjects4.length = 0;
gdjs.TitleCode.GDJerry_9595LogoObjects1.length = 0;
gdjs.TitleCode.GDJerry_9595LogoObjects2.length = 0;
gdjs.TitleCode.GDJerry_9595LogoObjects3.length = 0;
gdjs.TitleCode.GDJerry_9595LogoObjects4.length = 0;
gdjs.TitleCode.GDBrains_9595EatenObjects1.length = 0;
gdjs.TitleCode.GDBrains_9595EatenObjects2.length = 0;
gdjs.TitleCode.GDBrains_9595EatenObjects3.length = 0;
gdjs.TitleCode.GDBrains_9595EatenObjects4.length = 0;
gdjs.TitleCode.GDTransitionObjects1.length = 0;
gdjs.TitleCode.GDTransitionObjects2.length = 0;
gdjs.TitleCode.GDTransitionObjects3.length = 0;
gdjs.TitleCode.GDTransitionObjects4.length = 0;
gdjs.TitleCode.GDHigh_9595ScoreObjects1.length = 0;
gdjs.TitleCode.GDHigh_9595ScoreObjects2.length = 0;
gdjs.TitleCode.GDHigh_9595ScoreObjects3.length = 0;
gdjs.TitleCode.GDHigh_9595ScoreObjects4.length = 0;
gdjs.TitleCode.GDRocks_9595DestroyedObjects1.length = 0;
gdjs.TitleCode.GDRocks_9595DestroyedObjects2.length = 0;
gdjs.TitleCode.GDRocks_9595DestroyedObjects3.length = 0;
gdjs.TitleCode.GDRocks_9595DestroyedObjects4.length = 0;
gdjs.TitleCode.GDGames_9595PlayedObjects1.length = 0;
gdjs.TitleCode.GDGames_9595PlayedObjects2.length = 0;
gdjs.TitleCode.GDGames_9595PlayedObjects3.length = 0;
gdjs.TitleCode.GDGames_9595PlayedObjects4.length = 0;

gdjs.TitleCode.eventsList18(runtimeScene);

return;

}

gdjs['TitleCode'] = gdjs.TitleCode;
