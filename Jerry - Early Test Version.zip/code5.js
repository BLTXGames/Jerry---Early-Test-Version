gdjs.Debug_32RoomCode = {};
gdjs.Debug_32RoomCode.GDJerry_9595TestObjects1= [];
gdjs.Debug_32RoomCode.GDJerry_9595TestObjects2= [];
gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1= [];
gdjs.Debug_32RoomCode.GDBrain_9595TestObjects2= [];
gdjs.Debug_32RoomCode.GDBorderObjects1= [];
gdjs.Debug_32RoomCode.GDBorderObjects2= [];
gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects1= [];
gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects2= [];
gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects1= [];
gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects2= [];
gdjs.Debug_32RoomCode.GDDebugObjects1= [];
gdjs.Debug_32RoomCode.GDDebugObjects2= [];
gdjs.Debug_32RoomCode.GDBurrowObjects1= [];
gdjs.Debug_32RoomCode.GDBurrowObjects2= [];
gdjs.Debug_32RoomCode.GDHigh_9595Score_9595GameplayObjects1= [];
gdjs.Debug_32RoomCode.GDHigh_9595Score_9595GameplayObjects2= [];
gdjs.Debug_32RoomCode.GDSkyObjects1= [];
gdjs.Debug_32RoomCode.GDSkyObjects2= [];
gdjs.Debug_32RoomCode.GDJerry_9595LogoObjects1= [];
gdjs.Debug_32RoomCode.GDJerry_9595LogoObjects2= [];
gdjs.Debug_32RoomCode.GDBrains_9595EatenObjects1= [];
gdjs.Debug_32RoomCode.GDBrains_9595EatenObjects2= [];
gdjs.Debug_32RoomCode.GDTransitionObjects1= [];
gdjs.Debug_32RoomCode.GDTransitionObjects2= [];
gdjs.Debug_32RoomCode.GDHigh_9595ScoreObjects1= [];
gdjs.Debug_32RoomCode.GDHigh_9595ScoreObjects2= [];
gdjs.Debug_32RoomCode.GDRocks_9595DestroyedObjects1= [];
gdjs.Debug_32RoomCode.GDRocks_9595DestroyedObjects2= [];
gdjs.Debug_32RoomCode.GDGames_9595PlayedObjects1= [];
gdjs.Debug_32RoomCode.GDGames_9595PlayedObjects2= [];


gdjs.Debug_32RoomCode.asyncCallback15289844 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Debug Room", false);
}}
gdjs.Debug_32RoomCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Debug_32RoomCode.asyncCallback15289844(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Debug_32RoomCode.eventsList1 = function(runtimeScene) {

};gdjs.Debug_32RoomCode.mapOfEmptyGDBrain_9595TestObjects = Hashtable.newFrom({"Brain_Test": []});
gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrainSpawnLEFTObjects1ObjectsGDgdjs_9546Debug_959532RoomCode_9546GDBrainSpawnRIGHTObjects1Objects = Hashtable.newFrom({"BrainSpawnLEFT": gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects1, "BrainSpawnRIGHT": gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects1});
gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrain_95959595TestObjects1Objects = Hashtable.newFrom({"Brain_Test": gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1});
gdjs.Debug_32RoomCode.eventsList2 = function(runtimeScene) {

};gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrain_95959595TestObjects1Objects = Hashtable.newFrom({"Brain_Test": gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1});
gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrainSpawnLEFTObjects1Objects = Hashtable.newFrom({"BrainSpawnLEFT": gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects1});
gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrain_95959595TestObjects1Objects = Hashtable.newFrom({"Brain_Test": gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1});
gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrainSpawnRIGHTObjects1Objects = Hashtable.newFrom({"BrainSpawnRIGHT": gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects1});
gdjs.Debug_32RoomCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BrainSpawnRIGHT"), gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects1);
/* Reuse gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length;i<l;++i) {
    if ( !(gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[k] = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i];
        ++k;
    }
}
gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrain_95959595TestObjects1Objects, gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrainSpawnRIGHTObjects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1 */
{for(var i = 0, len = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length ;i < len;++i) {
    gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i].setX(gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i].getX() + (192));
}
}}

}


};gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrain_95959595TestObjects1Objects = Hashtable.newFrom({"Brain_Test": gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1});
gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrainSpawnRIGHTObjects1Objects = Hashtable.newFrom({"BrainSpawnRIGHT": gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects1});
gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrain_95959595TestObjects1Objects = Hashtable.newFrom({"Brain_Test": gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1});
gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrainSpawnLEFTObjects1Objects = Hashtable.newFrom({"BrainSpawnLEFT": gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects1});
gdjs.Debug_32RoomCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BrainSpawnLEFT"), gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects1);
/* Reuse gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length;i<l;++i) {
    if ( gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[k] = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i];
        ++k;
    }
}
gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrain_95959595TestObjects1Objects, gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrainSpawnLEFTObjects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1 */
{for(var i = 0, len = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length ;i < len;++i) {
    gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i].setX(gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i].getX() - (192));
}
}}

}


};gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrain_95959595TestObjects1Objects = Hashtable.newFrom({"Brain_Test": gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1});
gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBorderObjects1Objects = Hashtable.newFrom({"Border": gdjs.Debug_32RoomCode.GDBorderObjects1});
gdjs.Debug_32RoomCode.eventsList5 = function(runtimeScene) {

};gdjs.Debug_32RoomCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 0.7, "Brains", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 0.7, "", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 0.7, "Layer", 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15289748);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Debug_32RoomCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.Debug_32RoomCode.eventsList1(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainSpawn");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BrainSpawnLEFT"), gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects1);
gdjs.copyArray(runtimeScene.getObjects("BrainSpawnRIGHT"), gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "BrainSpawn") > 5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Debug_32RoomCode.mapOfEmptyGDBrain_9595TestObjects) <= 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrainSpawnLEFTObjects1ObjectsGDgdjs_9546Debug_959532RoomCode_9546GDBrainSpawnRIGHTObjects1Objects);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects1 */
/* Reuse gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects1 */
gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrain_95959595TestObjects1Objects, (( gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects1.length === 0 ) ? (( gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects1.length === 0 ) ? 0 :gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects1[0].getPointX("")) :gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects1[0].getPointX("")), (( gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects1.length === 0 ) ? (( gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects1.length === 0 ) ? 0 :gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects1[0].getPointY("")) :gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects1[0].getPointY("")), "Brains");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainSpawn");
}{for(var i = 0, len = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length ;i < len;++i) {
    gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i].getBehavior("Resizable").setSize(160, 160);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(gdjs.random(100));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "BrainSpawnerRandomness", 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(gdjs.random(100));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) <= 50;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15296100);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BrainSpawnLEFT"), gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects1);
gdjs.copyArray(runtimeScene.getObjects("BrainSpawnRIGHT"), gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects1);
{for(var i = 0, len = gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects1.length ;i < len;++i) {
    gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects1[i].setY(32);
}
}{for(var i = 0, len = gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects1.length ;i < len;++i) {
    gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects1[i].setY(192);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) > 50;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15297100);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BrainSpawnLEFT"), gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects1);
gdjs.copyArray(runtimeScene.getObjects("BrainSpawnRIGHT"), gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects1);
{for(var i = 0, len = gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects1.length ;i < len;++i) {
    gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects1[i].setY(192);
}
}{for(var i = 0, len = gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects1.length ;i < len;++i) {
    gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects1[i].setY(32);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Debug"), gdjs.Debug_32RoomCode.GDDebugObjects1);
{for(var i = 0, len = gdjs.Debug_32RoomCode.GDDebugObjects1.length ;i < len;++i) {
    gdjs.Debug_32RoomCode.GDDebugObjects1[i].getBehavior("Text").setText("Randomness: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(1)));
}
}}

}


{


gdjs.Debug_32RoomCode.eventsList2(runtimeScene);
}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BrainSpawnLEFT"), gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects1);
gdjs.copyArray(runtimeScene.getObjects("Brain_Test"), gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrain_95959595TestObjects1Objects, gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrainSpawnLEFTObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1 */
{for(var i = 0, len = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length ;i < len;++i) {
    gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Brain_Test"), gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length;i<l;++i) {
    if ( !(gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i].getBehavior("Flippable").isFlippedX()) ) {
        isConditionTrue_0 = true;
        gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[k] = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i];
        ++k;
    }
}
gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length;i<l;++i) {
    if ( gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i].getBehavior("RepeatTimer").Repeat2("BrainScroll", 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[k] = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i];
        ++k;
    }
}
gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1 */
{for(var i = 0, len = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length ;i < len;++i) {
    gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i].setX(gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i].getX() + (192));
}
}
{ //Subevents
gdjs.Debug_32RoomCode.eventsList3(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("BrainSpawnRIGHT"), gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects1);
gdjs.copyArray(runtimeScene.getObjects("Brain_Test"), gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrain_95959595TestObjects1Objects, gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrainSpawnRIGHTObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1 */
{for(var i = 0, len = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length ;i < len;++i) {
    gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i].getBehavior("Flippable").flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Brain_Test"), gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length;i<l;++i) {
    if ( gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i].getBehavior("Flippable").isFlippedX() ) {
        isConditionTrue_0 = true;
        gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[k] = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i];
        ++k;
    }
}
gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length;i<l;++i) {
    if ( gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i].getBehavior("RepeatTimer").Repeat2("BrainScroll", 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[k] = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i];
        ++k;
    }
}
gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1 */
{for(var i = 0, len = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length ;i < len;++i) {
    gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i].setX(gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i].getX() - (192));
}
}
{ //Subevents
gdjs.Debug_32RoomCode.eventsList4(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Border"), gdjs.Debug_32RoomCode.GDBorderObjects1);
gdjs.copyArray(runtimeScene.getObjects("Brain_Test"), gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBrain_95959595TestObjects1Objects, gdjs.Debug_32RoomCode.mapOfGDgdjs_9546Debug_959532RoomCode_9546GDBorderObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1 */
{for(var i = 0, len = gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length ;i < len;++i) {
    gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


gdjs.Debug_32RoomCode.eventsList5(runtimeScene);
}


{



}


{



}


{



}


};

gdjs.Debug_32RoomCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Debug_32RoomCode.GDJerry_9595TestObjects1.length = 0;
gdjs.Debug_32RoomCode.GDJerry_9595TestObjects2.length = 0;
gdjs.Debug_32RoomCode.GDBrain_9595TestObjects1.length = 0;
gdjs.Debug_32RoomCode.GDBrain_9595TestObjects2.length = 0;
gdjs.Debug_32RoomCode.GDBorderObjects1.length = 0;
gdjs.Debug_32RoomCode.GDBorderObjects2.length = 0;
gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects1.length = 0;
gdjs.Debug_32RoomCode.GDBrainSpawnLEFTObjects2.length = 0;
gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects1.length = 0;
gdjs.Debug_32RoomCode.GDBrainSpawnRIGHTObjects2.length = 0;
gdjs.Debug_32RoomCode.GDDebugObjects1.length = 0;
gdjs.Debug_32RoomCode.GDDebugObjects2.length = 0;
gdjs.Debug_32RoomCode.GDBurrowObjects1.length = 0;
gdjs.Debug_32RoomCode.GDBurrowObjects2.length = 0;
gdjs.Debug_32RoomCode.GDHigh_9595Score_9595GameplayObjects1.length = 0;
gdjs.Debug_32RoomCode.GDHigh_9595Score_9595GameplayObjects2.length = 0;
gdjs.Debug_32RoomCode.GDSkyObjects1.length = 0;
gdjs.Debug_32RoomCode.GDSkyObjects2.length = 0;
gdjs.Debug_32RoomCode.GDJerry_9595LogoObjects1.length = 0;
gdjs.Debug_32RoomCode.GDJerry_9595LogoObjects2.length = 0;
gdjs.Debug_32RoomCode.GDBrains_9595EatenObjects1.length = 0;
gdjs.Debug_32RoomCode.GDBrains_9595EatenObjects2.length = 0;
gdjs.Debug_32RoomCode.GDTransitionObjects1.length = 0;
gdjs.Debug_32RoomCode.GDTransitionObjects2.length = 0;
gdjs.Debug_32RoomCode.GDHigh_9595ScoreObjects1.length = 0;
gdjs.Debug_32RoomCode.GDHigh_9595ScoreObjects2.length = 0;
gdjs.Debug_32RoomCode.GDRocks_9595DestroyedObjects1.length = 0;
gdjs.Debug_32RoomCode.GDRocks_9595DestroyedObjects2.length = 0;
gdjs.Debug_32RoomCode.GDGames_9595PlayedObjects1.length = 0;
gdjs.Debug_32RoomCode.GDGames_9595PlayedObjects2.length = 0;

gdjs.Debug_32RoomCode.eventsList6(runtimeScene);

return;

}

gdjs['Debug_32RoomCode'] = gdjs.Debug_32RoomCode;
