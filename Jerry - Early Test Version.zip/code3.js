gdjs.GalleryCode = {};
gdjs.GalleryCode.GDData_9595BGObjects1= [];
gdjs.GalleryCode.GDData_9595BGObjects2= [];
gdjs.GalleryCode.GDData_9595BGObjects3= [];
gdjs.GalleryCode.GDData_9595BGObjects4= [];
gdjs.GalleryCode.GDData_9595BGObjects5= [];
gdjs.GalleryCode.GDData_9595BGObjects6= [];
gdjs.GalleryCode.GDData_9595BGObjects7= [];
gdjs.GalleryCode.GDData_9595BGObjects8= [];
gdjs.GalleryCode.GDData_9595BGObjects9= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects1= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects4= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects5= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects6= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects7= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects8= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects9= [];
gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1= [];
gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2= [];
gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3= [];
gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects4= [];
gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects5= [];
gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects6= [];
gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects7= [];
gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects8= [];
gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects9= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects1= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects2= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects4= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects5= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects6= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects7= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects8= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects9= [];
gdjs.GalleryCode.GDBorder_9595LObjects1= [];
gdjs.GalleryCode.GDBorder_9595LObjects2= [];
gdjs.GalleryCode.GDBorder_9595LObjects3= [];
gdjs.GalleryCode.GDBorder_9595LObjects4= [];
gdjs.GalleryCode.GDBorder_9595LObjects5= [];
gdjs.GalleryCode.GDBorder_9595LObjects6= [];
gdjs.GalleryCode.GDBorder_9595LObjects7= [];
gdjs.GalleryCode.GDBorder_9595LObjects8= [];
gdjs.GalleryCode.GDBorder_9595LObjects9= [];
gdjs.GalleryCode.GDBorder_9595RObjects1= [];
gdjs.GalleryCode.GDBorder_9595RObjects2= [];
gdjs.GalleryCode.GDBorder_9595RObjects3= [];
gdjs.GalleryCode.GDBorder_9595RObjects4= [];
gdjs.GalleryCode.GDBorder_9595RObjects5= [];
gdjs.GalleryCode.GDBorder_9595RObjects6= [];
gdjs.GalleryCode.GDBorder_9595RObjects7= [];
gdjs.GalleryCode.GDBorder_9595RObjects8= [];
gdjs.GalleryCode.GDBorder_9595RObjects9= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects1= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects2= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects4= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects5= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects6= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects7= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects8= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects9= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects1= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects2= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects4= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects5= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects6= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects7= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects8= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects9= [];
gdjs.GalleryCode.GDBorder_9595BottomObjects1= [];
gdjs.GalleryCode.GDBorder_9595BottomObjects2= [];
gdjs.GalleryCode.GDBorder_9595BottomObjects3= [];
gdjs.GalleryCode.GDBorder_9595BottomObjects4= [];
gdjs.GalleryCode.GDBorder_9595BottomObjects5= [];
gdjs.GalleryCode.GDBorder_9595BottomObjects6= [];
gdjs.GalleryCode.GDBorder_9595BottomObjects7= [];
gdjs.GalleryCode.GDBorder_9595BottomObjects8= [];
gdjs.GalleryCode.GDBorder_9595BottomObjects9= [];
gdjs.GalleryCode.GDBorder_9595TopObjects1= [];
gdjs.GalleryCode.GDBorder_9595TopObjects2= [];
gdjs.GalleryCode.GDBorder_9595TopObjects3= [];
gdjs.GalleryCode.GDBorder_9595TopObjects4= [];
gdjs.GalleryCode.GDBorder_9595TopObjects5= [];
gdjs.GalleryCode.GDBorder_9595TopObjects6= [];
gdjs.GalleryCode.GDBorder_9595TopObjects7= [];
gdjs.GalleryCode.GDBorder_9595TopObjects8= [];
gdjs.GalleryCode.GDBorder_9595TopObjects9= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects1= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects2= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects4= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects5= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects6= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects7= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects8= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects9= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects1= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects2= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects4= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects5= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects6= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects7= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects8= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects9= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects1= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects2= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects4= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects5= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects6= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects7= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects8= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects9= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects1= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects2= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects4= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects5= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects6= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects7= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects8= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects9= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects1= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects2= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects3= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects4= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects5= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects6= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects7= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects8= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects9= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects1= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects2= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects3= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects4= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects5= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects6= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects7= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects8= [];
gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects9= [];
gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects1= [];
gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2= [];
gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects3= [];
gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4= [];
gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects5= [];
gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects6= [];
gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects7= [];
gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects8= [];
gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects9= [];
gdjs.GalleryCode.GDSelected_9595ItemObjects1= [];
gdjs.GalleryCode.GDSelected_9595ItemObjects2= [];
gdjs.GalleryCode.GDSelected_9595ItemObjects3= [];
gdjs.GalleryCode.GDSelected_9595ItemObjects4= [];
gdjs.GalleryCode.GDSelected_9595ItemObjects5= [];
gdjs.GalleryCode.GDSelected_9595ItemObjects6= [];
gdjs.GalleryCode.GDSelected_9595ItemObjects7= [];
gdjs.GalleryCode.GDSelected_9595ItemObjects8= [];
gdjs.GalleryCode.GDSelected_9595ItemObjects9= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects1= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects2= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects3= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects4= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects5= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects6= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects7= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects8= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects9= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects1= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects2= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects3= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects4= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects5= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects6= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects7= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects8= [];
gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects9= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects1= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects2= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects3= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects4= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects5= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects6= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects7= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects8= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects9= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects1= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects2= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects3= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects4= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects5= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects6= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects7= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects8= [];
gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects9= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects1= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects2= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects3= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects4= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects5= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects6= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects7= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects8= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects9= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects1= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects2= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects3= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects4= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects5= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects6= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects7= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects8= [];
gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects9= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects1= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects2= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects3= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects4= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects5= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects6= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects7= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects8= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects9= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects1= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects2= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects3= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects4= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects5= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects6= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects7= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects8= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects9= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects1= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects2= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects3= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects4= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects5= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects6= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects7= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects8= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects9= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects1= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects2= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects3= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects4= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects5= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects6= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects7= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects8= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects9= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects1= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects2= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects3= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects4= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects5= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects6= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects7= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects8= [];
gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects9= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects1= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects2= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects3= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects4= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects5= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects6= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects7= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects8= [];
gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects9= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects1= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects2= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects3= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects4= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects5= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects6= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects7= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects8= [];
gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects9= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects1= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects2= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects3= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects4= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects5= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects6= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects7= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects8= [];
gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects9= [];
gdjs.GalleryCode.GDGallery_9595BGObjects1= [];
gdjs.GalleryCode.GDGallery_9595BGObjects2= [];
gdjs.GalleryCode.GDGallery_9595BGObjects3= [];
gdjs.GalleryCode.GDGallery_9595BGObjects4= [];
gdjs.GalleryCode.GDGallery_9595BGObjects5= [];
gdjs.GalleryCode.GDGallery_9595BGObjects6= [];
gdjs.GalleryCode.GDGallery_9595BGObjects7= [];
gdjs.GalleryCode.GDGallery_9595BGObjects8= [];
gdjs.GalleryCode.GDGallery_9595BGObjects9= [];
gdjs.GalleryCode.GDCharacter_9595NameObjects1= [];
gdjs.GalleryCode.GDCharacter_9595NameObjects2= [];
gdjs.GalleryCode.GDCharacter_9595NameObjects3= [];
gdjs.GalleryCode.GDCharacter_9595NameObjects4= [];
gdjs.GalleryCode.GDCharacter_9595NameObjects5= [];
gdjs.GalleryCode.GDCharacter_9595NameObjects6= [];
gdjs.GalleryCode.GDCharacter_9595NameObjects7= [];
gdjs.GalleryCode.GDCharacter_9595NameObjects8= [];
gdjs.GalleryCode.GDCharacter_9595NameObjects9= [];
gdjs.GalleryCode.GDOriginObjects1= [];
gdjs.GalleryCode.GDOriginObjects2= [];
gdjs.GalleryCode.GDOriginObjects3= [];
gdjs.GalleryCode.GDOriginObjects4= [];
gdjs.GalleryCode.GDOriginObjects5= [];
gdjs.GalleryCode.GDOriginObjects6= [];
gdjs.GalleryCode.GDOriginObjects7= [];
gdjs.GalleryCode.GDOriginObjects8= [];
gdjs.GalleryCode.GDOriginObjects9= [];
gdjs.GalleryCode.GDSelectedObjects1= [];
gdjs.GalleryCode.GDSelectedObjects2= [];
gdjs.GalleryCode.GDSelectedObjects3= [];
gdjs.GalleryCode.GDSelectedObjects4= [];
gdjs.GalleryCode.GDSelectedObjects5= [];
gdjs.GalleryCode.GDSelectedObjects6= [];
gdjs.GalleryCode.GDSelectedObjects7= [];
gdjs.GalleryCode.GDSelectedObjects8= [];
gdjs.GalleryCode.GDSelectedObjects9= [];
gdjs.GalleryCode.GDNot_9595SelectedObjects1= [];
gdjs.GalleryCode.GDNot_9595SelectedObjects2= [];
gdjs.GalleryCode.GDNot_9595SelectedObjects3= [];
gdjs.GalleryCode.GDNot_9595SelectedObjects4= [];
gdjs.GalleryCode.GDNot_9595SelectedObjects5= [];
gdjs.GalleryCode.GDNot_9595SelectedObjects6= [];
gdjs.GalleryCode.GDNot_9595SelectedObjects7= [];
gdjs.GalleryCode.GDNot_9595SelectedObjects8= [];
gdjs.GalleryCode.GDNot_9595SelectedObjects9= [];
gdjs.GalleryCode.GDSelect_9595CursorObjects1= [];
gdjs.GalleryCode.GDSelect_9595CursorObjects2= [];
gdjs.GalleryCode.GDSelect_9595CursorObjects3= [];
gdjs.GalleryCode.GDSelect_9595CursorObjects4= [];
gdjs.GalleryCode.GDSelect_9595CursorObjects5= [];
gdjs.GalleryCode.GDSelect_9595CursorObjects6= [];
gdjs.GalleryCode.GDSelect_9595CursorObjects7= [];
gdjs.GalleryCode.GDSelect_9595CursorObjects8= [];
gdjs.GalleryCode.GDSelect_9595CursorObjects9= [];
gdjs.GalleryCode.GDBurrowObjects1= [];
gdjs.GalleryCode.GDBurrowObjects2= [];
gdjs.GalleryCode.GDBurrowObjects3= [];
gdjs.GalleryCode.GDBurrowObjects4= [];
gdjs.GalleryCode.GDBurrowObjects5= [];
gdjs.GalleryCode.GDBurrowObjects6= [];
gdjs.GalleryCode.GDBurrowObjects7= [];
gdjs.GalleryCode.GDBurrowObjects8= [];
gdjs.GalleryCode.GDBurrowObjects9= [];
gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects1= [];
gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects2= [];
gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects3= [];
gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects4= [];
gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects5= [];
gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects6= [];
gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects7= [];
gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects8= [];
gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects9= [];
gdjs.GalleryCode.GDSkyObjects1= [];
gdjs.GalleryCode.GDSkyObjects2= [];
gdjs.GalleryCode.GDSkyObjects3= [];
gdjs.GalleryCode.GDSkyObjects4= [];
gdjs.GalleryCode.GDSkyObjects5= [];
gdjs.GalleryCode.GDSkyObjects6= [];
gdjs.GalleryCode.GDSkyObjects7= [];
gdjs.GalleryCode.GDSkyObjects8= [];
gdjs.GalleryCode.GDSkyObjects9= [];
gdjs.GalleryCode.GDJerry_9595LogoObjects1= [];
gdjs.GalleryCode.GDJerry_9595LogoObjects2= [];
gdjs.GalleryCode.GDJerry_9595LogoObjects3= [];
gdjs.GalleryCode.GDJerry_9595LogoObjects4= [];
gdjs.GalleryCode.GDJerry_9595LogoObjects5= [];
gdjs.GalleryCode.GDJerry_9595LogoObjects6= [];
gdjs.GalleryCode.GDJerry_9595LogoObjects7= [];
gdjs.GalleryCode.GDJerry_9595LogoObjects8= [];
gdjs.GalleryCode.GDJerry_9595LogoObjects9= [];
gdjs.GalleryCode.GDBrains_9595EatenObjects1= [];
gdjs.GalleryCode.GDBrains_9595EatenObjects2= [];
gdjs.GalleryCode.GDBrains_9595EatenObjects3= [];
gdjs.GalleryCode.GDBrains_9595EatenObjects4= [];
gdjs.GalleryCode.GDBrains_9595EatenObjects5= [];
gdjs.GalleryCode.GDBrains_9595EatenObjects6= [];
gdjs.GalleryCode.GDBrains_9595EatenObjects7= [];
gdjs.GalleryCode.GDBrains_9595EatenObjects8= [];
gdjs.GalleryCode.GDBrains_9595EatenObjects9= [];
gdjs.GalleryCode.GDTransitionObjects1= [];
gdjs.GalleryCode.GDTransitionObjects2= [];
gdjs.GalleryCode.GDTransitionObjects3= [];
gdjs.GalleryCode.GDTransitionObjects4= [];
gdjs.GalleryCode.GDTransitionObjects5= [];
gdjs.GalleryCode.GDTransitionObjects6= [];
gdjs.GalleryCode.GDTransitionObjects7= [];
gdjs.GalleryCode.GDTransitionObjects8= [];
gdjs.GalleryCode.GDTransitionObjects9= [];
gdjs.GalleryCode.GDHigh_9595ScoreObjects1= [];
gdjs.GalleryCode.GDHigh_9595ScoreObjects2= [];
gdjs.GalleryCode.GDHigh_9595ScoreObjects3= [];
gdjs.GalleryCode.GDHigh_9595ScoreObjects4= [];
gdjs.GalleryCode.GDHigh_9595ScoreObjects5= [];
gdjs.GalleryCode.GDHigh_9595ScoreObjects6= [];
gdjs.GalleryCode.GDHigh_9595ScoreObjects7= [];
gdjs.GalleryCode.GDHigh_9595ScoreObjects8= [];
gdjs.GalleryCode.GDHigh_9595ScoreObjects9= [];
gdjs.GalleryCode.GDRocks_9595DestroyedObjects1= [];
gdjs.GalleryCode.GDRocks_9595DestroyedObjects2= [];
gdjs.GalleryCode.GDRocks_9595DestroyedObjects3= [];
gdjs.GalleryCode.GDRocks_9595DestroyedObjects4= [];
gdjs.GalleryCode.GDRocks_9595DestroyedObjects5= [];
gdjs.GalleryCode.GDRocks_9595DestroyedObjects6= [];
gdjs.GalleryCode.GDRocks_9595DestroyedObjects7= [];
gdjs.GalleryCode.GDRocks_9595DestroyedObjects8= [];
gdjs.GalleryCode.GDRocks_9595DestroyedObjects9= [];
gdjs.GalleryCode.GDGames_9595PlayedObjects1= [];
gdjs.GalleryCode.GDGames_9595PlayedObjects2= [];
gdjs.GalleryCode.GDGames_9595PlayedObjects3= [];
gdjs.GalleryCode.GDGames_9595PlayedObjects4= [];
gdjs.GalleryCode.GDGames_9595PlayedObjects5= [];
gdjs.GalleryCode.GDGames_9595PlayedObjects6= [];
gdjs.GalleryCode.GDGames_9595PlayedObjects7= [];
gdjs.GalleryCode.GDGames_9595PlayedObjects8= [];
gdjs.GalleryCode.GDGames_9595PlayedObjects9= [];


gdjs.GalleryCode.asyncCallback15335628 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 1.aac", false, 100, 1);
}}
gdjs.GalleryCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.GalleryCode.asyncCallback15335628(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15335484);
}
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.asyncCallback15338124 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 1.aac", false, 100, 1);
}}
gdjs.GalleryCode.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.GalleryCode.asyncCallback15338124(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15337980);
}
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}{/* Unknown object - skipped. */}}

}


};gdjs.GalleryCode.eventsList5 = function(runtimeScene) {

{


gdjs.GalleryCode.eventsList1(runtimeScene);
}


{


gdjs.GalleryCode.eventsList3(runtimeScene);
}


{


gdjs.GalleryCode.eventsList4(runtimeScene);
}


};gdjs.GalleryCode.asyncCallback15353668 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}}
gdjs.GalleryCode.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.GalleryCode.asyncCallback15353668(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GalleryCode.asyncCallback15352660 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.GalleryCode.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GalleryCode.eventsList8 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.GalleryCode.asyncCallback15352660(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList9 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList8(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GalleryCode.asyncCallback15352020 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.GalleryCode.eventsList9(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GalleryCode.eventsList10 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.GalleryCode.asyncCallback15352020(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList11 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList10(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GalleryCode.asyncCallback15348764 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.GalleryCode.eventsList11(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GalleryCode.eventsList12 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.GalleryCode.asyncCallback15348764(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList13 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList12(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GalleryCode.asyncCallback15347756 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.GalleryCode.eventsList13(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GalleryCode.eventsList14 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.GalleryCode.asyncCallback15347756(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList15 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList14(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GalleryCode.asyncCallback15346748 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.GalleryCode.eventsList15(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GalleryCode.eventsList16 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.GalleryCode.asyncCallback15346748(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList17 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList16(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GalleryCode.asyncCallback15346108 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.GalleryCode.eventsList17(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GalleryCode.eventsList18 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.GalleryCode.asyncCallback15346108(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList20 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
/* Unknown object - skipped. */if (isConditionTrue_1) {
isConditionTrue_1 = false;
{let isConditionTrue_2 = false;
isConditionTrue_1 = false;
{
isConditionTrue_2 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
isConditionTrue_2 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "a"));
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
isConditionTrue_2 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right"));
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
isConditionTrue_2 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "d"));
if(isConditionTrue_2) {
    isConditionTrue_1 = true;
}
}
{
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15343940);
}
}
}
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 1.aac", false, 100, 1);
}
{ //Subevents
gdjs.GalleryCode.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList21 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.GalleryCode.eventsList22 = function(runtimeScene) {

{


gdjs.GalleryCode.eventsList5(runtimeScene);
}


{


gdjs.GalleryCode.eventsList20(runtimeScene);
}


{


gdjs.GalleryCode.eventsList21(runtimeScene);
}


};gdjs.GalleryCode.eventsList23 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
{/* Unknown object - skipped. */}}

}


};gdjs.GalleryCode.asyncCallback15359244 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.GalleryCode.eventsList23(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GalleryCode.eventsList24 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.GalleryCode.asyncCallback15359244(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList25 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList24(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GalleryCode.asyncCallback15358196 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.GalleryCode.eventsList25(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GalleryCode.eventsList26 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.GalleryCode.asyncCallback15358196(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList27 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList26(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GalleryCode.asyncCallback15356204 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.GalleryCode.eventsList27(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GalleryCode.eventsList28 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.GalleryCode.asyncCallback15356204(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList29 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 3;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList28(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList30 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15355716);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.GalleryCode.eventsList29(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList31 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15360356);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


};gdjs.GalleryCode.asyncCallback15364596 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}}
gdjs.GalleryCode.eventsList32 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.GalleryCode.asyncCallback15364596(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList33 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{runtimeScene.getScene().getVariables().get("Brains_Eaten_Number").add(1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 2.aac", false, 100, 1);
}
{ //Subevents
gdjs.GalleryCode.eventsList32(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList34 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
/* Unknown object - skipped. */if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
/* Unknown object - skipped. */if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
}
{ //Subevents
gdjs.GalleryCode.eventsList33(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.asyncCallback15366372 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}}
gdjs.GalleryCode.eventsList35 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.GalleryCode.asyncCallback15366372(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList36 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().get("Rocks_Destroyed_Number").add(1);
}
{ //Subevents
gdjs.GalleryCode.eventsList35(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList37 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15365252);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.GalleryCode.eventsList36(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.asyncCallback15368956 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}
gdjs.GalleryCode.eventsList38 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.GalleryCode.asyncCallback15368956(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList39 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.GalleryCode.eventsList38(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList40 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15368004);
}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.GalleryCode.eventsList39(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList41 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList40(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList42 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("GameStorage", "BrainsEatenNumber", runtimeScene, runtimeScene.getScene().getVariables().get("Brains_Eaten_Number"));
}}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Brains_Eaten_Number")));
}}

}


{



}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeNumberInJSONFile("GameStorage", "BrainsEatenNumber", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Brains_Eaten_Number")));
}}

}


};gdjs.GalleryCode.eventsList43 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("GameStorage", "RocksDestroyedNumber", runtimeScene, runtimeScene.getScene().getVariables().get("Rocks_Destroyed_Number"));
}}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Rocks_Destroyed_Number")));
}}

}


{



}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeNumberInJSONFile("GameStorage", "RocksDestroyedNumber", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Rocks_Destroyed_Number")));
}}

}


};gdjs.GalleryCode.eventsList44 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("GameStorage", "GamesPlayedNumber", runtimeScene, runtimeScene.getScene().getVariables().get("Games_Played_Number"));
}}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Games_Played_Number")));
}}

}


{



}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeNumberInJSONFile("GameStorage", "GamesPlayedNumber", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Games_Played_Number")));
}}

}


};gdjs.GalleryCode.eventsList45 = function(runtimeScene) {

{


gdjs.GalleryCode.eventsList42(runtimeScene);
}


{


gdjs.GalleryCode.eventsList43(runtimeScene);
}


{


gdjs.GalleryCode.eventsList44(runtimeScene);
}


};gdjs.GalleryCode.eventsList46 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Gameplay");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}}

}


};gdjs.GalleryCode.eventsList47 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burrow"), gdjs.GalleryCode.GDBurrowObjects3);
{for(var i = 0, len = gdjs.GalleryCode.GDBurrowObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDBurrowObjects3[i].getBehavior("Animation").setAnimationName("Night");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burrow"), gdjs.GalleryCode.GDBurrowObjects3);
{for(var i = 0, len = gdjs.GalleryCode.GDBurrowObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDBurrowObjects3[i].getBehavior("Animation").setAnimationName("Day");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__October.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burrow"), gdjs.GalleryCode.GDBurrowObjects3);
{for(var i = 0, len = gdjs.GalleryCode.GDBurrowObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDBurrowObjects3[i].getBehavior("Animation").setAnimationName("Halloween");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__December.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Burrow"), gdjs.GalleryCode.GDBurrowObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDBurrowObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDBurrowObjects2[i].getBehavior("Animation").setAnimationName("Christmas");
}
}}

}


};gdjs.GalleryCode.eventsList48 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Dawn.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.GalleryCode.GDSkyObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDSkyObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSkyObjects2[i].getBehavior("Animation").setAnimationName("Dawn");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Morning.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.GalleryCode.GDSkyObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDSkyObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSkyObjects2[i].getBehavior("Animation").setAnimationName("Day");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Dusk.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.GalleryCode.GDSkyObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDSkyObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSkyObjects2[i].getBehavior("Animation").setAnimationName("Dusk");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.GalleryCode.GDSkyObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDSkyObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSkyObjects2[i].getBehavior("Animation").setAnimationName("Night");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__October.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sky"), gdjs.GalleryCode.GDSkyObjects1);
{for(var i = 0, len = gdjs.GalleryCode.GDSkyObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDSkyObjects1[i].getBehavior("Animation").setAnimationName("Halloween");
}
}}

}


};gdjs.GalleryCode.eventsList49 = function(runtimeScene) {

{


gdjs.GalleryCode.eventsList47(runtimeScene);
}


{


gdjs.GalleryCode.eventsList48(runtimeScene);
}


};gdjs.GalleryCode.eventsList50 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainSpawn");
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) < 10;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "BrainSpawn") > 5;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainSpawn");
}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 10;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "BrainSpawn") > 5;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainSpawn");
}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= 50;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "BrainSpawn") > 5;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainSpawn");
}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


};gdjs.GalleryCode.eventsList51 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.GalleryCode.eventsList52 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) >= 3);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.GalleryCode.eventsList51(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList53 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.GalleryCode.eventsList54 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) >= 3);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.GalleryCode.eventsList53(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList55 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainScrollingSpeed");
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.setLayerTimeScale(runtimeScene, "Brains", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("BrainScrollingSpeed")));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "BrainScrollingSpeed") >= 90;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("BrainScrollingSpeed").add(0.6);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "BrainScrollingSpeed");
}}

}


};gdjs.GalleryCode.eventsList56 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.GalleryCode.eventsList57 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 1;
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 2;
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 3;
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


};gdjs.GalleryCode.asyncCallback14681804 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.GalleryCode.eventsList57(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GalleryCode.eventsList58 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14681804(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList59 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 4.aac", false, 100, 0.5);
}
{ //Subevents
gdjs.GalleryCode.eventsList58(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList60 = function(runtimeScene) {

{


gdjs.GalleryCode.eventsList50(runtimeScene);
}


{


gdjs.GalleryCode.eventsList52(runtimeScene);
}


{


gdjs.GalleryCode.eventsList54(runtimeScene);
}


{


gdjs.GalleryCode.eventsList55(runtimeScene);
}


{


gdjs.GalleryCode.eventsList56(runtimeScene);
}


{


gdjs.GalleryCode.eventsList59(runtimeScene);
}


};gdjs.GalleryCode.eventsList61 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "RockSpawn");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Gameplay") > 30;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "RockSpawn") > 30;
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "RockSpawn");
}{/* Unknown object - skipped. */}{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.GalleryCode.eventsList62 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "RockFallingSpeed");
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.camera.setLayerTimeScale(runtimeScene, "Rocks", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("RockFallingSpeed")));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "RockFallingSpeed") >= 90;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("RockFallingSpeed").add(0.7);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "RockFallingSpeed");
}}

}


};gdjs.GalleryCode.eventsList63 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) >= 3);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


gdjs.GalleryCode.eventsList62(runtimeScene);
}


};gdjs.GalleryCode.asyncCallback14694292 = function (runtimeScene, asyncObjectsList) {
{/* Unknown object - skipped. */}}
gdjs.GalleryCode.eventsList64 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14694292(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList65 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.GalleryCode.eventsList64(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList66 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14695748);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(5);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Coins 2.aac", false, 100, 1);
}}

}


};gdjs.GalleryCode.eventsList67 = function(runtimeScene) {

{


gdjs.GalleryCode.eventsList61(runtimeScene);
}


{


gdjs.GalleryCode.eventsList63(runtimeScene);
}


{


gdjs.GalleryCode.eventsList65(runtimeScene);
}


{


gdjs.GalleryCode.eventsList66(runtimeScene);
}


};gdjs.GalleryCode.eventsList68 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 3;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title", false);
}}

}


};gdjs.GalleryCode.asyncCallback14698556 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getScene().getVariables().get("Games_Played_Number").add(1);
}}
gdjs.GalleryCode.eventsList69 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(52), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14698556(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList70 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14698332);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList69(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList71 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num1");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Delete");
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14700316);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("HighScore").setNumber(0);
}{runtimeScene.getScene().getVariables().get("Brains_Eaten_Number").setNumber(0);
}{runtimeScene.getScene().getVariables().get("Games_Played_Number").setNumber(0);
}{runtimeScene.getScene().getVariables().get("Rocks_Destroyed_Number").setNumber(0);
}}

}


};gdjs.GalleryCode.eventsList72 = function(runtimeScene) {

{


gdjs.GalleryCode.eventsList71(runtimeScene);
}


};gdjs.GalleryCode.eventsList73 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("GameStorage", "HighScore", runtimeScene, runtimeScene.getScene().getVariables().get("HighScore"));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("HighScore"));
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("HighScore").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("High_Score_Gameplay"), gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects2[i].getBehavior("Text").setText("High Score: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("HighScore")));
}
}{gdjs.evtTools.storage.writeNumberInJSONFile("GameStorage", "HighScore", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("HighScore")));
}}

}


{


let isConditionTrue_0 = false;
{
{/* Unknown object - skipped. */}}

}


};gdjs.GalleryCode.eventsList74 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.GalleryCode.eventsList75 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown object - skipped. */if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.GalleryCode.eventsList76 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14705820);
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.GalleryCode.eventsList74(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14707396);
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14708140);
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}
{ //Subevents
gdjs.GalleryCode.eventsList75(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14709716);
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.GalleryCode.eventsList77 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14710596);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14711500);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__TimeDetector__Night.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
if (isConditionTrue_0) {
{/* Unknown object - skipped. */}}

}


};gdjs.GalleryCode.eventsList78 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList76(runtimeScene);} //End of subevents
}

}


{


gdjs.GalleryCode.eventsList77(runtimeScene);
}


};gdjs.GalleryCode.eventsList79 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) >= 3;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) >= 10;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
}}

}


{



}


{



}


{



}


{



}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8)) >= 20;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), true);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) >= 50;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), true);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 500;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(13), true);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 1000;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) >= 200;
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(14), true);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 1500;
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), true);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 3000;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) >= 500;
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(16), true);
}}

}


};gdjs.GalleryCode.eventsList80 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 3;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage", false);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title", false);
}}

}


};gdjs.GalleryCode.eventsList81 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num2");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "NumpadReturn");
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14726532);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(13), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(14), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(16), true);
}}

}


};gdjs.GalleryCode.eventsList82 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num2");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Delete");
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14729444);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(13), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(14), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(16), false);
}}

}


};gdjs.GalleryCode.eventsList83 = function(runtimeScene) {

{


gdjs.GalleryCode.eventsList80(runtimeScene);
}


{


gdjs.GalleryCode.eventsList81(runtimeScene);
}


{


gdjs.GalleryCode.eventsList82(runtimeScene);
}


};gdjs.GalleryCode.eventsList84 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isPreview(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList83(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList85 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Text"), gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Text"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Text"), gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Text"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Text"), gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Text"), gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Text"), gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Text"), gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects2[i].setCenterYInScene(540);
}
for(var i = 0, len = gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects2[i].setCenterYInScene(540);
}
for(var i = 0, len = gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects2[i].setCenterYInScene(540);
}
for(var i = 0, len = gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects2[i].setCenterYInScene(540);
}
for(var i = 0, len = gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects2[i].setCenterYInScene(540);
}
for(var i = 0, len = gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects2[i].setCenterYInScene(540);
}
for(var i = 0, len = gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects2[i].setCenterYInScene(540);
}
for(var i = 0, len = gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects2[i].setCenterYInScene(540);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Text"), gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Text"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Character_Name"), gdjs.GalleryCode.GDCharacter_9595NameObjects2);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Text"), gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Text"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Text"), gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Text"), gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Text"), gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Text"), gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDCharacter_9595NameObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDCharacter_9595NameObjects2[i].setY((( gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects2[0].getY()) :gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects2[0].getY()) :gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects2[0].getY()) :gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects2[0].getY()) :gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects2[0].getY()) :gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects2[0].getY()) :gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects2[0].getY()) :gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects2[0].getY()) - 100);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDCharacter_9595NameObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDCharacter_9595NameObjects2[i].setCenterXInScene((( gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects2.length === 0 ) ? (( gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects2[0].getCenterXInScene()) :gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects2[0].getCenterXInScene()) :gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects2[0].getCenterXInScene()) :gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects2[0].getCenterXInScene()) :gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects2[0].getCenterXInScene()) :gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects2[0].getCenterXInScene()) :gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects2[0].getCenterXInScene()) :gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects2[0].getCenterXInScene()));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Border_Bottom"), gdjs.GalleryCode.GDBorder_9595BottomObjects2);
gdjs.copyArray(runtimeScene.getObjects("Border_L"), gdjs.GalleryCode.GDBorder_9595LObjects2);
gdjs.copyArray(runtimeScene.getObjects("Border_R"), gdjs.GalleryCode.GDBorder_9595RObjects2);
gdjs.copyArray(runtimeScene.getObjects("Border_Top"), gdjs.GalleryCode.GDBorder_9595TopObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDBorder_9595RObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDBorder_9595RObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GalleryCode.GDBorder_9595LObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDBorder_9595LObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GalleryCode.GDBorder_9595TopObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDBorder_9595TopObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GalleryCode.GDBorder_9595BottomObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDBorder_9595BottomObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Image"), gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects2);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Image"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects2);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Image"), gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects2);
gdjs.copyArray(runtimeScene.getObjects("Gallery_Image_Box"), gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Image"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Image"), gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects2);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Image"), gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Image"), gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Image"), gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects2[i].setCenterPositionInScene((( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2[0].getPointX("")),(( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects2[i].setCenterPositionInScene((( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2[0].getPointX("")),(( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects2[i].setCenterPositionInScene((( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2[0].getPointX("")),(( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects2[i].setCenterPositionInScene((( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2[0].getPointX("")),(( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects2[i].setCenterPositionInScene((( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2[0].getPointX("")),(( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects2[i].setCenterPositionInScene((( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2[0].getPointX("")),(( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects2[i].setCenterPositionInScene((( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2[0].getPointX("")),(( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects2[i].setCenterPositionInScene((( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2[0].getPointX("")),(( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2[i].hide();
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects1);
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects1[i].setCenterXInScene(960);
}
}}

}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDBorder_95959595RObjects2Objects = Hashtable.newFrom({"Border_R": gdjs.GalleryCode.GDBorder_9595RObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Jerry_Gallery_Thumbnail": gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2, "Rudy_Gallery_Thumbnail": gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects2, "Conquest_Gallery_Thumbnail": gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects2, "Libby_Gallery_Thumbnail": gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects2, "General_Gallery_Thumbnail": gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects2, "Zombie_Gallery_Thumbnail": gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects2, "Alien_Gallery_Thumbnail": gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects2, "Carcass_Gallery_Thumbnail": gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDBorder_95959595LObjects2Objects = Hashtable.newFrom({"Border_L": gdjs.GalleryCode.GDBorder_9595LObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Jerry_Gallery_Thumbnail": gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2, "Rudy_Gallery_Thumbnail": gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects2, "Conquest_Gallery_Thumbnail": gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects2, "Libby_Gallery_Thumbnail": gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects2, "General_Gallery_Thumbnail": gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects2, "Zombie_Gallery_Thumbnail": gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects2, "Alien_Gallery_Thumbnail": gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects2, "Carcass_Gallery_Thumbnail": gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDBorder_95959595BottomObjects2Objects = Hashtable.newFrom({"Border_Bottom": gdjs.GalleryCode.GDBorder_9595BottomObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Jerry_Gallery_Thumbnail": gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2, "Rudy_Gallery_Thumbnail": gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects2, "Conquest_Gallery_Thumbnail": gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects2, "Libby_Gallery_Thumbnail": gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects2, "General_Gallery_Thumbnail": gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects2, "Zombie_Gallery_Thumbnail": gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects2, "Alien_Gallery_Thumbnail": gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects2, "Carcass_Gallery_Thumbnail": gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDBorder_95959595TopObjects1Objects = Hashtable.newFrom({"Border_Top": gdjs.GalleryCode.GDBorder_9595TopObjects1});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Jerry_Gallery_Thumbnail": gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects1, "Rudy_Gallery_Thumbnail": gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects1, "Conquest_Gallery_Thumbnail": gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects1, "Libby_Gallery_Thumbnail": gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects1, "General_Gallery_Thumbnail": gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects1, "Zombie_Gallery_Thumbnail": gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects1, "Alien_Gallery_Thumbnail": gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects1, "Carcass_Gallery_Thumbnail": gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects1});
gdjs.GalleryCode.eventsList86 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14911748);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2);
gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, (( gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2[0].getPointX("")), (( gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2.length === 0 ) ? 0 :gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Resizable").setSize(300, 352);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Border_R"), gdjs.GalleryCode.GDBorder_9595RObjects2);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDBorder_95959595RObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14912820);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2 */
{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].setX(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].getX() + (437));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Border_L"), gdjs.GalleryCode.GDBorder_9595LObjects2);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDBorder_95959595LObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14914596);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2 */
{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].setX(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].getX() - (437));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Border_Bottom"), gdjs.GalleryCode.GDBorder_9595BottomObjects2);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDBorder_95959595BottomObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2ObjectsGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14915428);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2 */
{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].setY(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].getY() + (448));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Border_Top"), gdjs.GalleryCode.GDBorder_9595TopObjects1);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDBorder_95959595TopObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14916900);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1 */
{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1[i].setY(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1[i].getY() - (448));
}
}}

}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Jerry_Gallery_Thumbnail": gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595TextObjects4Objects = Hashtable.newFrom({"Jerry_Gallery_Text": gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects4});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595ImageObjects4Objects = Hashtable.newFrom({"Jerry_Gallery_Image": gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects4});
gdjs.GalleryCode.asyncCallback14921908 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Gallery_Image_Box"), gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4);
gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects4.length = 0;

gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595TextObjects4Objects, 692, 320, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595ImageObjects4Objects, (( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4[0].getPointX("")), (( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4[0].getPointY("")), "");
}}
gdjs.GalleryCode.eventsList87 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14921908(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.asyncCallback14923204 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3);

{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].setX(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].getX() - (3000));
}
}}
gdjs.GalleryCode.eventsList88 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2) asyncObjectsList.addObject("Hover_Gallery_Thumbnail", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.12), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14923204(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList89 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Character_Name"), gdjs.GalleryCode.GDCharacter_9595NameObjects3);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2, gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2, gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects3);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GalleryCode.GDCharacter_9595NameObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDCharacter_9595NameObjects3[i].getBehavior("Text").setText("Jerry");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.GalleryCode.eventsList87(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14923132);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList88(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList90 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Animation").setAnimationName("Gallery Thumbnail Jerry");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList89(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Rudy_Gallery_Thumbnail": gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595TextObjects4Objects = Hashtable.newFrom({"Rudy_Gallery_Text": gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects4});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595ImageObjects4Objects = Hashtable.newFrom({"Rudy_Gallery_Image": gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects4});
gdjs.GalleryCode.asyncCallback14927452 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Gallery_Image_Box"), gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4);
gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects4.length = 0;

gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595TextObjects4Objects, 692, 320, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595ImageObjects4Objects, (( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4[0].getPointX("")), (( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4[0].getPointY("")), "");
}}
gdjs.GalleryCode.eventsList91 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14927452(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.asyncCallback14928748 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3);

{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].setX(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].getX() - (3000));
}
}}
gdjs.GalleryCode.eventsList92 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2) asyncObjectsList.addObject("Hover_Gallery_Thumbnail", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.12), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14928748(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList93 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Character_Name"), gdjs.GalleryCode.GDCharacter_9595NameObjects3);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2, gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects2, gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects3);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GalleryCode.GDCharacter_9595NameObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDCharacter_9595NameObjects3[i].getBehavior("Text").setText("Rudy The Brain Rabbit");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.GalleryCode.eventsList91(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14928676);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList92(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList94 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Animation").setAnimationName("Gallery Thumbnail Rudy");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList93(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Zombie_Gallery_Thumbnail": gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595TextObjects4Objects = Hashtable.newFrom({"Zombie_Gallery_Text": gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects4});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595ImageObjects4Objects = Hashtable.newFrom({"Zombie_Gallery_Image": gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects4});
gdjs.GalleryCode.asyncCallback14933052 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Gallery_Image_Box"), gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4);
gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects4.length = 0;

gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595TextObjects4Objects, 692, 320, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595ImageObjects4Objects, (( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4[0].getPointX("")), (( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4[0].getPointY("")), "");
}}
gdjs.GalleryCode.eventsList95 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14933052(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.asyncCallback14934340 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3);

{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].setX(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].getX() - (3000));
}
}}
gdjs.GalleryCode.eventsList96 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2) asyncObjectsList.addObject("Hover_Gallery_Thumbnail", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.12), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14934340(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList97 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Character_Name"), gdjs.GalleryCode.GDCharacter_9595NameObjects3);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2, gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects3);
gdjs.copyArray(gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects2, gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3);

{for(var i = 0, len = gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GalleryCode.GDCharacter_9595NameObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDCharacter_9595NameObjects3[i].getBehavior("Text").setText("Zombie Gerbil");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.GalleryCode.eventsList95(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14933188);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList96(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList98 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Animation").setAnimationName("Gallery Thumbnail Zombie");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList97(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Alien_Gallery_Thumbnail": gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595TextObjects4Objects = Hashtable.newFrom({"Alien_Gallery_Text": gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects4});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595ImageObjects4Objects = Hashtable.newFrom({"Alien_Gallery_Image": gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects4});
gdjs.GalleryCode.asyncCallback14938628 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Gallery_Image_Box"), gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4);
gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects4.length = 0;

gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595TextObjects4Objects, 692, 320, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595ImageObjects4Objects, (( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4[0].getPointX("")), (( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4[0].getPointY("")), "");
}}
gdjs.GalleryCode.eventsList99 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14938628(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.asyncCallback14939948 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3);

{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].setX(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].getX() - (3000));
}
}}
gdjs.GalleryCode.eventsList100 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2) asyncObjectsList.addObject("Hover_Gallery_Thumbnail", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.12), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14939948(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList101 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects2, gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Character_Name"), gdjs.GalleryCode.GDCharacter_9595NameObjects3);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2, gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects3);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GalleryCode.GDCharacter_9595NameObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDCharacter_9595NameObjects3[i].getBehavior("Text").setText("Alien");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.GalleryCode.eventsList99(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14939876);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList100(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList102 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Animation").setAnimationName("Gallery Thumbnail Alien");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList101(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Conquest_Gallery_Thumbnail": gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595TextObjects4Objects = Hashtable.newFrom({"Conquest_Gallery_Text": gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects4});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595ImageObjects4Objects = Hashtable.newFrom({"Conquest_Gallery_Image": gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects4});
gdjs.GalleryCode.asyncCallback14944260 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Gallery_Image_Box"), gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4);
gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects4.length = 0;

gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595TextObjects4Objects, 692, 320, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595ImageObjects4Objects, (( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4[0].getPointX("")), (( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4[0].getPointY("")), "");
}}
gdjs.GalleryCode.eventsList103 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14944260(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.asyncCallback14945548 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3);

{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].setX(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].getX() - (3000));
}
}}
gdjs.GalleryCode.eventsList104 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2) asyncObjectsList.addObject("Hover_Gallery_Thumbnail", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.12), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14945548(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList105 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Character_Name"), gdjs.GalleryCode.GDCharacter_9595NameObjects3);
gdjs.copyArray(gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects2, gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2, gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects3);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GalleryCode.GDCharacter_9595NameObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDCharacter_9595NameObjects3[i].getBehavior("Text").setText("Dr. Conquest");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.GalleryCode.eventsList103(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14944396);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList104(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList106 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(13), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Animation").setAnimationName("Gallery Thumbnail Conquest");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(13), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList105(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Carcass_Gallery_Thumbnail": gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595TextObjects4Objects = Hashtable.newFrom({"Carcass_Gallery_Text": gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects4});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595ImageObjects4Objects = Hashtable.newFrom({"Carcass_Gallery_Image": gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects4});
gdjs.GalleryCode.asyncCallback14949996 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Gallery_Image_Box"), gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4);
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects4.length = 0;

gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595TextObjects4Objects, 692, 320, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595ImageObjects4Objects, (( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4[0].getPointX("")), (( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4[0].getPointY("")), "");
}}
gdjs.GalleryCode.eventsList107 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14949996(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.asyncCallback14951212 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3);

{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].setX(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].getX() - (3000));
}
}}
gdjs.GalleryCode.eventsList108 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2) asyncObjectsList.addObject("Hover_Gallery_Thumbnail", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.12), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14951212(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList109 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects2, gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Character_Name"), gdjs.GalleryCode.GDCharacter_9595NameObjects3);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2, gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects3);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GalleryCode.GDCharacter_9595NameObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDCharacter_9595NameObjects3[i].getBehavior("Text").setText("Gerbil Carcass");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.GalleryCode.eventsList107(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14951052);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList108(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList110 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(14), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Animation").setAnimationName("Gallery Thumbnail Carcass");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(14), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList109(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"General_Gallery_Thumbnail": gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595TextObjects4Objects = Hashtable.newFrom({"General_Gallery_Text": gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects4});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595ImageObjects4Objects = Hashtable.newFrom({"General_Gallery_Image": gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects4});
gdjs.GalleryCode.asyncCallback14955588 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Gallery_Image_Box"), gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4);
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects4.length = 0;

gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595TextObjects4Objects, 692, 320, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595ImageObjects4Objects, (( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4[0].getPointX("")), (( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4[0].getPointY("")), "");
}}
gdjs.GalleryCode.eventsList111 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14955588(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.asyncCallback14956884 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3);

{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].setX(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].getX() - (3000));
}
}}
gdjs.GalleryCode.eventsList112 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2) asyncObjectsList.addObject("Hover_Gallery_Thumbnail", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.12), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14956884(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList113 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Character_Name"), gdjs.GalleryCode.GDCharacter_9595NameObjects3);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects2, gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2, gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3);

gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3);
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects3);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GalleryCode.GDCharacter_9595NameObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDCharacter_9595NameObjects3[i].getBehavior("Text").setText("General");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.GalleryCode.eventsList111(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14956812);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList112(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList114 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3);
{for(var i = 0, len = gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3.length ;i < len;++i) {
    gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3[i].getBehavior("Animation").setAnimationName("Gallery Thumbnail General");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList113(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Libby_Gallery_Thumbnail": gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects1});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595TextObjects3Objects = Hashtable.newFrom({"Libby_Gallery_Text": gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects3});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595ImageObjects3Objects = Hashtable.newFrom({"Libby_Gallery_Image": gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects3});
gdjs.GalleryCode.asyncCallback14961092 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Gallery_Image_Box"), gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects3);
gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects3.length = 0;

gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595TextObjects3Objects, 692, 320, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595ImageObjects3Objects, (( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects3.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects3[0].getPointX("")), (( gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects3.length === 0 ) ? 0 :gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects3[0].getPointY("")), "");
}}
gdjs.GalleryCode.eventsList115 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14961092(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.asyncCallback14962412 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);

{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].setX(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].getX() - (3000));
}
}}
gdjs.GalleryCode.eventsList116 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1) asyncObjectsList.addObject("Hover_Gallery_Thumbnail", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.12), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14962412(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList117 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Character_Name"), gdjs.GalleryCode.GDCharacter_9595NameObjects2);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1, gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);

gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects1, gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects2);

gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Tween").addObjectPositionYTween2("Tween", -(250), "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 1000, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GalleryCode.GDCharacter_9595NameObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDCharacter_9595NameObjects2[i].getBehavior("Text").setText("Libby");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.GalleryCode.eventsList115(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14962340);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList116(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList118 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(16), true);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects2[i].getBehavior("Animation").setAnimationName("Gallery Thumbnail Libby");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(16), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList117(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList119 = function(runtimeScene) {

{


gdjs.GalleryCode.eventsList90(runtimeScene);
}


{


gdjs.GalleryCode.eventsList94(runtimeScene);
}


{


gdjs.GalleryCode.eventsList98(runtimeScene);
}


{


gdjs.GalleryCode.eventsList102(runtimeScene);
}


{


gdjs.GalleryCode.eventsList106(runtimeScene);
}


{


gdjs.GalleryCode.eventsList110(runtimeScene);
}


{


gdjs.GalleryCode.eventsList114(runtimeScene);
}


{


gdjs.GalleryCode.eventsList118(runtimeScene);
}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Jerry_Gallery_Thumbnail": gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects1, "Rudy_Gallery_Thumbnail": gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects1, "Conquest_Gallery_Thumbnail": gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects1, "Libby_Gallery_Thumbnail": gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects1, "General_Gallery_Thumbnail": gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects1, "Zombie_Gallery_Thumbnail": gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects1, "Alien_Gallery_Thumbnail": gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects1, "Carcass_Gallery_Thumbnail": gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects1});
gdjs.GalleryCode.asyncCallback14965548 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);

{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].setX(gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2[i].getX() + (3000));
}
}}
gdjs.GalleryCode.eventsList120 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1) asyncObjectsList.addObject("Hover_Gallery_Thumbnail", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.12), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14965548(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList121 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14965388);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GalleryCode.eventsList120(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList122 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects1ObjectsGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Image"), gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects1);
gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Text"), gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects1);
/* Reuse gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Image"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects1);
gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Text"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects1);
/* Reuse gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Image"), gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects1);
gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Text"), gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects1);
/* Reuse gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects1 */
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Image"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects1);
gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Text"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects1);
/* Reuse gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects1 */
/* Reuse gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Image"), gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects1);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Text"), gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects1);
/* Reuse gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Image"), gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects1);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Text"), gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects1);
/* Reuse gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Image"), gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects1);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Text"), gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects1);
/* Reuse gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects1);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Image"), gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects1);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Text"), gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects1);
/* Reuse gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects1 */
{for(var i = 0, len = gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 149, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 149, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 149, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 149, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 597, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 597, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 597, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Tween", 597, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.GalleryCode.eventsList121(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Jerry_Gallery_Thumbnail": gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Rudy_Gallery_Thumbnail": gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.eventsList123 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
if (isConditionTrue_0) {
/* Reuse gdjs.GalleryCode.GDSelected_9595ItemObjects2 */
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Play 10 Games");
}
}}

}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Zombie_Gallery_Thumbnail": gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.eventsList124 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
if (isConditionTrue_0) {
/* Reuse gdjs.GalleryCode.GDSelected_9595ItemObjects2 */
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Play 20 Games");
}
}}

}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Alien_Gallery_Thumbnail": gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.eventsList125 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)) >= 1;
if (isConditionTrue_0) {
/* Reuse gdjs.GalleryCode.GDSelected_9595ItemObjects2 */
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Destroy 50 Rocks");
}
}}

}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Conquest_Gallery_Thumbnail": gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.eventsList126 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 250;
if (isConditionTrue_0) {
/* Reuse gdjs.GalleryCode.GDSelected_9595ItemObjects2 */
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Eat 500 Brains");
}
}}

}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Carcass_Gallery_Thumbnail": gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.eventsList127 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 500;
if (isConditionTrue_0) {
/* Reuse gdjs.GalleryCode.GDSelected_9595ItemObjects2 */
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Eat 1000 Brains and destroy 200 rocks");
}
}}

}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"General_Gallery_Thumbnail": gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.eventsList128 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) >= 500;
if (isConditionTrue_0) {
/* Reuse gdjs.GalleryCode.GDSelected_9595ItemObjects2 */
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Eat 1500 Brains");
}
}}

}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Libby_Gallery_Thumbnail": gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects1});
gdjs.GalleryCode.eventsList129 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Play 3 Games");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("???");
}
}
{ //Subevents
gdjs.GalleryCode.eventsList123(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("???");
}
}
{ //Subevents
gdjs.GalleryCode.eventsList124(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("???");
}
}
{ //Subevents
gdjs.GalleryCode.eventsList125(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(13), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("???");
}
}
{ //Subevents
gdjs.GalleryCode.eventsList126(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(14), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("???");
}
}
{ //Subevents
gdjs.GalleryCode.eventsList127(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("???");
}
}
{ //Subevents
gdjs.GalleryCode.eventsList128(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(16), false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects1);
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects1[i].getBehavior("Text").setText("???");
}
}}

}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Jerry_Gallery_Thumbnail": gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Rudy_Gallery_Thumbnail": gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Zombie_Gallery_Thumbnail": gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Alien_Gallery_Thumbnail": gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Conquest_Gallery_Thumbnail": gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Carcass_Gallery_Thumbnail": gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2Objects = Hashtable.newFrom({"General_Gallery_Thumbnail": gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects2});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Hover_Gallery_Thumbnail": gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1});
gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects1Objects = Hashtable.newFrom({"Libby_Gallery_Thumbnail": gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects1});
gdjs.GalleryCode.eventsList130 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jerry_Gallery_Thumbnail"), gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDJerry_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(9), true);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Jerry - Play 3 games");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Rudy_Gallery_Thumbnail"), gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDRudy_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(10), true);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Rudy - Play 10 Games");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Zombie_Gallery_Thumbnail"), gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDZombie_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(11), true);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Zombie Gerbil - Play 20 Games");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Alien_Gallery_Thumbnail"), gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDAlien_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(12), true);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Alien - Destroy 50 Rocks");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Conquest_Gallery_Thumbnail"), gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDConquest_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(13), true);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Dr. Conquest - Eat 500 Brains");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Carcass_Gallery_Thumbnail"), gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDCarcass_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(14), true);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("Gerbil Carcass - Eat 1000 Briains, and destroy 200 rocks.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("General_Gallery_Thumbnail"), gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects2);
gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects2Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDGeneral_95959595Gallery_95959595ThumbnailObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(15), true);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects2);
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects2.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects2[i].getBehavior("Text").setText("General - Eat 1500 Brains.");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hover_Gallery_Thumbnail"), gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1);
gdjs.copyArray(runtimeScene.getObjects("Libby_Gallery_Thumbnail"), gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDHover_95959595Gallery_95959595ThumbnailObjects1Objects, gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDLibby_95959595Gallery_95959595ThumbnailObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(16), true);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Selected_Item"), gdjs.GalleryCode.GDSelected_9595ItemObjects1);
{for(var i = 0, len = gdjs.GalleryCode.GDSelected_9595ItemObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDSelected_9595ItemObjects1[i].getBehavior("Text").setText("Libby - Eat 3000 Brains, and Destroy 500 Rocks.");
}
}}

}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDTransitionObjects1Objects = Hashtable.newFrom({"Transition": gdjs.GalleryCode.GDTransitionObjects1});
gdjs.GalleryCode.eventsList131 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.GalleryCode.GDTransitionObjects1 */
{for(var i = 0, len = gdjs.GalleryCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDTransitionObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Transition", 0, "linear", 0.3, false);
}
}}

}


};gdjs.GalleryCode.eventsList132 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.GalleryCode.GDTransitionObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDTransitionObjects1Objects, 0, 0, "");
}{for(var i = 0, len = gdjs.GalleryCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDTransitionObjects1[i].setLayer("Transition");
}
}{for(var i = 0, len = gdjs.GalleryCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDTransitionObjects1[i].getBehavior("Resizable").setSize(1920, 1080);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDTransitionObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}
{ //Subevents
gdjs.GalleryCode.eventsList131(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDTransitionObjects1Objects = Hashtable.newFrom({"Transition": gdjs.GalleryCode.GDTransitionObjects1});
gdjs.GalleryCode.asyncCallback14992348 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Title", false);
}}
gdjs.GalleryCode.eventsList133 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.GalleryCode.asyncCallback14992348(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GalleryCode.eventsList134 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.GalleryCode.eventsList133(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList135 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.GalleryCode.GDTransitionObjects1 */
{for(var i = 0, len = gdjs.GalleryCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDTransitionObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Transition", 255, "linear", 0.3, false);
}
}
{ //Subevents
gdjs.GalleryCode.eventsList134(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList136 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
gdjs.GalleryCode.GDTransitionObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GalleryCode.mapOfGDgdjs_9546GalleryCode_9546GDTransitionObjects1Objects, 0, 0, "");
}{for(var i = 0, len = gdjs.GalleryCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDTransitionObjects1[i].setLayer("Transition");
}
}{for(var i = 0, len = gdjs.GalleryCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDTransitionObjects1[i].getBehavior("Resizable").setSize(1920, 1080);
}
}{for(var i = 0, len = gdjs.GalleryCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.GalleryCode.GDTransitionObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(6), true);
}
{ //Subevents
gdjs.GalleryCode.eventsList135(runtimeScene);} //End of subevents
}

}


};gdjs.GalleryCode.eventsList137 = function(runtimeScene) {

{



}


{



}


{


gdjs.GalleryCode.eventsList22(runtimeScene);
}


{


gdjs.GalleryCode.eventsList30(runtimeScene);
}


{


gdjs.GalleryCode.eventsList31(runtimeScene);
}


{


gdjs.GalleryCode.eventsList34(runtimeScene);
}


{


gdjs.GalleryCode.eventsList37(runtimeScene);
}


{


gdjs.GalleryCode.eventsList41(runtimeScene);
}


{


gdjs.GalleryCode.eventsList45(runtimeScene);
}


{


gdjs.GalleryCode.eventsList46(runtimeScene);
}


{


gdjs.GalleryCode.eventsList49(runtimeScene);
}


{


gdjs.GalleryCode.eventsList60(runtimeScene);
}


{


gdjs.GalleryCode.eventsList67(runtimeScene);
}


{


gdjs.GalleryCode.eventsList68(runtimeScene);
}


{


gdjs.GalleryCode.eventsList70(runtimeScene);
}


{


gdjs.GalleryCode.eventsList72(runtimeScene);
}


{


gdjs.GalleryCode.eventsList73(runtimeScene);
}


{


gdjs.GalleryCode.eventsList78(runtimeScene);
}


{


gdjs.GalleryCode.eventsList79(runtimeScene);
}


{


gdjs.GalleryCode.eventsList84(runtimeScene);
}


{


gdjs.GalleryCode.eventsList85(runtimeScene);
}


{


gdjs.GalleryCode.eventsList86(runtimeScene);
}


{


gdjs.GalleryCode.eventsList119(runtimeScene);
}


{


gdjs.GalleryCode.eventsList122(runtimeScene);
}


{


gdjs.GalleryCode.eventsList129(runtimeScene);
}


{


gdjs.GalleryCode.eventsList130(runtimeScene);
}


{


gdjs.GalleryCode.eventsList132(runtimeScene);
}


{


gdjs.GalleryCode.eventsList136(runtimeScene);
}


};

gdjs.GalleryCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GalleryCode.GDData_9595BGObjects1.length = 0;
gdjs.GalleryCode.GDData_9595BGObjects2.length = 0;
gdjs.GalleryCode.GDData_9595BGObjects3.length = 0;
gdjs.GalleryCode.GDData_9595BGObjects4.length = 0;
gdjs.GalleryCode.GDData_9595BGObjects5.length = 0;
gdjs.GalleryCode.GDData_9595BGObjects6.length = 0;
gdjs.GalleryCode.GDData_9595BGObjects7.length = 0;
gdjs.GalleryCode.GDData_9595BGObjects8.length = 0;
gdjs.GalleryCode.GDData_9595BGObjects9.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects1.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects2.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects3.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects4.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects5.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects6.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects7.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects8.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595ThumbnailObjects9.length = 0;
gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects1.length = 0;
gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects2.length = 0;
gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects3.length = 0;
gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects4.length = 0;
gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects5.length = 0;
gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects6.length = 0;
gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects7.length = 0;
gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects8.length = 0;
gdjs.GalleryCode.GDHover_9595Gallery_9595ThumbnailObjects9.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects1.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects2.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects3.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects4.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects5.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects6.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects7.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects8.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595ThumbnailObjects9.length = 0;
gdjs.GalleryCode.GDBorder_9595LObjects1.length = 0;
gdjs.GalleryCode.GDBorder_9595LObjects2.length = 0;
gdjs.GalleryCode.GDBorder_9595LObjects3.length = 0;
gdjs.GalleryCode.GDBorder_9595LObjects4.length = 0;
gdjs.GalleryCode.GDBorder_9595LObjects5.length = 0;
gdjs.GalleryCode.GDBorder_9595LObjects6.length = 0;
gdjs.GalleryCode.GDBorder_9595LObjects7.length = 0;
gdjs.GalleryCode.GDBorder_9595LObjects8.length = 0;
gdjs.GalleryCode.GDBorder_9595LObjects9.length = 0;
gdjs.GalleryCode.GDBorder_9595RObjects1.length = 0;
gdjs.GalleryCode.GDBorder_9595RObjects2.length = 0;
gdjs.GalleryCode.GDBorder_9595RObjects3.length = 0;
gdjs.GalleryCode.GDBorder_9595RObjects4.length = 0;
gdjs.GalleryCode.GDBorder_9595RObjects5.length = 0;
gdjs.GalleryCode.GDBorder_9595RObjects6.length = 0;
gdjs.GalleryCode.GDBorder_9595RObjects7.length = 0;
gdjs.GalleryCode.GDBorder_9595RObjects8.length = 0;
gdjs.GalleryCode.GDBorder_9595RObjects9.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects1.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects2.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects3.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects4.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects5.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects6.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects7.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects8.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595ThumbnailObjects9.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects1.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects2.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects3.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects4.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects5.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects6.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects7.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects8.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595ThumbnailObjects9.length = 0;
gdjs.GalleryCode.GDBorder_9595BottomObjects1.length = 0;
gdjs.GalleryCode.GDBorder_9595BottomObjects2.length = 0;
gdjs.GalleryCode.GDBorder_9595BottomObjects3.length = 0;
gdjs.GalleryCode.GDBorder_9595BottomObjects4.length = 0;
gdjs.GalleryCode.GDBorder_9595BottomObjects5.length = 0;
gdjs.GalleryCode.GDBorder_9595BottomObjects6.length = 0;
gdjs.GalleryCode.GDBorder_9595BottomObjects7.length = 0;
gdjs.GalleryCode.GDBorder_9595BottomObjects8.length = 0;
gdjs.GalleryCode.GDBorder_9595BottomObjects9.length = 0;
gdjs.GalleryCode.GDBorder_9595TopObjects1.length = 0;
gdjs.GalleryCode.GDBorder_9595TopObjects2.length = 0;
gdjs.GalleryCode.GDBorder_9595TopObjects3.length = 0;
gdjs.GalleryCode.GDBorder_9595TopObjects4.length = 0;
gdjs.GalleryCode.GDBorder_9595TopObjects5.length = 0;
gdjs.GalleryCode.GDBorder_9595TopObjects6.length = 0;
gdjs.GalleryCode.GDBorder_9595TopObjects7.length = 0;
gdjs.GalleryCode.GDBorder_9595TopObjects8.length = 0;
gdjs.GalleryCode.GDBorder_9595TopObjects9.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects1.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects2.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects3.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects4.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects5.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects6.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects7.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects8.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ThumbnailObjects9.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects1.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects2.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects3.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects4.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects5.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects6.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects7.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects8.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ThumbnailObjects9.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects1.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects2.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects3.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects4.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects5.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects6.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects7.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects8.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595ThumbnailObjects9.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects1.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects2.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects3.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects4.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects5.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects6.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects7.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects8.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595ThumbnailObjects9.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects1.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects2.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects3.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects4.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects5.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects6.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects7.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects8.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595TextObjects9.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects1.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects2.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects3.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects4.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects5.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects6.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects7.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects8.length = 0;
gdjs.GalleryCode.GDJerry_9595Gallery_9595ImageObjects9.length = 0;
gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects1.length = 0;
gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects2.length = 0;
gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects3.length = 0;
gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects4.length = 0;
gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects5.length = 0;
gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects6.length = 0;
gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects7.length = 0;
gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects8.length = 0;
gdjs.GalleryCode.GDGallery_9595Image_9595BoxObjects9.length = 0;
gdjs.GalleryCode.GDSelected_9595ItemObjects1.length = 0;
gdjs.GalleryCode.GDSelected_9595ItemObjects2.length = 0;
gdjs.GalleryCode.GDSelected_9595ItemObjects3.length = 0;
gdjs.GalleryCode.GDSelected_9595ItemObjects4.length = 0;
gdjs.GalleryCode.GDSelected_9595ItemObjects5.length = 0;
gdjs.GalleryCode.GDSelected_9595ItemObjects6.length = 0;
gdjs.GalleryCode.GDSelected_9595ItemObjects7.length = 0;
gdjs.GalleryCode.GDSelected_9595ItemObjects8.length = 0;
gdjs.GalleryCode.GDSelected_9595ItemObjects9.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects1.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects2.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects3.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects4.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects5.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects6.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects7.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects8.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595ImageObjects9.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects1.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects2.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects3.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects4.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects5.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects6.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects7.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects8.length = 0;
gdjs.GalleryCode.GDRudy_9595Gallery_9595TextObjects9.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects1.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects2.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects3.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects4.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects5.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects6.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects7.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects8.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595ImageObjects9.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects1.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects2.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects3.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects4.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects5.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects6.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects7.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects8.length = 0;
gdjs.GalleryCode.GDAlien_9595Gallery_9595TextObjects9.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects1.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects2.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects3.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects4.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects5.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects6.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects7.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects8.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595ImageObjects9.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects1.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects2.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects3.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects4.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects5.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects6.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects7.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects8.length = 0;
gdjs.GalleryCode.GDZombie_9595Gallery_9595TextObjects9.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects1.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects2.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects3.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects4.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects5.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects6.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects7.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects8.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595ImageObjects9.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects1.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects2.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects3.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects4.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects5.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects6.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects7.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects8.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595ImageObjects9.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects1.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects2.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects3.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects4.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects5.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects6.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects7.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects8.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595ImageObjects9.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects1.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects2.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects3.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects4.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects5.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects6.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects7.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects8.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595ImageObjects9.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects1.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects2.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects3.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects4.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects5.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects6.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects7.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects8.length = 0;
gdjs.GalleryCode.GDConquest_9595Gallery_9595TextObjects9.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects1.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects2.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects3.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects4.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects5.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects6.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects7.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects8.length = 0;
gdjs.GalleryCode.GDCarcass_9595Gallery_9595TextObjects9.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects1.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects2.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects3.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects4.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects5.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects6.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects7.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects8.length = 0;
gdjs.GalleryCode.GDGeneral_9595Gallery_9595TextObjects9.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects1.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects2.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects3.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects4.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects5.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects6.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects7.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects8.length = 0;
gdjs.GalleryCode.GDLibby_9595Gallery_9595TextObjects9.length = 0;
gdjs.GalleryCode.GDGallery_9595BGObjects1.length = 0;
gdjs.GalleryCode.GDGallery_9595BGObjects2.length = 0;
gdjs.GalleryCode.GDGallery_9595BGObjects3.length = 0;
gdjs.GalleryCode.GDGallery_9595BGObjects4.length = 0;
gdjs.GalleryCode.GDGallery_9595BGObjects5.length = 0;
gdjs.GalleryCode.GDGallery_9595BGObjects6.length = 0;
gdjs.GalleryCode.GDGallery_9595BGObjects7.length = 0;
gdjs.GalleryCode.GDGallery_9595BGObjects8.length = 0;
gdjs.GalleryCode.GDGallery_9595BGObjects9.length = 0;
gdjs.GalleryCode.GDCharacter_9595NameObjects1.length = 0;
gdjs.GalleryCode.GDCharacter_9595NameObjects2.length = 0;
gdjs.GalleryCode.GDCharacter_9595NameObjects3.length = 0;
gdjs.GalleryCode.GDCharacter_9595NameObjects4.length = 0;
gdjs.GalleryCode.GDCharacter_9595NameObjects5.length = 0;
gdjs.GalleryCode.GDCharacter_9595NameObjects6.length = 0;
gdjs.GalleryCode.GDCharacter_9595NameObjects7.length = 0;
gdjs.GalleryCode.GDCharacter_9595NameObjects8.length = 0;
gdjs.GalleryCode.GDCharacter_9595NameObjects9.length = 0;
gdjs.GalleryCode.GDOriginObjects1.length = 0;
gdjs.GalleryCode.GDOriginObjects2.length = 0;
gdjs.GalleryCode.GDOriginObjects3.length = 0;
gdjs.GalleryCode.GDOriginObjects4.length = 0;
gdjs.GalleryCode.GDOriginObjects5.length = 0;
gdjs.GalleryCode.GDOriginObjects6.length = 0;
gdjs.GalleryCode.GDOriginObjects7.length = 0;
gdjs.GalleryCode.GDOriginObjects8.length = 0;
gdjs.GalleryCode.GDOriginObjects9.length = 0;
gdjs.GalleryCode.GDSelectedObjects1.length = 0;
gdjs.GalleryCode.GDSelectedObjects2.length = 0;
gdjs.GalleryCode.GDSelectedObjects3.length = 0;
gdjs.GalleryCode.GDSelectedObjects4.length = 0;
gdjs.GalleryCode.GDSelectedObjects5.length = 0;
gdjs.GalleryCode.GDSelectedObjects6.length = 0;
gdjs.GalleryCode.GDSelectedObjects7.length = 0;
gdjs.GalleryCode.GDSelectedObjects8.length = 0;
gdjs.GalleryCode.GDSelectedObjects9.length = 0;
gdjs.GalleryCode.GDNot_9595SelectedObjects1.length = 0;
gdjs.GalleryCode.GDNot_9595SelectedObjects2.length = 0;
gdjs.GalleryCode.GDNot_9595SelectedObjects3.length = 0;
gdjs.GalleryCode.GDNot_9595SelectedObjects4.length = 0;
gdjs.GalleryCode.GDNot_9595SelectedObjects5.length = 0;
gdjs.GalleryCode.GDNot_9595SelectedObjects6.length = 0;
gdjs.GalleryCode.GDNot_9595SelectedObjects7.length = 0;
gdjs.GalleryCode.GDNot_9595SelectedObjects8.length = 0;
gdjs.GalleryCode.GDNot_9595SelectedObjects9.length = 0;
gdjs.GalleryCode.GDSelect_9595CursorObjects1.length = 0;
gdjs.GalleryCode.GDSelect_9595CursorObjects2.length = 0;
gdjs.GalleryCode.GDSelect_9595CursorObjects3.length = 0;
gdjs.GalleryCode.GDSelect_9595CursorObjects4.length = 0;
gdjs.GalleryCode.GDSelect_9595CursorObjects5.length = 0;
gdjs.GalleryCode.GDSelect_9595CursorObjects6.length = 0;
gdjs.GalleryCode.GDSelect_9595CursorObjects7.length = 0;
gdjs.GalleryCode.GDSelect_9595CursorObjects8.length = 0;
gdjs.GalleryCode.GDSelect_9595CursorObjects9.length = 0;
gdjs.GalleryCode.GDBurrowObjects1.length = 0;
gdjs.GalleryCode.GDBurrowObjects2.length = 0;
gdjs.GalleryCode.GDBurrowObjects3.length = 0;
gdjs.GalleryCode.GDBurrowObjects4.length = 0;
gdjs.GalleryCode.GDBurrowObjects5.length = 0;
gdjs.GalleryCode.GDBurrowObjects6.length = 0;
gdjs.GalleryCode.GDBurrowObjects7.length = 0;
gdjs.GalleryCode.GDBurrowObjects8.length = 0;
gdjs.GalleryCode.GDBurrowObjects9.length = 0;
gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects1.length = 0;
gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects2.length = 0;
gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects3.length = 0;
gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects4.length = 0;
gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects5.length = 0;
gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects6.length = 0;
gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects7.length = 0;
gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects8.length = 0;
gdjs.GalleryCode.GDHigh_9595Score_9595GameplayObjects9.length = 0;
gdjs.GalleryCode.GDSkyObjects1.length = 0;
gdjs.GalleryCode.GDSkyObjects2.length = 0;
gdjs.GalleryCode.GDSkyObjects3.length = 0;
gdjs.GalleryCode.GDSkyObjects4.length = 0;
gdjs.GalleryCode.GDSkyObjects5.length = 0;
gdjs.GalleryCode.GDSkyObjects6.length = 0;
gdjs.GalleryCode.GDSkyObjects7.length = 0;
gdjs.GalleryCode.GDSkyObjects8.length = 0;
gdjs.GalleryCode.GDSkyObjects9.length = 0;
gdjs.GalleryCode.GDJerry_9595LogoObjects1.length = 0;
gdjs.GalleryCode.GDJerry_9595LogoObjects2.length = 0;
gdjs.GalleryCode.GDJerry_9595LogoObjects3.length = 0;
gdjs.GalleryCode.GDJerry_9595LogoObjects4.length = 0;
gdjs.GalleryCode.GDJerry_9595LogoObjects5.length = 0;
gdjs.GalleryCode.GDJerry_9595LogoObjects6.length = 0;
gdjs.GalleryCode.GDJerry_9595LogoObjects7.length = 0;
gdjs.GalleryCode.GDJerry_9595LogoObjects8.length = 0;
gdjs.GalleryCode.GDJerry_9595LogoObjects9.length = 0;
gdjs.GalleryCode.GDBrains_9595EatenObjects1.length = 0;
gdjs.GalleryCode.GDBrains_9595EatenObjects2.length = 0;
gdjs.GalleryCode.GDBrains_9595EatenObjects3.length = 0;
gdjs.GalleryCode.GDBrains_9595EatenObjects4.length = 0;
gdjs.GalleryCode.GDBrains_9595EatenObjects5.length = 0;
gdjs.GalleryCode.GDBrains_9595EatenObjects6.length = 0;
gdjs.GalleryCode.GDBrains_9595EatenObjects7.length = 0;
gdjs.GalleryCode.GDBrains_9595EatenObjects8.length = 0;
gdjs.GalleryCode.GDBrains_9595EatenObjects9.length = 0;
gdjs.GalleryCode.GDTransitionObjects1.length = 0;
gdjs.GalleryCode.GDTransitionObjects2.length = 0;
gdjs.GalleryCode.GDTransitionObjects3.length = 0;
gdjs.GalleryCode.GDTransitionObjects4.length = 0;
gdjs.GalleryCode.GDTransitionObjects5.length = 0;
gdjs.GalleryCode.GDTransitionObjects6.length = 0;
gdjs.GalleryCode.GDTransitionObjects7.length = 0;
gdjs.GalleryCode.GDTransitionObjects8.length = 0;
gdjs.GalleryCode.GDTransitionObjects9.length = 0;
gdjs.GalleryCode.GDHigh_9595ScoreObjects1.length = 0;
gdjs.GalleryCode.GDHigh_9595ScoreObjects2.length = 0;
gdjs.GalleryCode.GDHigh_9595ScoreObjects3.length = 0;
gdjs.GalleryCode.GDHigh_9595ScoreObjects4.length = 0;
gdjs.GalleryCode.GDHigh_9595ScoreObjects5.length = 0;
gdjs.GalleryCode.GDHigh_9595ScoreObjects6.length = 0;
gdjs.GalleryCode.GDHigh_9595ScoreObjects7.length = 0;
gdjs.GalleryCode.GDHigh_9595ScoreObjects8.length = 0;
gdjs.GalleryCode.GDHigh_9595ScoreObjects9.length = 0;
gdjs.GalleryCode.GDRocks_9595DestroyedObjects1.length = 0;
gdjs.GalleryCode.GDRocks_9595DestroyedObjects2.length = 0;
gdjs.GalleryCode.GDRocks_9595DestroyedObjects3.length = 0;
gdjs.GalleryCode.GDRocks_9595DestroyedObjects4.length = 0;
gdjs.GalleryCode.GDRocks_9595DestroyedObjects5.length = 0;
gdjs.GalleryCode.GDRocks_9595DestroyedObjects6.length = 0;
gdjs.GalleryCode.GDRocks_9595DestroyedObjects7.length = 0;
gdjs.GalleryCode.GDRocks_9595DestroyedObjects8.length = 0;
gdjs.GalleryCode.GDRocks_9595DestroyedObjects9.length = 0;
gdjs.GalleryCode.GDGames_9595PlayedObjects1.length = 0;
gdjs.GalleryCode.GDGames_9595PlayedObjects2.length = 0;
gdjs.GalleryCode.GDGames_9595PlayedObjects3.length = 0;
gdjs.GalleryCode.GDGames_9595PlayedObjects4.length = 0;
gdjs.GalleryCode.GDGames_9595PlayedObjects5.length = 0;
gdjs.GalleryCode.GDGames_9595PlayedObjects6.length = 0;
gdjs.GalleryCode.GDGames_9595PlayedObjects7.length = 0;
gdjs.GalleryCode.GDGames_9595PlayedObjects8.length = 0;
gdjs.GalleryCode.GDGames_9595PlayedObjects9.length = 0;

gdjs.GalleryCode.eventsList137(runtimeScene);

return;

}

gdjs['GalleryCode'] = gdjs.GalleryCode;
